import * as ethers from 'ethers';

/**
 * Converts a hexadecimal string to a decimal string.
 * @param hexString The hexadecimal string (e.g., "0x1a").
 * @returns The decimal string.
 */
export const formatHexToDecimal = (hexString: string): string => {
  if (!hexString || hexString === '0x') return '0';
  try {
    return ethers.toBigInt(hexString).toString();
  } catch (e) {
    console.error('Error formatting hex to decimal:', e);
    return hexString; // Return original if parsing fails
  }
};

/**
 * Converts a hexadecimal timestamp string to a human-readable date and time.
 * @param hexTimestamp The hexadecimal timestamp string (e.g., "0x60c0f9a0").
 * @returns A formatted date string.
 */
export const formatTimestamp = (hexTimestamp: string): string => {
  if (!hexTimestamp) return 'N/A';
  try {
    const timestampInSeconds = parseInt(hexTimestamp, 16);
    return new Date(timestampInSeconds * 1000).toLocaleString();
  } catch (e) {
    console.error('Error formatting timestamp:', e);
    return hexTimestamp; // Return original if parsing fails
  }
};

/**
 * Converts a value from Wei (hex string) to BNB, formatted to a fixed number of decimal places.
 * @param weiHex The value in Wei as a hexadecimal string (e.g., "0x1000000000000000").
 * @returns The value in BNB as a string.
 */
export const formatWeiToBNB = (weiHex: string): string => {
  if (!weiHex || weiHex === '0x') return '0 BNB';
  try {
    // ethers v6 uses BigInt internally and formatUnits for conversion
    const bnbValue = ethers.formatUnits(weiHex, 18); // This returns a string like "0.123456789012345678" or "123.456"

    const [integerPart, decimalPart] = bnbValue.split('.');
    if (!decimalPart) {
      return `${integerPart} BNB`;
    }

    // Display up to 6 decimal places for BNB for readability, and remove trailing zeros
    const trimmedDecimal = decimalPart.substring(0, Math.min(decimalPart.length, 6)).replace(/0+$/, '');

    return `${integerPart}${trimmedDecimal ? '.' + trimmedDecimal : ''} BNB`;
  } catch (e) {
    console.error('Error formatting Wei to BNB:', e);
    return `${weiHex} Wei`; // Return original if parsing fails
  }
};

/**
 * Converts lamports (Solana's smallest unit) to SOL.
 * @param lamports The value in lamports.
 * @returns The value in SOL as a string.
 */
export const formatLamportsToSOL = (lamports: number): string => {
  // 1 SOL = 1,000,000,000 lamports
  return (lamports / 1_000_000_000).toFixed(9).replace(/\.?0+$/, '') + ' SOL';
};

/**
 * Converts a Unix timestamp to a human-readable date and time.
 * @param timestamp The Unix timestamp in seconds.
 * @returns A formatted date string.
 */
export const formatSolanaTimestamp = (timestamp: number | null): string => {
  if (timestamp === null) return 'N/A';
  try {
    return new Date(timestamp * 1000).toLocaleString();
  } catch (e) {
    console.error('Error formatting Solana timestamp:', e);
    return timestamp.toString();
  }
};

/**
 * Shortens a Solana address or transaction signature for display.
 * @param address The full address or signature string.
 * @param chars The number of characters to show at the start and end.
 * @returns The shortened string.
 */
export const shortenAddress = (address: string, chars: number = 6): string => {
  if (!address) return '';
  if (address.length <= chars * 2 + 3) return address; // If too short to shorten meaningfully
  return `${address.substring(0, chars)}...${address.substring(address.length - chars)}`;
};