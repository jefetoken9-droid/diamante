export const DEFAULT_RPC_URL = 'https://bsc-dataseed.binance.org/';
export const DEFAULT_SOLANA_RPC_URL = 'https://api.devnet.solana.com'; // Changed back to Devnet for better default experience
export const BLOCK_FETCH_INTERVAL_MS = 10000; // 10 seconds
export const NUM_BLOCKS_TO_DISPLAY = 10;

// Diamante (DMT) Token Configuration
export const DMT_TOKEN_ADDRESS = '5zJo2GzYRgiZw5j3SBNpuqVcGok35kT3ADwsw74yJWV6'; // Mainnet-beta address
export const DMT_TOKEN_DECIMALS = 6;
export const DMT_TOKEN_NETWORK = 'mainnet-beta'; // Explicitly state the network for DMT