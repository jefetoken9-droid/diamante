import React from 'react';
import { SolanaBlock } from '../types';
import { formatSolanaTimestamp, shortenAddress } from '../utils/formatters';

interface SolanaBlockDetailProps {
  block: SolanaBlock;
  onClose: () => void;
  onSelectTransaction: (signature: string) => void;
}

const SolanaBlockDetail: React.FC<SolanaBlockDetailProps> = ({ block, onClose, onSelectTransaction }) => {
  const renderDetailRow = (label: string, value: string | number | null) => (
    <div className="flex flex-col sm:flex-row py-2 border-b border-gray-700">
      <span className="font-semibold text-gray-300 w-full sm:w-1/4 min-w-[120px]">{label}:</span>
      <span className="text-gray-100 font-mono break-all w-full sm:w-3/4">{value === null ? 'N/A' : value}</span>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-95 z-50 overflow-y-auto p-4 sm:p-8 flex justify-center" role="dialog" aria-modal="true" aria-labelledby="solana-block-detail-title">
      <div className="bg-gray-800 rounded-lg shadow-2xl max-w-4xl w-full relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-200 text-3xl font-bold transition-colors duration-200"
          aria-label="Close block details"
        >
          &times;
        </button>
        <div className="p-6 sm:p-8">
          <h2 id="solana-block-detail-title" className="text-3xl font-bold text-emerald-400 mb-6 border-b border-gray-700 pb-4">
            Solana Block #{block.slot}
          </h2>

          <div className="space-y-2 mb-8 text-sm" role="region" aria-label="Block Header Details">
            {renderDetailRow('Blockhash', block.blockhash)}
            {renderDetailRow('Timestamp', formatSolanaTimestamp(block.blockTime))}
            {renderDetailRow('Parent Slot', block.parentSlot)}
            {renderDetailRow('Block Height', block.blockHeight)}
            {renderDetailRow('Transactions', block.signatures.length)}
          </div>

          <h3 className="text-2xl font-bold text-emerald-400 mb-4 border-b border-gray-700 pb-3" aria-label="Transactions in this Block">Transactions</h3>
          {block.signatures.length === 0 ? (
            <p className="text-gray-400">No transactions in this block.</p>
          ) : (
            <div className="space-y-4" role="list">
              {block.signatures.map((signature: string) => (
                <div key={signature} className="bg-gray-700 p-4 rounded-lg shadow-inner text-sm flex items-center justify-between" role="listitem">
                  <span className="text-gray-100 font-mono break-all flex-grow mr-4" title={signature}>
                    {shortenAddress(signature, 20)}
                  </span>
                  <button
                    onClick={() => onSelectTransaction(signature)}
                    className="px-4 py-2 bg-emerald-600 text-white font-semibold rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-colors duration-200 text-xs sm:text-sm"
                    aria-label={`View details for transaction ${shortenAddress(signature)}`}
                  >
                    View Details
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SolanaBlockDetail;