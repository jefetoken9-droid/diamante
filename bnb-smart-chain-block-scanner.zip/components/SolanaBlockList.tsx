import React from 'react';
import { SolanaBlock } from '../types';
import SolanaBlockListItem from './SolanaBlockListItem';

interface SolanaBlockListProps {
  blocks: SolanaBlock[];
  onBlockSelect: (block: SolanaBlock) => void;
}

const SolanaBlockList: React.FC<SolanaBlockListProps> = ({ blocks, onBlockSelect }) => {
  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-2xl h-full overflow-y-auto">
      <h2 className="text-2xl font-bold text-emerald-400 mb-6 border-b border-gray-700 pb-3 sticky top-0 bg-gray-900 z-10" aria-label="Latest Solana Blocks">
        Latest Solana Blocks
      </h2>
      {blocks.length === 0 ? (
        <p className="text-gray-400 text-center py-10">No blocks to display. Start scanning!</p>
      ) : (
        <ul className="space-y-4" role="list">
          {blocks.map((block) => (
            <SolanaBlockListItem key={block.blockhash} block={block} onSelect={onBlockSelect} />
          ))}
        </ul>
      )}
    </div>
  );
};

export default SolanaBlockList;