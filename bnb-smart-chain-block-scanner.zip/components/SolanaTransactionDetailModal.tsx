import React, { useState, useEffect } from 'react';
import { SolanaTransactionDetails } from '../types';
import { getSolanaTransaction } from '../services/solanaService';
import { formatLamportsToSOL, formatSolanaTimestamp, shortenAddress } from '../utils/formatters';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';
import { DMT_TOKEN_ADDRESS } from '../constants'; // Import DMT token address

interface SolanaTransactionDetailModalProps {
  rpcUrl: string;
  signature: string | null;
  onClose: () => void;
}

const SolanaTransactionDetailModal: React.FC<SolanaTransactionDetailModalProps> = ({ rpcUrl, signature, onClose }) => {
  const [txDetails, setTxDetails] = useState<SolanaTransactionDetails | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!signature) {
      setTxDetails(null);
      setLoading(false);
      return;
    }

    const fetchTxDetails = async () => {
      setLoading(true);
      setError(null);
      try {
        const details = await getSolanaTransaction(rpcUrl, signature);
        if (!details) {
          throw new Error('Transaction details not found.');
        }
        setTxDetails(details);
      } catch (err) {
        console.error('Failed to fetch Solana transaction details:', err);
        setError(`Failed to load transaction details: ${err instanceof Error ? err.message : String(err)}`);
      } finally {
        setLoading(false);
      }
    };

    fetchTxDetails();
  }, [rpcUrl, signature]);

  if (!signature) return null; // Only render if a signature is provided

  const renderDetailRow = (label: string, value: string | number | null) => (
    <div className="flex flex-col sm:flex-row py-2 border-b border-gray-700">
      <span className="font-semibold text-gray-300 w-full sm:w-1/4 min-w-[120px]">{label}:</span>
      <span className="text-gray-100 font-mono break-all w-full sm:w-3/4">{value === null ? 'N/A' : value}</span>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-95 z-50 overflow-y-auto p-4 sm:p-8 flex justify-center" role="dialog" aria-modal="true" aria-labelledby="solana-tx-detail-title">
      <div className="bg-gray-800 rounded-lg shadow-2xl max-w-4xl w-full relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-200 text-3xl font-bold transition-colors duration-200"
          aria-label="Close transaction details"
        >
          &times;
        </button>
        <div className="p-6 sm:p-8">
          <h2 id="solana-tx-detail-title" className="text-3xl font-bold text-emerald-400 mb-6 border-b border-gray-700 pb-4">
            Solana Transaction Details
          </h2>

          {loading && <LoadingSpinner />}
          {error && <ErrorMessage message={error} />}

          {!loading && !error && !txDetails && (
            <p className="text-gray-400 text-center py-10">No details available for this transaction.</p>
          )}

          {!loading && !error && txDetails && (
            <div className="space-y-2 text-sm">
              {renderDetailRow('Signature', txDetails.signature)}
              {renderDetailRow('Slot', txDetails.slot)}
              {renderDetailRow('Block Time', formatSolanaTimestamp(txDetails.blockTime))}
              {renderDetailRow('Status', txDetails.status)}
              {renderDetailRow('Fee', formatLamportsToSOL(txDetails.fee))}

              {/* New section for Token Transfers */}
              {txDetails.tokenTransfers.length > 0 && (
                <>
                  <h3 className="text-xl font-bold text-emerald-400 mt-6 mb-2 border-b border-gray-700 pb-2">Token Transfers</h3>
                  <div className="space-y-3">
                    {txDetails.tokenTransfers.map((transfer, index) => (
                      <div
                        key={index}
                        className={`p-3 rounded-md shadow-inner ${
                          transfer.isDMT ? 'bg-purple-800 border border-purple-600' : 'bg-gray-700'
                        }`}
                      >
                        <p className="font-semibold text-gray-200 mb-1">
                          {transfer.uiAmountString} {transfer.isDMT ? 'DMT' : shortenAddress(transfer.mint, 8)}
                          {transfer.isDMT && <span className="ml-2 px-2 py-0.5 bg-purple-500 text-white text-xs rounded-full">DMT</span>}
                        </p>
                        <p className="text-gray-300 text-xs">From: <span className="font-mono break-all">{shortenAddress(transfer.from, 12)}</span></p>
                        <p className="text-gray-300 text-xs">To: <span className="font-mono break-all">{shortenAddress(transfer.to, 12)}</span></p>
                        {!transfer.isDMT && <p className="text-gray-300 text-xs">Mint: <span className="font-mono break-all">{shortenAddress(transfer.mint, 12)}</span></p>}
                      </div>
                    ))}
                  </div>
                </>
              )}

              <h3 className="text-xl font-bold text-emerald-400 mt-6 mb-2 border-b border-gray-700 pb-2">Account Keys</h3>
              {txDetails.accountKeys.length > 0 ? (
                <ul className="list-disc list-inside space-y-1 ml-4 text-gray-100 font-mono break-all">
                  {txDetails.accountKeys.map((key, index) => (
                    <li key={index} title={key}>{shortenAddress(key, 12)}</li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-400">No account keys involved.</p>
              )}

              <h3 className="text-xl font-bold text-emerald-400 mt-6 mb-2 border-b border-gray-700 pb-2">Instructions</h3>
              {txDetails.instructions.length > 0 ? (
                <div className="space-y-4">
                  {txDetails.instructions.map((instruction, index) => (
                    <div key={index} className="bg-gray-700 p-3 rounded-md shadow-inner">
                      {renderDetailRow('Program ID', shortenAddress(instruction.programId, 12))}
                      <div className="flex flex-col sm:flex-row py-1">
                        <span className="font-semibold text-gray-300 w-full sm:w-1/4 min-w-[120px]">Accounts:</span>
                        <ul className="list-disc list-inside space-y-1 ml-4 text-gray-100 font-mono break-all w-full sm:w-3/4">
                          {instruction.accounts.map((acc, accIdx) => (
                            <li key={accIdx} title={acc}>{shortenAddress(acc, 12)}</li>
                          ))}
                        </ul>
                      </div>
                      {renderDetailRow('Data', instruction.data)}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-400">No instructions found.</p>
              )}

              <h3 className="text-xl font-bold text-emerald-400 mt-6 mb-2 border-b border-gray-700 pb-2">Log Messages</h3>
              {txDetails.logMessages.length > 0 ? (
                <ul className="list-disc list-inside space-y-1 ml-4 text-gray-100 font-mono break-all">
                  {txDetails.logMessages.map((log, index) => (
                    <li key={index}>{log}</li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-400">No log messages.</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SolanaTransactionDetailModal;