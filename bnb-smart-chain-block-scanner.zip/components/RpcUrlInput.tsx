import React, { useState, useEffect } from 'react';

interface RpcUrlInputProps {
  currentRpcUrl: string;
  onRpcUrlChange: (newUrl: string) => void;
  chainName: string; // New prop to display the current chain
  placeholder?: string; // Custom placeholder text
}

const RpcUrlInput: React.FC<RpcUrlInputProps> = ({ currentRpcUrl, onRpcUrlChange, chainName, placeholder }) => {
  const [inputUrl, setInputUrl] = useState<string>(currentRpcUrl);

  // Update inputUrl when currentRpcUrl changes from parent (e.g., chain switch)
  useEffect(() => {
    setInputUrl(currentRpcUrl);
  }, [currentRpcUrl]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputUrl.trim() && inputUrl.trim() !== currentRpcUrl) {
      onRpcUrlChange(inputUrl.trim());
    }
  };

  return (
    <div className="mb-6 bg-gray-800 p-4 rounded-lg shadow-inner">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4">
        <input
          type="url"
          value={inputUrl}
          onChange={(e) => setInputUrl(e.target.value)}
          placeholder={placeholder || `Enter custom RPC URL for ${chainName}`}
          className="flex-grow p-3 rounded-md bg-gray-700 border border-gray-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-gray-50 placeholder-gray-400"
          aria-label={`RPC URL for ${chainName}`}
        />
        <button
          type="submit"
          className="px-6 py-3 bg-emerald-600 text-white font-semibold rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={!inputUrl.trim() || inputUrl.trim() === currentRpcUrl}
          aria-label={`Set RPC URL for ${chainName}`}
        >
          Set RPC URL
        </button>
      </form>
      <p className="mt-2 text-sm text-gray-400">Current RPC for {chainName}: <span className="text-emerald-300 break-all">{currentRpcUrl}</span></p>
      {chainName === 'BNB Smart Chain' && (
        <p className="mt-1 text-xs text-gray-500">
          Tip: You can use an Alchemy RPC URL for BSC here (e.g., `https://bsc-mainnet.g.alchemy.com/v2/YOUR_API_KEY`)
          by replacing `YOUR_API_KEY` with your actual Alchemy key.
          Remember to keep your API key secure and do not share it.
        </p>
      )}
      {chainName === 'Solana' && (
        <p className="mt-1 text-xs text-gray-500">
          Tip: The default is Solana Devnet. For stable and reliable access to Solana Mainnet (and to avoid frequent "Access Forbidden" or rate limit errors),
          it is highly recommended to use a dedicated RPC provider (e.g., Helius, Alchemy, QuickNode).
          You will need to obtain an API key from them and enter their specific endpoint URL here. Remember to keep any API keys secure and do not share them.
        </p>
      )}
    </div>
  );
};

export default RpcUrlInput;