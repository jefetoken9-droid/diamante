import React from 'react';
import { EVMBlock } from '../types';
import { formatHexToDecimal, formatTimestamp } from '../utils/formatters';

interface BlockListItemProps {
  block: EVMBlock;
  onSelect: (block: EVMBlock) => void;
}

const BlockListItem: React.FC<BlockListItemProps> = ({ block, onSelect }) => {
  const blockNumber = formatHexToDecimal(block.number);
  const timestamp = formatTimestamp(block.timestamp);

  return (
    <li
      className="bg-gray-800 p-4 rounded-lg shadow-md cursor-pointer hover:bg-gray-700 transition-colors duration-200 flex flex-col sm:flex-row justify-between items-start sm:items-center"
      onClick={() => onSelect(block)}
    >
      <div>
        <h3 className="text-emerald-400 font-semibold text-lg">Block #{blockNumber}</h3>
        <p className="text-gray-300 text-sm truncate w-64 sm:w-auto">Hash: {block.hash}</p>
      </div>
      <div className="text-right mt-2 sm:mt-0">
        <p className="text-gray-400 text-sm">Miner: <span className="font-mono text-xs">{block.miner.substring(0, 10)}...</span></p>
        <p className="text-gray-400 text-sm">Timestamp: {timestamp}</p>
        <p className="text-gray-400 text-sm">{formatHexToDecimal(block.transactions.length.toString())} Txns</p>
      </div>
    </li>
  );
};

export default BlockListItem;