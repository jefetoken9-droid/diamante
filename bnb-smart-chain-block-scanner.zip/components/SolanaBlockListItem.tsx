import React from 'react';
import { SolanaBlock } from '../types';
import { formatSolanaTimestamp, shortenAddress } from '../utils/formatters';

interface SolanaBlockListItemProps {
  block: SolanaBlock;
  onSelect: (block: SolanaBlock) => void;
}

const SolanaBlockListItem: React.FC<SolanaBlockListItemProps> = ({ block, onSelect }) => {
  const timestamp = formatSolanaTimestamp(block.blockTime);

  return (
    <li
      className="bg-gray-800 p-4 rounded-lg shadow-md cursor-pointer hover:bg-gray-700 transition-colors duration-200 flex flex-col sm:flex-row justify-between items-start sm:items-center"
      onClick={() => onSelect(block)}
      role="listitem"
      aria-label={`Solana Block ${block.slot}`}
    >
      <div>
        <h3 className="text-emerald-400 font-semibold text-lg">Slot #{block.slot}</h3>
        <p className="text-gray-300 text-sm truncate w-64 sm:w-auto" title={block.blockhash}>Blockhash: {shortenAddress(block.blockhash)}</p>
      </div>
      <div className="text-right mt-2 sm:mt-0">
        <p className="text-gray-400 text-sm">Parent Slot: {block.parentSlot}</p>
        <p className="text-gray-400 text-sm">Timestamp: {timestamp}</p>
        <p className="text-gray-400 text-sm">{block.signatures.length} Txns</p>
      </div>
    </li>
  );
};

export default SolanaBlockListItem;