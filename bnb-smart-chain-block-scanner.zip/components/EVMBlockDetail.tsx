import React from 'react';
import { EVMBlock, EVMTransaction } from '../types';
import { formatHexToDecimal, formatTimestamp, formatWeiToBNB } from '../utils/formatters';

interface EVMBlockDetailProps {
  block: EVMBlock;
  onClose: () => void;
}

const EVMBlockDetail: React.FC<EVMBlockDetailProps> = ({ block, onClose }) => {
  const renderDetailRow = (label: string, value: string | number) => (
    <div className="flex flex-col sm:flex-row py-2 border-b border-gray-700">
      <span className="font-semibold text-gray-300 w-full sm:w-1/4 min-w-[120px]">{label}:</span>
      <span className="text-gray-100 font-mono break-all w-full sm:w-3/4">{value}</span>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-95 z-50 overflow-y-auto p-4 sm:p-8 flex justify-center" role="dialog" aria-modal="true" aria-labelledby="evm-block-detail-title">
      <div className="bg-gray-800 rounded-lg shadow-2xl max-w-4xl w-full relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-200 text-3xl font-bold transition-colors duration-200"
          aria-label="Close block details"
        >
          &times;
        </button>
        <div className="p-6 sm:p-8">
          <h2 id="evm-block-detail-title" className="text-3xl font-bold text-emerald-400 mb-6 border-b border-gray-700 pb-4">
            EVM Block #{formatHexToDecimal(block.number)}
          </h2>

          <div className="space-y-2 mb-8 text-sm" role="region" aria-label="Block Header Details">
            {renderDetailRow('Hash', block.hash)}
            {renderDetailRow('Timestamp', formatTimestamp(block.timestamp))}
            {renderDetailRow('Miner', block.miner)}
            {renderDetailRow('Parent Hash', block.parentHash)}
            {renderDetailRow('Transactions', formatHexToDecimal(block.transactions.length.toString()))}
            {renderDetailRow('Gas Used', formatHexToDecimal(block.gasUsed))}
            {renderDetailRow('Gas Limit', formatHexToDecimal(block.gasLimit))}
            {renderDetailRow('Size', `${formatHexToDecimal(block.size)} bytes`)}
            {renderDetailRow('Difficulty', formatHexToDecimal(block.difficulty))}
            {renderDetailRow('Total Difficulty', formatHexToDecimal(block.totalDifficulty))}
            {renderDetailRow('Nonce', block.nonce)}
            {renderDetailRow('Extra Data', block.extraData)}
            {renderDetailRow('State Root', block.stateRoot)}
            {renderDetailRow('Transactions Root', block.transactionsRoot)}
            {renderDetailRow('Receipts Root', block.receiptsRoot)}
            {renderDetailRow('Logs Bloom', block.logsBloom)}
          </div>

          <h3 className="text-2xl font-bold text-emerald-400 mb-4 border-b border-gray-700 pb-3" aria-label="Transactions in this Block">Transactions</h3>
          {block.transactions.length === 0 ? (
            <p className="text-gray-400">No transactions in this block.</p>
          ) : (
            <div className="space-y-4" role="list">
              {block.transactions.map((tx: EVMTransaction) => (
                <div key={tx.hash} className="bg-gray-700 p-4 rounded-lg shadow-inner text-sm" role="listitem">
                  {renderDetailRow('Tx Hash', tx.hash)}
                  {renderDetailRow('From', tx.from)}
                  {renderDetailRow('To', tx.to || 'Contract Creation')}
                  {renderDetailRow('Value', formatWeiToBNB(tx.value))}
                  {renderDetailRow('Gas Price', formatWeiToBNB(tx.gasPrice))}
                  {renderDetailRow('Gas Used', formatHexToDecimal(tx.gas))}
                  {renderDetailRow('Nonce', formatHexToDecimal(tx.nonce))}
                  {renderDetailRow('Tx Index', formatHexToDecimal(tx.transactionIndex))}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EVMBlockDetail;