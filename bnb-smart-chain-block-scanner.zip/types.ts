// EVM Chain Types (e.g., BNB Smart Chain)
export interface EVMBlock {
  number: string; // Hex string (e.g., "0x1234")
  hash: string;
  parentHash: string;
  nonce: string;
  sha3Uncles: string;
  logsBloom: string;
  transactionsRoot: string;
  stateRoot: string;
  receiptsRoot: string;
  miner: string;
  difficulty: string;
  totalDifficulty: string;
  extraData: string;
  size: string; // Hex string
  gasLimit: string; // Hex string
  gasUsed: string; // Hex string
  timestamp: string; // Hex string
  transactions: EVMTransaction[]; // Array of full Transaction objects
  uncles: string[];
}

export interface EVMTransaction {
  blockHash: string;
  blockNumber: string; // Hex string
  from: string;
  gas: string; // Hex string
  gasPrice: string; // Hex string (in wei)
  hash: string;
  input: string;
  nonce: string; // Hex string
  to: string | null;
  transactionIndex: string; // Hex string
  value: string; // Hex string (in wei)
  v: string;
  r: string;
  s: string;
}

// Solana Chain Types
export interface SolanaBlock {
  slot: number;
  blockhash: string;
  parentSlot: number;
  // blockTime is Unix timestamp in seconds, null for absent blockTime
  blockTime: number | null;
  blockHeight: number | null;
  // Signatures for transactions in this block (not full transaction objects)
  signatures: string[];
}

export interface TokenTransfer {
  from: string;
  to: string;
  mint: string;
  amount: string; // Amount as string, considering token decimals
  uiAmountString: string; // Formatted UI amount for display
  isDMT: boolean; // Flag to identify if it's the DMT token
}

// Simplified Solana Transaction details for display, fetched separately
export interface SolanaTransactionDetails {
  signature: string;
  slot: number;
  blockTime: number | null; // Unix timestamp
  fee: number; // In lamports
  status: 'Success' | 'Failed'; // Derived from meta.err
  logMessages: string[];
  // Participants (simplified to just PublicKey strings)
  accountKeys: string[];
  // Instructions (simplified)
  instructions: Array<{
    programId: string;
    accounts: string[];
    data: string;
    // Add parsed if available and useful
  }>;
  tokenTransfers: TokenTransfer[]; // New field for token transfers
}


// RPC Response Types
export interface RpcResponse<T> {
  jsonrpc: string;
  id: number;
  result: T;
  error?: {
    code: number;
    message: string;
    data?: any;
  };
}