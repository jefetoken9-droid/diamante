import React, { useState, useEffect, useCallback, useRef } from 'react';
import { EVMBlock, SolanaBlock } from './types';
import { getLatestBlockNumber, getBlockByNumber } from './services/bscService';
import { getLatestSolanaBlockSlot, getSolanaBlock } from './services/solanaService';
import { DEFAULT_RPC_URL, DEFAULT_SOLANA_RPC_URL, BLOCK_FETCH_INTERVAL_MS, NUM_BLOCKS_TO_DISPLAY } from './constants';
import RpcUrlInput from './components/RpcUrlInput';
import EVMBlockList from './components/EVMBlockList';
import EVMBlockDetail from './components/EVMBlockDetail';
import SolanaBlockList from './components/SolanaBlockList';
import SolanaBlockDetail from './components/SolanaBlockDetail';
import SolanaTransactionDetailModal from './components/SolanaTransactionDetailModal';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';

type Chain = 'bsc' | 'solana';

const App: React.FC = () => {
  const [selectedChain, setSelectedChain] = useState<Chain>('bsc');
  const [rpcUrls, setRpcUrls] = useState<Record<Chain, string>>({
    bsc: DEFAULT_RPC_URL,
    solana: DEFAULT_SOLANA_RPC_URL, // Using Devnet by default for a functional experience, user can change
  });
  const [bscBlocks, setBscBlocks] = useState<EVMBlock[]>([]);
  const [solanaBlocks, setSolanaBlocks] = useState<SolanaBlock[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedEVMBlock, setSelectedEVMBlock] = useState<EVMBlock | null>(null);
  const [selectedSolanaBlock, setSelectedSolanaBlock] = useState<SolanaBlock | null>(null);
  const [selectedSolanaTxSignature, setSelectedSolanaTxSignature] = useState<string | null>(null);

  const latestFetchedBscBlockNumberRef = useRef<number | null>(null);
  const latestFetchedSolanaSlotRef = useRef<number | null>(null);

  const currentRpcUrl = rpcUrls[selectedChain];

  const fetchBscBlocks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const latestBlockNumberHex = await getLatestBlockNumber(rpcUrls.bsc);
      const latestBlockNumber = parseInt(latestBlockNumberHex, 16);

      if (latestFetchedBscBlockNumberRef.current === latestBlockNumber) {
        setLoading(false);
        return;
      }

      latestFetchedBscBlockNumberRef.current = latestBlockNumber;

      const fetchedBlocks: EVMBlock[] = [];
      const blocksToFetchCount = Math.min(NUM_BLOCKS_TO_DISPLAY, latestBlockNumber + 1);

      for (let i = 0; i < blocksToFetchCount; i++) {
        const blockNumberToFetch = latestBlockNumber - i;
        if (blockNumberToFetch < 0) break;
        const blockHex = `0x${blockNumberToFetch.toString(16)}`;
        const blockData = await getBlockByNumber(rpcUrls.bsc, blockHex, true);
        if (blockData) {
          fetchedBlocks.push(blockData);
        }
      }
      setBscBlocks(fetchedBlocks.sort((a, b) => parseInt(b.number, 16) - parseInt(a.number, 16)));
    } catch (err) {
      console.error("Failed to fetch BSC blocks:", err);
      setError(`Failed to fetch BSC blocks. Please check the RPC URL or network connection. Details: ${err instanceof Error ? err.message : String(err)}`);
      setBscBlocks([]);
    } finally {
      setLoading(false);
    }
  }, [rpcUrls.bsc]);

  const fetchSolanaBlocks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const latestSlot = await getLatestSolanaBlockSlot(rpcUrls.solana);

      if (latestFetchedSolanaSlotRef.current === latestSlot) {
        setLoading(false);
        return;
      }

      latestFetchedSolanaSlotRef.current = latestSlot;

      const fetchedBlocks: SolanaBlock[] = [];
      const blocksToFetchCount = Math.min(NUM_BLOCKS_TO_DISPLAY, latestSlot + 1);

      for (let i = 0; i < blocksToFetchCount; i++) {
        const slotToFetch = latestSlot - i;
        if (slotToFetch < 0) break;
        // Solana's getBlock can be slow if fetching many transactions.
        // We fetch only basic block info and transaction signatures here.
        const blockData = await getSolanaBlock(rpcUrls.solana, slotToFetch);
        if (blockData) { // Only add if blockData is not null
          fetchedBlocks.push(blockData);
        }
      }
      setSolanaBlocks(fetchedBlocks.sort((a, b) => b.slot - a.slot));
    } catch (err) {
      console.error("Failed to fetch Solana blocks:", err);
      // General error for the entire batch fetch, perhaps too many individual blocks failed or RPC is unstable.
      setError(`Failed to fetch Solana blocks. Some blocks might be malformed or the RPC is unstable. Details: ${err instanceof Error ? err.message : String(err)}`);
      setSolanaBlocks([]);
    } finally {
      setLoading(false);
    }
  }, [rpcUrls.solana]);

  useEffect(() => {
    // Reset state when chain changes
    setBscBlocks([]);
    setSolanaBlocks([]);
    setSelectedEVMBlock(null);
    setSelectedSolanaBlock(null);
    setSelectedSolanaTxSignature(null);
    latestFetchedBscBlockNumberRef.current = null;
    latestFetchedSolanaSlotRef.current = null;
    setError(null);
    setLoading(true);

    let intervalId: number; // Changed from NodeJS.Timeout

    if (selectedChain === 'bsc') {
      fetchBscBlocks();
      intervalId = setInterval(fetchBscBlocks, BLOCK_FETCH_INTERVAL_MS);
    } else { // selectedChain === 'solana'
      fetchSolanaBlocks();
      intervalId = setInterval(fetchSolanaBlocks, BLOCK_FETCH_INTERVAL_MS);
    }

    return () => clearInterval(intervalId);
  }, [selectedChain, fetchBscBlocks, fetchSolanaBlocks]);

  const handleRpcUrlChange = useCallback((newUrl: string) => {
    setRpcUrls((prev) => ({
      ...prev,
      [selectedChain]: newUrl,
    }));
    // Reset relevant states to trigger re-fetch for the new RPC
    setBscBlocks([]);
    setSolanaBlocks([]);
    setSelectedEVMBlock(null);
    setSelectedSolanaBlock(null);
    setSelectedSolanaTxSignature(null);
    latestFetchedBscBlockNumberRef.current = null;
    latestFetchedSolanaSlotRef.current = null;
    setError(null);
  }, [selectedChain]);

  const handleEVMBlockSelect = useCallback((block: EVMBlock) => {
    setSelectedEVMBlock(block);
  }, []);

  const handleCloseEVMBlockDetail = useCallback(() => {
    setSelectedEVMBlock(null);
  }, []);

  const handleSolanaBlockSelect = useCallback((block: SolanaBlock) => {
    setSelectedSolanaBlock(block);
  }, []);

  const handleCloseSolanaBlockDetail = useCallback(() => {
    setSelectedSolanaBlock(null);
  }, []);

  const handleSolanaTxSelect = useCallback((signature: string) => {
    setSelectedSolanaTxSignature(signature);
  }, []);

  const handleCloseSolanaTxDetail = useCallback(() => {
    setSelectedSolanaTxSignature(null);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center bg-gray-900 text-gray-50 p-4">
      <header className="w-full max-w-5xl text-center py-8 mb-8 bg-gray-800 rounded-lg shadow-xl">
        <h1 className="text-5xl font-extrabold text-emerald-400 mb-2 leading-tight">
          {selectedChain === 'bsc' ? 'BNB Smart Chain Explorer' : 'Solana Explorer'}
        </h1>
        <p className="text-xl text-gray-300 font-light mb-4">
          {selectedChain === 'bsc'
            ? "Real-time block scanning for the world's largest smart contract blockchain."
            : "Real-time block scanning for the high-performance Solana blockchain."}
        </p>

        {/* Chain Selector */}
        <div className="flex justify-center gap-4 mt-4">
          <button
            onClick={() => setSelectedChain('bsc')}
            className={`px-6 py-2 rounded-md font-semibold transition-colors duration-200 ${
              selectedChain === 'bsc'
                ? 'bg-emerald-600 text-white shadow-lg'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
            aria-pressed={selectedChain === 'bsc'}
          >
            BNB Smart Chain
          </button>
          <button
            onClick={() => setSelectedChain('solana')}
            className={`px-6 py-2 rounded-md font-semibold transition-colors duration-200 ${
              selectedChain === 'solana'
                ? 'bg-emerald-600 text-white shadow-lg'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
            aria-pressed={selectedChain === 'solana'}
          >
            Solana
          </button>
        </div>
      </header>

      <main className="w-full max-w-5xl flex-grow">
        <RpcUrlInput
          currentRpcUrl={currentRpcUrl}
          onRpcUrlChange={handleRpcUrlChange}
          chainName={selectedChain === 'bsc' ? 'BNB Smart Chain' : 'Solana'}
          placeholder={selectedChain === 'bsc' ? 'Enter custom BSC RPC URL (e.g., https://bsc-dataseed.binance.org/)' : 'Enter custom Solana RPC URL (e.g., https://api.devnet.solana.com for Devnet, or a dedicated RPC from Helius/Alchemy for Mainnet)'}
        />

        {error && <ErrorMessage message={error} />}

        {loading && <LoadingSpinner />}

        {!loading && !error && selectedChain === 'bsc' && bscBlocks.length === 0 && (
          <p className="text-center text-gray-400 text-lg mt-8">
            No blocks found or RPC is not responding for BNB Smart Chain. Please try a different RPC URL.
          </p>
        )}

        {!loading && !error && selectedChain === 'solana' && solanaBlocks.length === 0 && (
          <p className="text-center text-gray-400 text-lg mt-8">
            No blocks found or RPC is not responding for Solana. The default is Solana Devnet.
            For stable access to Solana Mainnet, public RPCs are often rate-limited or return "Access Forbidden".
            Consider using a dedicated RPC provider (e.g., Helius, Alchemy, QuickNode) with your own API key.
          </p>
        )}

        {!loading && selectedChain === 'bsc' && bscBlocks.length > 0 && (
          <EVMBlockList blocks={bscBlocks} onBlockSelect={handleEVMBlockSelect} />
        )}

        {!loading && selectedChain === 'solana' && solanaBlocks.length > 0 && (
          <SolanaBlockList blocks={solanaBlocks} onBlockSelect={handleSolanaBlockSelect} />
        )}
      </main>

      {selectedEVMBlock && selectedChain === 'bsc' && (
        <EVMBlockDetail block={selectedEVMBlock} onClose={handleCloseEVMBlockDetail} />
      )}

      {selectedSolanaBlock && selectedChain === 'solana' && (
        <SolanaBlockDetail block={selectedSolanaBlock} onClose={handleCloseSolanaBlockDetail} onSelectTransaction={handleSolanaTxSelect} />
      )}

      {selectedSolanaTxSignature && selectedChain === 'solana' && (
        <SolanaTransactionDetailModal rpcUrl={rpcUrls.solana} signature={selectedSolanaTxSignature} onClose={handleCloseSolanaTxDetail} />
      )}

      <footer className="w-full max-w-5xl text-center py-6 mt-8 border-t border-gray-700 text-gray-400 text-sm">
        Built with ❤️ for the blockchain community.
      </footer>
    </div>
  );
};

export default App;