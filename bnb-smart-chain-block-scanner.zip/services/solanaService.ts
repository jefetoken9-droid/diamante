import { Connection, BlockResponse, ParsedTransactionWithMeta, PublicKey, TransactionResponse, ParsedInstruction, ParsedInnerInstruction, PartiallyDecodedInstruction } from '@solana/web3.js';
import { SolanaBlock, SolanaTransactionDetails, TokenTransfer } from '../types';
import { DMT_TOKEN_ADDRESS, DMT_TOKEN_DECIMALS } from '../constants';

// Cache for Solana Connection instances
const connections: Record<string, Connection> = {};

/**
 * Establishes a Solana RPC connection, reusing existing connection if available.
 * @param rpcUrl The URL of the Solana RPC endpoint.
 * @returns A Connection object.
 */
const getConnection = (rpcUrl: string): Connection => {
  if (!connections[rpcUrl]) {
    connections[rpcUrl] = new Connection(rpcUrl, 'confirmed');
  }
  return connections[rpcUrl];
};

/**
 * Fetches the latest block slot from the Solana RPC.
 * @param rpcUrl The URL of the Solana RPC endpoint.
 * @returns A promise that resolves to the latest block slot number.
 */
export const getLatestSolanaBlockSlot = async (rpcUrl: string): Promise<number> => {
  const connection = getConnection(rpcUrl);
  try {
    return await connection.getSlot();
  } catch (error) {
    console.error('Failed to get latest Solana block slot:', error);
    throw error;
  }
};

/**
 * Fetches a Solana block by its slot number.
 * Note: For performance, this only fetches basic block info and transaction signatures.
 * Full transaction details must be fetched separately.
 * @param rpcUrl The URL of the Solana RPC endpoint.
 * @param slot The block slot number.
 * @returns A promise that resolves to a SolanaBlock object, or null if an error occurs.
 */
export const getSolanaBlock = async (rpcUrl: string, slot: number): Promise<SolanaBlock | null> => {
  const connection = getConnection(rpcUrl);
  try {
    const blockResponse: BlockResponse | null = await connection.getBlock(slot, {
      maxSupportedTransactionVersion: 0,
      rewards: true,
      transactionDetails: 'signatures', // Only fetch signatures for transactions
      commitment: 'confirmed',
    });

    if (!blockResponse) {
      console.warn(`Solana block ${slot} not found or no response.`);
      return null;
    }

    // Safely access transactions and signatures, handling potential undefined/null values
    const signatures = blockResponse.transactions
      ?.map(tx => tx.transaction?.signatures[0]) // Safely access tx.transaction and signatures[0]
      .filter((s): s is string => !!s) || []; // Filter out any undefined or null signatures

    return {
      slot: slot,
      blockhash: blockResponse.blockhash,
      parentSlot: blockResponse.parentSlot,
      blockTime: blockResponse.blockTime, // Unix timestamp in seconds
      blockHeight: blockResponse.blockHeight,
      signatures: signatures,
    };
  } catch (error) {
    console.error(`Failed to get Solana block ${slot}:`, error);
    // Return null on error, allowing the main fetch loop to continue for other blocks
    return null;
  }
};

/**
 * Fetches full details of a Solana transaction by its signature.
 * @param rpcUrl The URL of the Solana RPC endpoint.
 * @param signature The transaction signature (hash).
 * @returns A promise that resolves to a SolanaTransactionDetails object, or null if not found.
 */
export const getSolanaTransaction = async (rpcUrl: string, signature: string): Promise<SolanaTransactionDetails | null> => {
  const connection = getConnection(rpcUrl);
  try {
    const transactionResponse: TransactionResponse | null = await connection.getTransaction(signature, {
      maxSupportedTransactionVersion: 0,
      commitment: 'confirmed',
      encoding: 'jsonParsed', // Request parsed instruction data
    });

    if (!transactionResponse) {
      return null;
    }

    // Extract relevant data for SolanaTransactionDetails
    const { transaction, meta, slot, blockTime } = transactionResponse;
    const parsedTransaction = transaction as ParsedTransactionWithMeta; // Cast to Parsed type

    const tokenTransfers: TokenTransfer[] = [];

    // Process token balance changes to infer transfers
    if (meta?.postTokenBalances && meta?.preTokenBalances && parsedTransaction.message.accountKeys) {
        const accountKeysMap = new Map<string, string>(); // Map index to public key string
        parsedTransaction.message.accountKeys.forEach((key, index) => {
            if (typeof key === 'string') {
                accountKeysMap.set(index.toString(), key);
            } else {
                accountKeysMap.set(index.toString(), key.pubkey.toBase58());
            }
        });

        // Filter for SPL Token Program instructions, specifically 'transfer' or 'transferChecked'
        const innerInstructions = meta.innerInstructions || [];
        const allInstructions = [...parsedTransaction.message.instructions, ...innerInstructions.flatMap(ix => ix.instructions)];

        for (const ix of allInstructions) {
            if ('programId' in ix && ix.programId.toBase58() === 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5TT') {
                const parsedIx = ix as ParsedInstruction;
                if (parsedIx.parsed?.type === 'transfer' || parsedIx.parsed?.type === 'transferChecked') {
                    const info = parsedIx.parsed.info;
                    const mint = info.mint;
                    const amount = info.tokenAmount?.amount || info.amount; // Use tokenAmount for transferChecked, amount for transfer
                    const uiAmountString = info.tokenAmount?.uiAmountString || (parseFloat(amount) / (10 ** (info.decimals || 0))).toString();

                    tokenTransfers.push({
                        from: info.source,
                        to: info.destination,
                        mint: mint,
                        amount: amount,
                        uiAmountString: uiAmountString,
                        isDMT: mint === DMT_TOKEN_ADDRESS,
                    });
                }
            }
        }
    }


    return {
      signature: signature,
      slot: slot,
      blockTime: blockTime,
      fee: meta?.fee ?? 0,
      status: meta?.err ? 'Failed' : 'Success',
      logMessages: meta?.logMessages || [],
      accountKeys: parsedTransaction.message.accountKeys.map(key => typeof key === 'string' ? key : key.pubkey.toBase58()),
      instructions: parsedTransaction.message.instructions.map(ix => ({
        programId: typeof ix.programId === 'string' ? ix.programId : ix.programId.toBase58(),
        accounts: ix.accounts.map(acc => typeof acc === 'string' ? acc : acc.toBase58()),
        data: ix.data,
      })),
      tokenTransfers: tokenTransfers, // Include extracted token transfers
    };

  } catch (error) {
    console.error(`Failed to get Solana transaction ${signature}:`, error);
    throw error;
  }
};