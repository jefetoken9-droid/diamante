import { EVMBlock, RpcResponse } from '../types';

/**
 * Makes an RPC call to the specified URL.
 * @param rpcUrl The URL of the BSC RPC endpoint.
 * @param method The RPC method to call (e.g., "eth_blockNumber").
 * @param params An array of parameters for the RPC method.
 * @returns A promise that resolves to the RPC response result.
 * @throws An error if the RPC call fails or returns an error.
 */
export const callRpc = async <T>(rpcUrl: string, method: string, params: any[] = []): Promise<T> => {
  const requestBody = {
    jsonrpc: '2.0',
    method: method,
    params: params,
    id: 1,
  };

  try {
    const response = await fetch(rpcUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const jsonResponse: RpcResponse<T> = await response.json();

    if (jsonResponse.error) {
      throw new Error(`RPC Error (${jsonResponse.error.code}): ${jsonResponse.error.message}`);
    }

    return jsonResponse.result;
  } catch (error) {
    console.error(`Failed to call RPC method ${method}:`, error);
    throw error;
  }
};

/**
 * Fetches the latest block number from the BSC RPC.
 * @param rpcUrl The URL of the BSC RPC endpoint.
 * @returns A promise that resolves to the latest block number as a hexadecimal string.
 */
export const getLatestBlockNumber = async (rpcUrl: string): Promise<string> => {
  return callRpc<string>(rpcUrl, 'eth_blockNumber');
};

/**
 * Fetches a block by its number, optionally including full transaction objects.
 * @param rpcUrl The URL of the BSC RPC endpoint.
 * @param blockNumber The block number (hex string or "latest").
 * @param includeTransactions Whether to include full transaction objects (default: false).
 * @returns A promise that resolves to the EVMBlock object.
 */
export const getBlockByNumber = async (rpcUrl: string, blockNumber: string, includeTransactions: boolean = false): Promise<EVMBlock> => {
  return callRpc<EVMBlock>(rpcUrl, 'eth_getBlockByNumber', [blockNumber, includeTransactions]);
};