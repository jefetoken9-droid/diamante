
import { Component, signal, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LlmInferenceService } from './services/llm-inference.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrls: [], // Tailwind handles styles, so no need for a separate CSS file
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  private llmInferenceService = inject(LlmInferenceService);

  userPrompt = signal<string>('');
  response = signal<string>('');
  isLoading = signal<boolean>(false);
  error = signal<string | null>(null);

  // Available models based on the Python snippet provided
  availableModels = signal<string[]>([
    'deepseek',
    'nvidia',
    'mixtral',
    'meta'
  ]);
  selectedModel = signal<string>('deepseek'); // Default selected model

  async sendMessage() {
    const currentPrompt = this.userPrompt().trim();
    if (!currentPrompt) {
      this.error.set('Please enter a prompt.');
      return;
    }

    this.isLoading.set(true);
    this.error.set(null);
    this.response.set('');

    try {
      this.llmInferenceService.generateResponse(currentPrompt, this.selectedModel()).subscribe({
        next: (res) => {
          this.response.set(res);
          this.isLoading.set(false);
        },
        error: (err) => {
          console.error('Error during LLM inference:', err);
          this.error.set('Failed to get response from AI. Please try again.');
          this.isLoading.set(false);
        }
      });
    } catch (e) {
      console.error('Unexpected error:', e);
      this.error.set('An unexpected error occurred.');
      this.isLoading.set(false);
    }
  }

  // Clear input and response
  clear() {
    this.userPrompt.set('');
    this.response.set('');
    this.error.set(null);
    this.isLoading.set(false);
  }
}
    