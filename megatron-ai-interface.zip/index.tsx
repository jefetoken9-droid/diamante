

import { bootstrapApplication, provideProtractorTestingSupport } from '@angular/platform-browser';
import { AppComponent } from './src/app.component';
import { provideZonelessChangeDetection } from '@angular/core';

bootstrapApplication(AppComponent, {
  providers: [
    provideZonelessChangeDetection(),
    // Add any other global providers here if needed, e.g., provideRouter withHashLocation
    provideProtractorTestingSupport() // Recommended for Applet environment
  ]
}).catch(err => console.error(err));
    

// AI Studio always uses an `index.tsx` file for all project types.
