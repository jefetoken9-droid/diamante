export interface WalletState {
  connected: boolean;
  publicKey: string | null;
  balance: number;
  tokens: {
    [key: string]: number;
  };
  keypair?: any; // Storing the Solana Keypair object (for imported private keys)
  adapter?: any; // Storing the External Wallet Provider (e.g. Phantom window.solana)
  rpcEndpoint?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
}

export interface TradeData {
  time: string;
  price: number;
  volume: number;
}

export enum Tab {
  DASHBOARD = 'DASHBOARD',
  SWAP = 'SWAP',
  CHAT = 'CHAT',
  AIRDROP = 'AIRDROP'
}

export interface Token {
  symbol: string;
  name: string;
  address: string;
  decimals: number;
  logoURI?: string;
}

export interface PoolData {
  priceUsd: string;
  priceChange24h: string;
  volume24h: string;
  liquidity: string;
  marketCap: string;
  fdv: string;
  pairName: string;
}

export interface GoogleMarketData {
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
}

export interface GoogleFinanceState {
  marketTrends: GoogleMarketData[];
  news: { title: string; source: string; time: string }[];
}

// Database Types matching the SQL Schema
export type UserTier = 'bronze' | 'silver' | 'gold' | 'platinum';
export type KycStatus = 'pending' | 'verified' | 'rejected';

export interface UserProfile {
  id: string;
  walletAddress: string;
  tier: UserTier;
  kycStatus: KycStatus;
  totalAirdropUsd: number;
  claimedAirdropUsd: number;
  tokensPending: number;
}

export interface MercadoPagoAccount {
  connected: boolean;
  email: string | null;
  accessToken: string | null;
  balance: number;
  currency: string;
}

export interface BotStatus {
    active: boolean;
    mode: 'IDLE' | 'VOLUME_BOT' | 'SNIPER_SWARM' | 'GOD_CANDLE';
    txCount: number;
    volumeGenerated: number;
}