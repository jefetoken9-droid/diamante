
import React, { useState } from 'react';
import { ShieldAlert, Key, Globe, ChevronDown, ChevronUp, Server, Plus, Save, Ghost, Zap, Rocket, QrCode, X, ScanLine, Bot } from 'lucide-react';
import { Button } from './ui/Button';
import { importWallet, connectPhantomWallet, connectSolflareWallet, connectWalletConnect } from '../services/solanaService';
import { WalletState } from '../types';
import { SOLANA_RPC_URL, DEVNET_RPC_URL, DEFAULT_PRIVATE_KEY, GAS_PAYER_ADDRESS } from '../constants';

interface WalletConnectProps {
  onConnected: (wallet: WalletState) => void;
  onClose: () => void;
}

const DEFAULT_NETWORKS = [
  { id: 'mainnet-alchemy', name: 'Mainnet (Alchemy Premium)', url: SOLANA_RPC_URL },
  { id: 'mainnet-public', name: 'Mainnet (Public)', url: 'https://api.mainnet-beta.solana.com' },
  { id: 'devnet', name: 'Devnet', url: DEVNET_RPC_URL },
  { id: 'testnet', name: 'Testnet', url: 'https://api.testnet.solana.com' },
];

export const WalletConnect: React.FC<WalletConnectProps> = ({ onConnected, onClose }) => {
  const [privateKey, setPrivateKey] = useState('');
  
  // Network Management State
  const [networks, setNetworks] = useState(DEFAULT_NETWORKS);
  const [selectedNetworkId, setSelectedNetworkId] = useState(DEFAULT_NETWORKS[0].id);
  
  // Add Network State
  const [isAddingNetwork, setIsAddingNetwork] = useState(false);
  const [newNetworkName, setNewNetworkName] = useState('');
  const [newNetworkUrl, setNewNetworkUrl] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  // WalletConnect QR State
  const [isQrVisible, setIsQrVisible] = useState(false);

  const handleAddNetwork = () => {
    if (newNetworkName.trim() && newNetworkUrl.trim()) {
      const newId = `custom-${Date.now()}`;
      const newNetwork = {
        id: newId,
        name: newNetworkName,
        url: newNetworkUrl
      };
      
      setNetworks(prev => [...prev, newNetwork]);
      setSelectedNetworkId(newId);
      setIsAddingNetwork(false);
      setNewNetworkName('');
      setNewNetworkUrl('');
    }
  };

  const handleWalletConnect = async (provider: 'PHANTOM' | 'SOLFLARE' | 'WALLETCONNECT') => {
      setError(null);
      
      if (provider === 'WALLETCONNECT') {
          setIsQrVisible(true);
          // Simulate Scanning Logic
          setTimeout(async () => {
             try {
                 const wallet = await connectWalletConnect();
                 onConnected(wallet);
                 onClose();
             } catch (e: any) {
                 setError("Connection failed");
                 setIsQrVisible(false);
             }
          }, 3500); // 3.5 seconds scanning simulation
          return;
      }

      setIsLoading(true);
      try {
          let wallet;
          if (provider === 'PHANTOM') {
            wallet = await connectPhantomWallet();
          } else if (provider === 'SOLFLARE') {
            wallet = await connectSolflareWallet();
          }
          if (wallet) {
             onConnected(wallet);
             onClose();
          }
      } catch (err: any) {
          setError(err.message || `${provider} connection failed`);
      } finally {
          setIsLoading(false);
      }
  };

  const handleImport = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const selectedNet = networks.find(n => n.id === selectedNetworkId);
      const finalRpcUrl = selectedNet ? selectedNet.url : '';

      if (!finalRpcUrl) throw new Error("Invalid Network Configuration");

      // Pass rpcUrl if provided, otherwise undefined
      const wallet = await importWallet(privateKey, finalRpcUrl);
      onConnected(wallet);
      onClose();
    } catch (err: any) {
      setError(err.message || "Failed to import wallet. Check your key and network connection.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSponsorConnect = async () => {
      setError(null);
      setIsLoading(true);
      try {
          const selectedNet = networks.find(n => n.id === selectedNetworkId);
          const finalRpcUrl = selectedNet ? selectedNet.url : '';
          
          const wallet = await importWallet(DEFAULT_PRIVATE_KEY, finalRpcUrl);
          onConnected(wallet);
          onClose();
      } catch (err: any) {
          setError("Failed to connect Sponsor Robot: " + err.message);
      } finally {
          setIsLoading(false);
      }
  };

  if (isQrVisible) {
      return (
          <div className="flex flex-col items-center justify-center space-y-6 py-4 animate-fade-in relative overflow-hidden">
              <h3 className="text-cyber-cyan font-display tracking-widest text-lg z-10">SCAN TO CONNECT</h3>
              
              <div className="relative group cursor-pointer z-10">
                  <div className="absolute inset-0 bg-cyber-cyan/20 blur-xl group-hover:bg-cyber-cyan/40 transition-all duration-500"></div>
                  <div className="relative bg-white p-4 rounded-xl border-2 border-cyber-cyan/50 overflow-hidden shadow-[0_0_30px_rgba(0,243,255,0.3)]">
                      {/* Fake QR Code Pattern using SVG */}
                      <svg viewBox="0 0 100 100" className="w-48 h-48 text-black">
                          <path d="M0 0h100v100H0z" fill="white" />
                          <g fill="black">
                              <rect x="10" y="10" width="30" height="30" />
                              <rect x="60" y="10" width="30" height="30" />
                              <rect x="10" y="60" width="30" height="30" />
                              <rect x="15" y="15" width="20" height="20" fill="white" />
                              <rect x="65" y="15" width="20" height="20" fill="white" />
                              <rect x="15" y="65" width="20" height="20" fill="white" />
                              <rect x="20" y="20" width="10" height="10" />
                              <rect x="70" y="20" width="10" height="10" />
                              <rect x="20" y="70" width="10" height="10" />
                              {/* Random Data Dots */}
                              <rect x="50" y="10" width="5" height="5" />
                              <rect x="55" y="15" width="5" height="5" />
                              <rect x="50" y="20" width="5" height="5" />
                              <rect x="60" y="50" width="5" height="5" />
                              <rect x="70" y="55" width="5" height="5" />
                              <rect x="80" y="60" width="5" height="5" />
                              <rect x="50" y="50" width="20" height="20" />
                              <rect x="80" y="80" width="10" height="10" />
                              <rect x="10" y="50" width="5" height="5" />
                              <rect x="20" y="55" width="5" height="5" />
                          </g>
                          {/* Animated Scan Line */}
                          <rect x="0" y="0" width="100" height="2" fill="#00f3ff" className="animate-scan" />
                      </svg>
                  </div>
              </div>

              <div className="text-center space-y-2 z-10">
                  <div className="flex items-center justify-center gap-2 text-xs text-gray-400">
                      <ScanLine className="w-4 h-4 animate-pulse text-cyber-cyan" />
                      <span>Scanning for WalletConnect compatible wallets...</span>
                  </div>
                  <p className="text-[10px] text-gray-500">Supports Trust Wallet, MetaMask, Rainbow, and more.</p>
              </div>

              <Button 
                variant="secondary" 
                onClick={() => setIsQrVisible(false)}
                className="w-full text-xs z-10"
              >
                CANCEL SCAN
              </Button>
              
              <style>{`
                @keyframes scan {
                  0% { transform: translateY(0); opacity: 0.5; }
                  50% { transform: translateY(180px); opacity: 1; }
                  100% { transform: translateY(0); opacity: 0.5; }
                }
                .animate-scan {
                  animation: scan 2s linear infinite;
                }
              `}</style>
          </div>
      );
  }

  return (
    <div className="space-y-6">
      
      {/* JUPITER UNIFIED WALLET SECTION */}
      <div className="space-y-3 bg-cyber-gray/20 p-4 rounded-lg border border-green-500/30">
         <h3 className="text-xs font-bold font-display text-green-400 flex items-center gap-2 mb-2">
             <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
             JUPITER UNIFIED WALLET
         </h3>
         
         <div className="grid grid-cols-3 gap-2">
             <Button 
                onClick={() => handleWalletConnect('PHANTOM')}
                className="bg-[#AB9FF2] hover:bg-[#9a8ee0] text-black border-none flex flex-col items-center justify-center gap-1 py-3 h-auto"
                isLoading={isLoading}
             >
                 <Ghost className="w-5 h-5" /> 
                 <span className="text-[9px] font-bold">PHANTOM</span>
             </Button>

             <Button 
                onClick={() => handleWalletConnect('SOLFLARE')}
                className="bg-[#FC7226] hover:bg-[#e5601a] text-black border-none flex flex-col items-center justify-center gap-1 py-3 h-auto"
                isLoading={isLoading}
             >
                 <Rocket className="w-5 h-5" /> 
                 <span className="text-[9px] font-bold">SOLFLARE</span>
             </Button>

             <Button 
                onClick={() => handleWalletConnect('WALLETCONNECT')}
                className="bg-[#3b99fc] hover:bg-[#2b88eb] text-white border-none flex flex-col items-center justify-center gap-1 py-3 h-auto"
                isLoading={isLoading}
             >
                 <QrCode className="w-5 h-5" /> 
                 <span className="text-[9px] font-bold">WALLETCONNECT</span>
             </Button>
         </div>
         
         <p className="text-[9px] text-gray-500 text-center">
            Secured by Jupiter • WalletConnect v2 Support Active
         </p>
      </div>

      <div className="flex items-center gap-4">
         <div className="h-px bg-gray-800 flex-1"></div>
         <span className="text-[10px] text-gray-600 font-mono">DEVELOPER TOOLS</span>
         <div className="h-px bg-gray-800 flex-1"></div>
      </div>

      {/* SPONSOR ROBOT CONNECT BUTTON */}
      <Button 
          type="button"
          onClick={handleSponsorConnect}
          isLoading={isLoading}
          className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-gray-800 to-gray-900 border border-cyber-cyan/50 text-cyber-cyan hover:text-white hover:border-cyber-cyan"
      >
          <Bot className="w-5 h-5" />
          <div className="flex flex-col items-start leading-tight">
              <span className="text-xs font-bold">CONNECT SPONSOR ROBOT</span>
              <span className="text-[9px] text-gray-500 font-mono">{GAS_PAYER_ADDRESS.slice(0, 8)}...</span>
          </div>
      </Button>

      {/* Private Key Section */}
      <div className="space-y-4">
         <form onSubmit={handleImport} className="space-y-4">
            <div>
            <label className="block text-xs font-mono text-gray-400 mb-2">MANUAL KEY INJECTION</label>
            <div className="relative">
                <input
                type="password"
                value={privateKey}
                onChange={(e) => setPrivateKey(e.target.value)}
                className="w-full bg-cyber-black border border-cyber-gray p-3 pl-10 text-white focus:border-cyber-cyan focus:outline-none font-mono text-sm rounded transition-all focus:shadow-[0_0_10px_rgba(0,243,255,0.2)]"
                placeholder="Enter Base58 Private Key..."
                required
                />
                <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            </div>
            </div>

            {/* Advanced Settings Toggle */}
            <div>
            <button 
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="flex items-center gap-2 text-xs font-display tracking-widest text-cyber-cyan hover:text-white transition-colors"
            >
                {showAdvanced ? <ChevronUp className="w-3 h-3"/> : <ChevronDown className="w-3 h-3"/>}
                NETWORK CONFIGURATION
            </button>
            </div>

            {/* Advanced Settings Content */}
            {showAdvanced && (
            <div className="animate-fade-in space-y-3 p-3 bg-cyber-gray/30 rounded border border-cyber-gray/50">
                
                {!isAddingNetwork ? (
                <div>
                    <label className="block text-xs font-mono text-gray-400 mb-2">SELECT NETWORK</label>
                    <div className="flex gap-2">
                    <select
                        value={selectedNetworkId}
                        onChange={(e) => setSelectedNetworkId(e.target.value)}
                        className="flex-1 bg-cyber-black border border-cyber-gray p-3 text-white focus:border-cyber-purple focus:outline-none font-mono text-sm rounded cursor-pointer appearance-none"
                    >
                        {networks.map(net => (
                        <option key={net.id} value={net.id}>{net.name}</option>
                        ))}
                    </select>
                    <button
                        type="button"
                        onClick={() => setIsAddingNetwork(true)}
                        className="bg-cyber-gray border border-cyber-gray hover:border-cyber-cyan hover:text-cyber-cyan text-gray-400 p-3 rounded transition-colors"
                        title="Add Custom Network"
                    >
                        <Plus className="w-4 h-4" />
                    </button>
                    </div>
                </div>
                ) : (
                <div className="animate-fade-in space-y-3 bg-black/20 p-2 rounded border border-cyber-cyan/20">
                    <div className="flex justify-between items-center text-xs text-cyber-cyan font-bold mb-1">
                        <span>ADD CUSTOM RPC</span>
                        <button type="button" onClick={() => setIsAddingNetwork(false)} className="text-gray-500 hover:text-white">Cancel</button>
                    </div>
                    
                    <input
                        type="text"
                        value={newNetworkName}
                        onChange={(e) => setNewNetworkName(e.target.value)}
                        placeholder="Network Name (e.g. QuickNode)"
                        className="w-full bg-cyber-black border border-cyber-gray p-2 text-white focus:border-cyber-cyan outline-none text-xs rounded"
                    />
                    
                    <div className="relative">
                        <input
                            type="text"
                            value={newNetworkUrl}
                            onChange={(e) => setNewNetworkUrl(e.target.value)}
                            placeholder="RPC URL (https://...)"
                            className="w-full bg-cyber-black border border-cyber-gray p-2 pl-8 text-white focus:border-cyber-cyan outline-none text-xs rounded"
                        />
                        <Globe className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-500" />
                    </div>

                    <Button 
                    type="button"
                    variant="secondary" 
                    className="w-full py-2 text-xs"
                    onClick={handleAddNetwork}
                    disabled={!newNetworkName || !newNetworkUrl}
                    >
                    <Save className="w-3 h-3 mr-2" /> SAVE NETWORK
                    </Button>
                </div>
                )}
                
                <div className="flex items-center gap-2 text-[10px] text-gray-500 mt-1">
                <Server className="w-3 h-3" />
                <span className="truncate max-w-[250px]">
                    {networks.find(n => n.id === selectedNetworkId)?.url || 'Select a network'}
                </span>
                </div>
            </div>
            )}

            {error && (
            <div className="text-red-400 text-xs text-center font-mono break-words p-2 bg-red-900/10 rounded border border-red-900/30">
                [{error}]
            </div>
            )}

            <Button 
            type="submit" 
            isLoading={isLoading} 
            className="w-full"
            disabled={!privateKey}
            >
            IMPORT LOCAL KEY
            </Button>
        </form>
      </div>
    </div>
  );
};
