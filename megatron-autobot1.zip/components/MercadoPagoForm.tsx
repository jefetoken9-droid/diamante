import React, { useState, useEffect } from 'react';
import { CreditCard, Calendar, Lock, User, AlertCircle, CheckCircle } from 'lucide-react';
import { processPayment } from '../services/mockBackend';
import { handleMercadoPagoError } from '../services/mercadopagoService';
import { Button } from './ui/Button'; // Import Button component

interface MercadoPagoFormProps {
    amount: number;
    onSuccess: (id: string) => void;
    onCancel: () => void;
}

export const MercadoPagoForm: React.FC<MercadoPagoFormProps> = ({ amount, onSuccess, onCancel }) => {
    const [formData, setFormData] = useState({
        cardNumber: '',
        cardholderName: '',
        expirationDate: '',
        securityCode: '',
        email: 'test@example.com',
        installments: '1',
        docType: 'CPF',
        docNumber: ''
    });
    
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
        setError(null);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            // Basic Simulation of Token Generation (usually handled by SDK)
            const token = `tok_${Date.now()}`;
            
            const paymentData = {
                transaction_amount: amount,
                token,
                description: "Megatron Token Purchase",
                installments: Number(formData.installments),
                payment_method_id: "visa",
                issuer_id: "visa",
                payer: {
                    email: formData.email,
                    identification: {
                        type: formData.docType,
                        number: formData.docNumber
                    }
                }
            };

            const response = await processPayment(paymentData);

            if (response.success) {
                onSuccess(response.paymentId);
            } else {
                throw response; // Throw to catch block to use handler
            }

        } catch (err: any) {
            const formattedError = handleMercadoPagoError(err);
            setError(formattedError.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto text-gray-800">
            <div className="flex justify-between items-center mb-6 border-b pb-4">
                <h3 className="text-xl font-bold text-[#009ee3] flex items-center gap-2">
                    <CreditCard className="w-6 h-6" /> Add Card
                </h3>
                <span className="bg-[#009ee3]/10 text-[#009ee3] text-xs font-bold px-2 py-1 rounded">
                    ${amount.toFixed(2)} USD
                </span>
            </div>

            <form id="form-checkout" onSubmit={handleSubmit} className="flex flex-col gap-4">
                {/* Card Number */}
                <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1">Card Number</label>
                    <div className="relative">
                        <input 
                            type="text" 
                            name="cardNumber"
                            value={formData.cardNumber}
                            onChange={handleInputChange}
                            placeholder="0000 0000 0000 0000"
                            maxLength={19}
                            className="w-full p-2.5 border border-gray-300 rounded focus:border-[#009ee3] focus:ring-2 focus:ring-[#009ee3]/20 outline-none transition pl-10"
                            required
                        />
                        <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    </div>
                </div>

                {/* Cardholder Name */}
                <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1">Cardholder Name</label>
                    <div className="relative">
                        <input 
                            type="text" 
                            name="cardholderName"
                            value={formData.cardholderName}
                            onChange={handleInputChange}
                            placeholder="YOUR NAME"
                            className="w-full p-2.5 border border-gray-300 rounded focus:border-[#009ee3] focus:ring-2 focus:ring-[#009ee3]/20 outline-none transition pl-10"
                            required
                        />
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    </div>
                </div>

                <div className="flex gap-4">
                    {/* Expiration Date */}
                    <div className="flex-1">
                        <label className="text-xs font-semibold text-gray-600 mb-1">Expiration</label>
                        <div className="relative">
                            <input 
                                type="text" 
                                name="expirationDate"
                                value={formData.expirationDate}
                                onChange={handleInputChange}
                                placeholder="MM/YY"
                                maxLength={5}
                                className="w-full p-2.5 border border-gray-300 rounded focus:border-[#009ee3] focus:ring-2 focus:ring-[#009ee3]/20 outline-none transition pl-10"
                                required
                            />
                            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        </div>
                    </div>

                    {/* Security Code */}
                    <div className="flex-1">
                        <label className="text-xs font-semibold text-gray-600 mb-1">CVV</label>
                        <div className="relative">
                            <input 
                                type="text" 
                                name="securityCode"
                                value={formData.securityCode}
                                onChange={handleInputChange}
                                placeholder="123"
                                maxLength={4}
                                className="w-full p-2.5 border border-gray-300 rounded focus:border-[#009ee3] focus:ring-2 focus:ring-[#009ee3]/20 outline-none transition pl-10"
                                required
                            />
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        </div>
                    </div>
                </div>

                {/* Document */}
                <div className="flex gap-4">
                    <div className="w-1/3">
                        <label className="text-xs font-semibold text-gray-600 mb-1">Type</label>
                        <select 
                            name="docType" 
                            value={formData.docType}
                            onChange={handleInputChange}
                            className="w-full p-2.5 border border-gray-300 rounded focus:border-[#009ee3] focus:ring-2 focus:ring-[#009ee3]/20 outline-none bg-white"
                        >
                            <option value="CPF">CPF</option>
                            <option value="CNPJ">CNPJ</option>
                        </select>
                    </div>
                    <div className="flex-1">
                        <label className="text-xs font-semibold text-gray-600 mb-1">Document Number</label>
                        <input 
                            type="text" 
                            name="docNumber"
                            value={formData.docNumber}
                            onChange={handleInputChange}
                            className="w-full p-2.5 border border-gray-300 rounded focus:border-[#009ee3] focus:ring-2 focus:ring-[#009ee3]/20 outline-none"
                            required
                        />
                    </div>
                </div>

                {/* Installments */}
                <div>
                     <label className="text-xs font-semibold text-gray-600 mb-1">Installments</label>
                     <select 
                        name="installments" 
                        value={formData.installments}
                        onChange={handleInputChange}
                        className="w-full p-2.5 border border-gray-300 rounded focus:border-[#009ee3] focus:ring-2 focus:ring-[#009ee3]/20 outline-none bg-white"
                     >
                         <option value="1">1x of ${(amount).toFixed(2)}</option>
                         <option value="3">3x of ${(amount/3).toFixed(2)}</option>
                         <option value="6">6x of ${(amount/6).toFixed(2)}</option>
                         <option value="12">12x of ${(amount/12).toFixed(2)}</option>
                     </select>
                </div>

                {error && (
                    <div className="flex items-start gap-2 text-sm text-[#d32f2f] bg-[#ffebee] p-3 rounded border border-[#ffcdd2]">
                        <AlertCircle className="w-5 h-5 flex-shrink-0" />
                        <span>{error}</span>
                    </div>
                )}

                <div className="mt-2 space-y-2">
                    <Button 
                        type="submit" 
                        isLoading={loading} 
                        className="w-full bg-[#009ee3] text-white hover:bg-[#009ee3]/80 border-none" // Custom style for MP brand color
                    >
                        Pay Now
                    </Button>
                    <Button 
                        type="button" 
                        variant="ghost" // Using ghost variant for cancel button
                        onClick={onCancel}
                        className="w-full"
                    >
                        Cancel
                    </Button>
                </div>
            </form>
            
            <div className="mt-4 flex items-center justify-center gap-2 text-[10px] text-gray-400">
                <Lock className="w-3 h-3" />
                Payments processed securely by Mercado Pago
            </div>
        </div>
    );
};