import React, { useState, useEffect } from 'react';
import { Bot, Zap, TrendingUp, Activity, Power, Crosshair } from 'lucide-react';
import { Card } from './ui/Card';
import { BotStatus } from '../types';

interface BotControlPanelProps {
    botStatus: BotStatus;
    setBotStatus: (status: BotStatus) => void;
}

export const BotControlPanel: React.FC<BotControlPanelProps> = ({ botStatus, setBotStatus }) => {
    
    const toggleBot = (mode: BotStatus['mode']) => {
        if (botStatus.active && botStatus.mode === mode) {
            // Stop
            setBotStatus({ ...botStatus, active: false, mode: 'IDLE' });
        } else {
            // Start
            setBotStatus({ ...botStatus, active: true, mode: mode });
        }
    };

    return (
        <Card title="AUTOTRADER BOTNET CONTROL" className="border-cyber-green/30">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* VOLUME BOTS */}
                <button 
                    onClick={() => toggleBot('VOLUME_BOT')}
                    className={`relative p-4 rounded border flex flex-col items-center gap-2 transition-all overflow-hidden group ${
                        botStatus.mode === 'VOLUME_BOT' 
                        ? 'bg-blue-900/40 border-blue-400 shadow-[0_0_20px_rgba(96,165,250,0.5)]' 
                        : 'bg-cyber-black/50 border-gray-700 hover:border-blue-400/50'
                    }`}
                >
                    <div className="flex items-center gap-2">
                        <Activity className={`w-6 h-6 ${botStatus.mode === 'VOLUME_BOT' ? 'text-blue-400 animate-pulse' : 'text-gray-500'}`} />
                        <span className={`font-display font-bold ${botStatus.mode === 'VOLUME_BOT' ? 'text-blue-400' : 'text-gray-400'}`}>VOLUME BOTS</span>
                    </div>
                    <div className="text-[10px] text-gray-500 text-center">
                        Generates wash trading to spike 24h volume stats.
                    </div>
                    {botStatus.mode === 'VOLUME_BOT' && (
                        <div className="absolute inset-0 bg-blue-400/5 animate-pulse"></div>
                    )}
                </button>

                {/* SNIPER SWARM */}
                <button 
                    onClick={() => toggleBot('SNIPER_SWARM')}
                    className={`relative p-4 rounded border flex flex-col items-center gap-2 transition-all overflow-hidden group ${
                        botStatus.mode === 'SNIPER_SWARM' 
                        ? 'bg-yellow-900/40 border-yellow-400 shadow-[0_0_20px_rgba(250,204,21,0.5)]' 
                        : 'bg-cyber-black/50 border-gray-700 hover:border-yellow-400/50'
                    }`}
                >
                    <div className="flex items-center gap-2">
                        <Crosshair className={`w-6 h-6 ${botStatus.mode === 'SNIPER_SWARM' ? 'text-yellow-400 animate-spin-slow' : 'text-gray-500'}`} />
                        <span className={`font-display font-bold ${botStatus.mode === 'SNIPER_SWARM' ? 'text-yellow-400' : 'text-gray-400'}`}>SNIPER SWARM</span>
                    </div>
                    <div className="text-[10px] text-gray-500 text-center">
                        Deploys 500+ wallets to micro-buy and hold floor.
                    </div>
                    {botStatus.mode === 'SNIPER_SWARM' && (
                        <div className="absolute inset-0 bg-yellow-400/5 animate-pulse"></div>
                    )}
                </button>

                {/* GOD CANDLE */}
                <button 
                    onClick={() => toggleBot('GOD_CANDLE')}
                    className={`relative p-4 rounded border flex flex-col items-center gap-2 transition-all overflow-hidden group ${
                        botStatus.mode === 'GOD_CANDLE' 
                        ? 'bg-green-900/40 border-green-500 shadow-[0_0_20px_rgba(74,222,128,0.8)]' 
                        : 'bg-cyber-black/50 border-gray-700 hover:border-green-500/50'
                    }`}
                >
                    <div className="flex items-center gap-2">
                        <Zap className={`w-6 h-6 ${botStatus.mode === 'GOD_CANDLE' ? 'text-green-500 animate-bounce' : 'text-gray-500'}`} />
                        <span className={`font-display font-bold ${botStatus.mode === 'GOD_CANDLE' ? 'text-green-500' : 'text-gray-400'}`}>GOD CANDLE</span>
                    </div>
                    <div className="text-[10px] text-gray-500 text-center">
                        Massive liquidity injection. Target: Gecko #1.
                    </div>
                    {botStatus.mode === 'GOD_CANDLE' && (
                        <div className="absolute inset-0 bg-green-500/10 animate-pulse"></div>
                    )}
                </button>
            </div>

            {/* LIVE METRICS */}
            <div className="mt-4 bg-black/40 p-3 rounded border border-gray-800 flex justify-between items-center font-mono text-xs">
                <div className="flex items-center gap-2">
                    <Power className={`w-4 h-4 ${botStatus.active ? 'text-green-500' : 'text-red-500'}`} />
                    <span className={botStatus.active ? 'text-green-500' : 'text-red-500'}>
                        STATUS: {botStatus.active ? 'ONLINE' : 'OFFLINE'}
                    </span>
                </div>
                <div>
                    TX/s: <span className="text-white">{botStatus.active ? Math.floor(Math.random() * 50) + 20 : 0}</span>
                </div>
                <div>
                    VOL GEN: <span className="text-cyber-cyan">${botStatus.volumeGenerated.toLocaleString()}</span>
                </div>
            </div>
        </Card>
    );
};