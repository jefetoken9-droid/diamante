import React, { useState } from 'react';
import { Button } from './ui/Button';
import { MercadoPagoAccount } from '../types';
import { connectMercadoPagoAccount } from '../services/mercadopagoService';
import { Wallet, LogIn, Lock } from 'lucide-react';

interface MercadoPagoConnectProps {
  onConnect: (account: MercadoPagoAccount) => void;
  onClose: () => void;
}

export const MercadoPagoConnect: React.FC<MercadoPagoConnectProps> = ({ onConnect, onClose }) => {
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const account = await connectMercadoPagoAccount(email, token);
      onConnect(account);
      onClose();
    } catch (err: any) {
      setError("Connection failed. Check credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-4 p-4 bg-[#009ee3]/10 border border-[#009ee3] rounded-lg">
        <Wallet className="w-8 h-8 text-[#009ee3]" />
        <div>
           <h3 className="text-[#009ee3] font-bold font-display">MERCADO PAGO CONNECT</h3>
           <p className="text-xs text-gray-400">Import your account to manage fiat balance.</p>
        </div>
      </div>

      <form onSubmit={handleConnect} className="space-y-4">
        <div>
          <label className="text-xs text-gray-400 block mb-1">MP Email Account</label>
          <input 
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-cyber-black border border-cyber-gray rounded p-2 text-white focus:border-[#009ee3] outline-none"
            placeholder="user@example.com"
            required
          />
        </div>

        <div>
          <label className="text-xs text-gray-400 block mb-1">Access Token (Prod/Test)</label>
          <div className="relative">
            <input 
                type="password"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="w-full bg-cyber-black border border-cyber-gray rounded p-2 pl-8 text-white focus:border-[#009ee3] outline-none"
                placeholder="APP_USR-xxxxxxxxxxxx"
                required
            />
            <Lock className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" />
          </div>
          <p className="text-[10px] text-gray-600 mt-1">We do not store your tokens. Used for session only.</p>
        </div>

        {error && <div className="text-red-400 text-xs">{error}</div>}

        <Button type="submit" isLoading={loading} className="w-full bg-[#009ee3] text-white hover:bg-[#009ee3]/80 border-none">
           <LogIn className="w-4 h-4 mr-2" /> LINK ACCOUNT
        </Button>
      </form>
    </div>
  );
};
