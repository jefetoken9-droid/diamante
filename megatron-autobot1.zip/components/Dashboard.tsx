
import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar } from 'recharts';
import { Send, Activity, Map, Search, Terminal, TrendingUp, TrendingDown, Droplets, DollarSign, Globe, Newspaper, Zap, Fuel, CreditCard, ExternalLink, ArrowDownUp, RefreshCw, LogOut, Wallet, Code, Database, Coins, Crosshair, Lock, AlertTriangle, PlusCircle, MinusCircle, Copy, CheckCircle } from 'lucide-react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { Modal } from './ui/Modal';
import { TransferInterface } from './TransferInterface';
import { WalletState, PoolData, TradeData, GoogleFinanceState, MercadoPagoAccount, BotStatus } from '../types';
import { fetchGoogleFinance } from '../services/googleFinanceService';
import { DEEPSEEK_TOKEN_ADDRESS, DIAMOND_TOKEN_ADDRESS, SLOP_TOKEN_ADDRESS, USDC_TOKEN_ADDRESS, DEEPSEEK_PRICE_USD, DIAMOND_PRICE_USD, SLOP_PRICE_USD, SOL_PRICE_USD, USDC_PRICE_USD, EXTERNAL_LINKS, POOL_ADDRESS } from '../constants';
import { renderPayoutInterface, renderDepositInstructions, createMercadoPagoOrder } from '../services/mercadopagoService';
import { openMoonPayWidget, openMoonPayWithdrawal } from '../services/moonpayService';
import { recordWithdrawal } from '../services/mockBackend';
import { executeAutofaderStrategy, createStakeAccount, executeSellAllStrategy } from '../services/solanaService';
import { MercadoPagoForm } from './MercadoPagoForm';
import { MercadoPagoConnect } from './MercadoPagoConnect';
import { BotControlPanel } from './BotControlPanel';
import { DeveloperCLI } from './DeveloperCLI';

interface DashboardProps {
  wallet: WalletState;
  poolData: PoolData | null;
  chartData: TradeData[];
  onTxSuccess?: () => void;
  botStatus: BotStatus;
  setBotStatus: (status: BotStatus) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ wallet, poolData, chartData, onTxSuccess, botStatus, setBotStatus }) => {
  const [isTransferOpen, setIsTransferOpen] = useState(false);
  const [isFiatOpen, setIsFiatOpen] = useState(false);
  const [isMpConnectOpen, setIsMpConnectOpen] = useState(false);
  const [isLiquidateModalOpen, setIsLiquidateModalOpen] = useState(false);
  const [isCliOpen, setIsCliOpen] = useState(false);
  
  const [mpAccount, setMpAccount] = useState<MercadoPagoAccount>({
      connected: false, email: null, accessToken: null, balance: 0, currency: 'MXN'
  });

  const [fiatProvider, setFiatProvider] = useState<'MERCADO_PAGO' | 'MOONPAY' | 'STRIPE'>('MERCADO_PAGO');
  const [fiatMode, setFiatMode] = useState<'DEPOSIT' | 'WITHDRAW'>('DEPOSIT');
  const [googleData, setGoogleData] = useState<GoogleFinanceState | null>(null);
  const [processingWithdrawal, setProcessingWithdrawal] = useState(false);
  const [paymentSuccessId, setPaymentSuccessId] = useState<string | null>(null);
  const [isExecLoading, setIsExecLoading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  
  const [autoSwapConfig, setAutoSwapConfig] = useState({ enabled: true, targetPrice: 2.00, percentage: 75 });
  const [hasAutoSwapped, setHasAutoSwapped] = useState(false);

  const loading = !poolData;
  const diamondBalance = wallet.tokens[DIAMOND_TOKEN_ADDRESS] || 0;
  const slopBalance = wallet.tokens[SLOP_TOKEN_ADDRESS] || 0;
  const usdcBalance = wallet.tokens[USDC_TOKEN_ADDRESS] || 0;
  
  const livePrice = poolData ? parseFloat(poolData.priceUsd) : DIAMOND_PRICE_USD;
  const priceChange = poolData ? parseFloat(poolData.priceChange24h) : 0;

  useEffect(() => {
    const loadGlobalMarkets = async () => {
        const data = await fetchGoogleFinance();
        if (data) setGoogleData(data);
    };
    loadGlobalMarkets();
  }, []);

  // --- ROBOT AUTOFADER EFFECT ---
  useEffect(() => {
      let interval: ReturnType<typeof setInterval>;
      if (botStatus.active) {
          interval = setInterval(async () => {
              try {
                  if (wallet.connected) {
                    const intensity = botStatus.mode === 'GOD_CANDLE' ? 5 : 1;
                    const result = await executeAutofaderStrategy(wallet, intensity);
                    
                    if (result.success) {
                        setBotStatus(prev => ({
                            ...prev,
                            txCount: prev.txCount + 1,
                            volumeGenerated: prev.volumeGenerated + (intensity * 100)
                        }));
                    } 
                  }
              } catch (e) { }
          }, 5000);
      }
      return () => {
          if (interval) clearInterval(interval);
      };
  }, [botStatus.active, wallet.connected]);

  // --- AUTO-SELL EXECUTION LOGIC ---
  useEffect(() => {
      if (autoSwapConfig.enabled && !hasAutoSwapped && livePrice >= autoSwapConfig.targetPrice && wallet.connected) {
          const runAutoSell = async () => {
              if (autoSwapConfig.percentage >= 99) {
                  setIsExecLoading(true);
                  try {
                      const result = await executeSellAllStrategy(wallet);
                      if (result.success) {
                          alert(`AUTO-PROFIT EXECUTED: ${result.message}`);
                          setHasAutoSwapped(true);
                          if (onTxSuccess) onTxSuccess();
                      }
                  } catch (e) { } finally {
                      setIsExecLoading(false);
                  }
              }
          };
          runAutoSell();
      }
  }, [livePrice, autoSwapConfig, hasAutoSwapped, wallet]);

  const handleSellAll = async () => {
      if (!wallet.connected) return;
      setIsExecLoading(true);
      try {
          const result = await executeSellAllStrategy(wallet);
          alert(result.message);
          if (result.success && onTxSuccess) onTxSuccess();
      } catch (e: any) {
          alert(`Error: ${e.message}`);
      } finally {
          setIsExecLoading(false);
      }
  }

  const confirmLiquidation = async () => {
      if (!wallet.connected) return;
      setIsExecLoading(true);
      try {
          const result = await executeSellAllStrategy(wallet);
          setIsLiquidateModalOpen(false);
          alert(result.message);
          if (result.success && onTxSuccess) onTxSuccess();
      } catch (e: any) {
          setIsLiquidateModalOpen(false);
          alert(`Error: ${e.message}`);
      } finally {
          setIsExecLoading(false);
      }
  };

  const handleMPWithdrawal = async () => {
      if(!wallet.publicKey) return;
      setProcessingWithdrawal(true);
      try {
          if (mpAccount.connected) {
              await createMercadoPagoOrder(mpAccount, 1000, 'WITHDRAWAL');
          }
          await recordWithdrawal(wallet.publicKey, 'MERCADOPAGO', wallet.balance * SOL_PRICE_USD, 'SPEI Transfer to CLABE');
          alert(`Withdrawal Processed Successfully! Funds sent via SPEI.`);
          setIsFiatOpen(false);
      } catch(e: any) {
          alert("Error processing MP Withdrawal: " + e.message);
      } finally {
          setProcessingWithdrawal(false);
      }
  };

  const handleMPSuccess = async (id: string) => {
      setPaymentSuccessId(id);
      if (mpAccount.connected) {
          try {
             await createMercadoPagoOrder(mpAccount, 1000, 'DEPOSIT');
          } catch (e) { console.error("Failed to sync order with MP Account", e); }
      }
      setTimeout(() => {
          setIsFiatOpen(false);
          setPaymentSuccessId(null);
          alert(`Payment Approved! ID: ${id}. Tokens will be credited shortly.`);
      }, 2000);
  };

  const handleMoonPayWithdrawal = () => {
      if(!wallet.publicKey) return;
      recordWithdrawal(wallet.publicKey, 'MOONPAY', wallet.balance * SOL_PRICE_USD, 'MoonPay Sell Flow');
      openMoonPayWithdrawal(wallet.publicKey);
  };

  const handleStakeCreation = async () => {
      if(!wallet.connected) return;
      setIsExecLoading(true);
      try {
          const result = await createStakeAccount(wallet);
          if (result.success) {
              alert(result.message);
              if(onTxSuccess) onTxSuccess();
          } else {
              console.log("Stake creation skipped: " + result.message);
          }
      } catch(e: any) { } finally {
          setIsExecLoading(false);
      }
  };

  const handleBuySol = () => {
      setFiatMode('DEPOSIT');
      setIsFiatOpen(true);
  };

  const copyToClipboard = (text: string, label: string) => {
      navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(null), 2000);
  };

  useEffect(() => {
    if (isFiatOpen && fiatProvider === 'MERCADO_PAGO') {
        if (fiatMode === 'WITHDRAW') {
            setTimeout(() => {
                renderPayoutInterface('wallet_brick_container', wallet.balance, handleMPWithdrawal);
            }, 100);
        } else if (fiatMode === 'DEPOSIT' && !paymentSuccessId) {
             setTimeout(() => {
                renderDepositInstructions('mp_deposit_instructions');
            }, 100);
        }
    }
  }, [isFiatOpen, fiatProvider, fiatMode, wallet.balance, paymentSuccessId]);

  return (
    <div className="space-y-6 animate-fade-in">
      <Modal isOpen={isLiquidateModalOpen} onClose={() => setIsLiquidateModalOpen(false)} title="CONFIRM LIQUIDATION">
         <div className="space-y-4 p-2">
            <div className="flex items-center gap-3 text-red-500 bg-red-900/20 p-3 rounded border border-red-500/50">
                <AlertTriangle className="w-6 h-6" />
                <span className="font-bold text-sm">WARNING: IRREVERSIBLE ACTION</span>
            </div>
            <p className="text-gray-300 text-sm">
                You are about to sell your entire position of <strong>{diamondBalance.toLocaleString()} DMT</strong> at market price.
            </p>
            <div className="flex gap-3 pt-2">
                <Button variant="secondary" onClick={() => setIsLiquidateModalOpen(false)} className="flex-1 text-xs">CANCEL</Button>
                <Button variant="danger" onClick={confirmLiquidation} isLoading={isExecLoading} className="flex-1 text-xs">CONFIRM LIQUIDATION</Button>
            </div>
         </div>
      </Modal>

      <Modal isOpen={isTransferOpen} onClose={() => setIsTransferOpen(false)} title="INITIATE TRANSFER (MAINNET)">
        <TransferInterface wallet={wallet} onClose={() => setIsTransferOpen(false)} onSuccess={() => { if(onTxSuccess) onTxSuccess(); }} />
      </Modal>

      <Modal isOpen={isMpConnectOpen} onClose={() => setIsMpConnectOpen(false)} title="MERCADO PAGO LINK">
         <MercadoPagoConnect onClose={() => setIsMpConnectOpen(false)} onConnect={(account) => setMpAccount(account)} />
      </Modal>

      <Modal isOpen={isFiatOpen} onClose={() => setIsFiatOpen(false)} title="GLOBAL FIAT GATEWAY">
         <div className="space-y-4">
            <div className="flex bg-black p-1 rounded-lg border border-gray-800">
                <button onClick={() => setFiatMode('DEPOSIT')} className={`flex-1 py-2 text-xs font-bold rounded transition-all ${fiatMode === 'DEPOSIT' ? 'bg-green-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}>BUY / DEPOSIT</button>
                <button onClick={() => setFiatMode('WITHDRAW')} className={`flex-1 py-2 text-xs font-bold rounded transition-all ${fiatMode === 'WITHDRAW' ? 'bg-red-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}>SELL / WITHDRAW</button>
            </div>
            <div className="flex gap-2 p-1 bg-cyber-gray rounded overflow-x-auto">
                <button onClick={() => setFiatProvider('MERCADO_PAGO')} className={`flex-1 whitespace-nowrap px-4 py-2 text-xs font-bold rounded transition-colors ${fiatProvider === 'MERCADO_PAGO' ? 'bg-cyber-cyan text-black' : 'text-gray-400 hover:text-white'}`}>MERCADO PAGO (SPEI)</button>
                <button onClick={() => setFiatProvider('MOONPAY')} className={`flex-1 whitespace-nowrap px-4 py-2 text-xs font-bold rounded transition-colors ${fiatProvider === 'MOONPAY' ? 'bg-cyber-purple text-white' : 'text-gray-400 hover:text-white'}`}>MOONPAY</button>
            </div>
            {fiatProvider === 'MERCADO_PAGO' ? (
                <div id="wallet_brick_container" className="min-h-[200px] flex flex-col items-center justify-center">
                    {fiatMode === 'DEPOSIT' ? (
                        paymentSuccessId ? (
                            <div className="text-center p-8 bg-green-900/20 rounded border border-green-500">
                                <div className="text-green-500 font-bold text-xl mb-2">PAYMENT APPROVED</div>
                                <div className="text-sm text-gray-300">Transaction ID: {paymentSuccessId}</div>
                            </div>
                        ) : (
                            <>
                                <MercadoPagoForm amount={100} onSuccess={handleMPSuccess} onCancel={() => setIsFiatOpen(false)} />
                                <div id="mp_deposit_instructions" className="w-full"></div>
                            </>
                        )
                    ) : null}
                </div>
            ) : (
                <div className="bg-opacity-10 border p-6 rounded text-center space-y-4">
                     <h3 className="text-white font-display">{fiatMode === 'DEPOSIT' ? 'BUY SOLANA' : 'CASH OUT TO VISA'}</h3>
                    <Button onClick={() => fiatMode === 'DEPOSIT' ? openMoonPayWidget(wallet.publicKey || '') : handleMoonPayWithdrawal()} className={`w-full text-white ${fiatMode === 'DEPOSIT' ? 'bg-green-600 hover:bg-green-500' : 'bg-red-600 hover:bg-red-500'}`} disabled={!wallet.connected}>
                        {wallet.connected ? `LAUNCH ${fiatMode} WIDGET` : 'CONNECT WALLET FIRST'} <ExternalLink className="w-4 h-4 ml-2 inline" />
                    </Button>
                </div>
            )}
         </div>
      </Modal>

      <div className="flex items-center justify-between text-xs font-mono bg-cyber-dark border border-cyber-gray p-2 rounded">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${poolData ? 'bg-green-400' : 'bg-yellow-400'}`}></span>
            <span className={`relative inline-flex rounded-full h-2 w-2 ${poolData ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
          </span>
          <span className={poolData ? "text-green-500 font-bold" : "text-yellow-500"}>
            {poolData ? "ALCHEMY RPC: ACTIVE" : "ESTABLISHING UPLINK..."}
          </span>
        </div>
        <div className="flex items-center gap-4">
             <button onClick={() => setIsMpConnectOpen(true)} className={`flex items-center gap-1 transition-colors hover:text-white ${mpAccount.connected ? 'text-[#009ee3]' : 'text-gray-500'}`}>
                 <Wallet className="w-3 h-3" />
                 <span>{mpAccount.connected ? `MP: ${mpAccount.currency} $${mpAccount.balance}` : 'LINK MERCADO PAGO'}</span>
             </button>
             <a href={EXTERNAL_LINKS.GOOGLE_FINANCE} target="_blank" rel="noopener noreferrer" className={`flex items-center gap-1 hover:text-white transition-colors ${googleData ? 'text-blue-400' : 'text-gray-600'}`}>
                <Globe className="w-3 h-3" />
                <span>{googleData ? 'FINANCE: LINKED' : 'FINANCE: SYNCING'}</span>
             </a>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {/* External Links Buttons kept same as before */}
        <a href={EXTERNAL_LINKS.PUMP_FUN} target="_blank" rel="noopener noreferrer" className="block md:col-span-1 col-span-2">
          <Button variant="primary" className="w-full flex items-center justify-center gap-2 text-xs md:text-sm bg-green-500 text-black border-none hover:bg-green-400">
            <Zap className="w-3 h-3 md:w-4 md:h-4 fill-black" /> PUMP.FUN
          </Button>
        </a>
        <a href={EXTERNAL_LINKS.PHOTON} target="_blank" rel="noopener noreferrer" className="block"><Button variant="secondary" className="w-full flex items-center justify-center gap-2 border-cyber-green text-cyber-green hover:bg-cyber-green/10 text-xs md:text-sm"><Activity className="w-3 h-3 md:w-4 md:h-4" /> PHOTON</Button></a>
        <a href={EXTERNAL_LINKS.BUBBLEMAPS} target="_blank" rel="noopener noreferrer" className="block"><Button variant="secondary" className="w-full flex items-center justify-center gap-2 border-pink-500 text-pink-500 hover:bg-pink-500/10 text-xs md:text-sm"><Map className="w-3 h-3 md:w-4 md:h-4" /> BUBBLEMAPS</Button></a>
        <a href={EXTERNAL_LINKS.SOLSCAN} target="_blank" rel="noopener noreferrer" className="block"><Button variant="secondary" className="w-full flex items-center justify-center gap-2 border-blue-400 text-blue-400 hover:bg-blue-400/10 text-xs md:text-sm"><Search className="w-3 h-3 md:w-4 md:h-4" /> SOLSCAN</Button></a>
        <a href={EXTERNAL_LINKS.GECKOTERMINAL} target="_blank" rel="noopener noreferrer" className="block"><Button variant="secondary" className="w-full flex items-center justify-center gap-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 text-xs md:text-sm"><Terminal className="w-3 h-3 md:w-4 md:h-4" /> GECKO</Button></a>
      </div>

      <BotControlPanel botStatus={botStatus} setBotStatus={setBotStatus} />

      {/* OFFICIAL CONTRACTS SECTION */}
      <Card title="OFFICIAL CONTRACT DATA (FOR SUPPORT & SWAPS)">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              <div className="bg-cyber-black p-3 rounded border border-cyber-gray/50">
                  <div className="text-gray-500 mb-1 flex items-center gap-2"><Coins className="w-3 h-3" /> DIAMOND (DMT) TOKEN ADDRESS</div>
                  <div className="flex items-center gap-2">
                      <span className="text-cyber-cyan break-all bg-cyber-gray/20 p-1 rounded">{DIAMOND_TOKEN_ADDRESS}</span>
                      <button onClick={() => copyToClipboard(DIAMOND_TOKEN_ADDRESS, 'token')} className="hover:text-white text-gray-400 transition-colors">
                          {copied === 'token' ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                  </div>
              </div>
              <div className="bg-cyber-black p-3 rounded border border-cyber-gray/50">
                  <div className="text-gray-500 mb-1 flex items-center gap-2"><Droplets className="w-3 h-3" /> SLOP (SLOP) TOKEN ADDRESS</div>
                  <div className="flex items-center gap-2">
                      <span className="text-orange-500 break-all bg-cyber-gray/20 p-1 rounded">{SLOP_TOKEN_ADDRESS}</span>
                      <button onClick={() => copyToClipboard(SLOP_TOKEN_ADDRESS, 'slop')} className="hover:text-white text-gray-400 transition-colors">
                          {copied === 'slop' ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                  </div>
              </div>
          </div>
      </Card>

      {/* Strategic Execution Card (Kept same) */}
      <Card title="STRATEGIC AUTO-EXECUTION (MAINNET)">
          <div className="flex flex-col md:flex-row gap-6 items-center">
              <div className="flex-1 space-y-4">
                  <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${autoSwapConfig.enabled ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                      <span className="text-sm font-display text-white">AUTO-PROFIT PROTOCOL</span>
                  </div>
                  <p className="text-xs text-gray-400">
                      System monitors live price. When DMT hits <strong>${autoSwapConfig.targetPrice.toFixed(2)}</strong>, it automatically liquidates <strong>{autoSwapConfig.percentage}%</strong> of holdings to SOL.
                  </p>
                  <div className="flex gap-4">
                      <div className="flex-1">
                          <label className="text-[10px] text-gray-500 block mb-1">TRIGGER PRICE ($)</label>
                          <input type="number" value={autoSwapConfig.targetPrice} onChange={(e) => setAutoSwapConfig({...autoSwapConfig, targetPrice: parseFloat(e.target.value)})} className="w-full bg-cyber-black border border-cyber-gray p-2 rounded text-cyber-cyan font-bold outline-none"/>
                      </div>
                      <div className="flex-1">
                          <label className="text-[10px] text-gray-500 block mb-1">LIQUIDATION %</label>
                          <input type="number" value={autoSwapConfig.percentage} onChange={(e) => setAutoSwapConfig({...autoSwapConfig, percentage: parseFloat(e.target.value)})} className="w-full bg-cyber-black border border-cyber-gray p-2 rounded text-cyber-purple font-bold outline-none"/>
                      </div>
                  </div>
              </div>
              <div className="flex flex-col gap-2 min-w-[200px]">
                  <div className="text-center mb-2">
                      <span className="text-[10px] text-gray-500">STATUS</span>
                      <div className={`font-mono font-bold ${hasAutoSwapped ? 'text-green-400' : 'text-gray-300'}`}>{hasAutoSwapped ? 'EXECUTED' : 'ARMED & WAITING'}</div>
                  </div>
                  <Button onClick={() => setAutoSwapConfig({...autoSwapConfig, enabled: !autoSwapConfig.enabled})} className={`w-full py-2 text-xs mb-2 ${autoSwapConfig.enabled ? 'bg-red-900/50 text-red-400 border border-red-500 hover:bg-red-500 hover:text-white' : 'bg-green-900/50 text-green-400 border border-green-500 hover:bg-green-500 hover:text-white'}`}><Lock className="w-3 h-3 mr-2 inline" />{autoSwapConfig.enabled ? 'DISABLE AUTO-EXEC' : 'ENABLE AUTO-EXEC'}</Button>
                  <Button onClick={handleSellAll} isLoading={isExecLoading} className="w-full py-2 text-xs bg-red-600 text-white hover:bg-red-500 border-none animate-pulse-glow">PANIC SELL (LIQUIDATE ALL)</Button>
              </div>
          </div>
      </Card>

      {/* DEV TOOLS & CLI */}
      <Card title="DEVELOPER TOOLS: MAINNET INTERACTION">
          <div className="space-y-4">
              <div className="flex justify-between items-center mb-2">
                  <h4 className="text-sm font-bold text-cyber-cyan flex items-center gap-2">
                      <Code className="w-4 h-4" /> API & CLI ACCESS
                  </h4>
                  <Button variant="secondary" onClick={() => setIsCliOpen(!isCliOpen)} className="text-[10px] py-1 h-auto">
                      {isCliOpen ? 'HIDE TERMINAL' : 'OPEN DEVELOPER TERMINAL'}
                  </Button>
              </div>
              
              {isCliOpen && <DeveloperCLI wallet={wallet} />}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="bg-cyber-gray/20 p-4 rounded border border-cyber-cyan/30">
                      <h4 className="text-sm font-bold text-cyber-cyan mb-2 flex items-center gap-2"><Code className="w-4 h-4" /> Native Staking</h4>
                      <p className="text-xs text-gray-500 mb-3">Creates a Stake Account on Mainnet using native <code>StakeProgram</code>.</p>
                      <Button onClick={handleStakeCreation} isLoading={isExecLoading} className="w-full text-xs bg-cyber-cyan/20 text-cyber-cyan border border-cyber-cyan hover:bg-cyber-cyan hover:text-black">CREATE STAKE ACCOUNT (REAL)</Button>
                  </div>
              </div>
          </div>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card title="PORTFOLIO HOLDINGS">
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-start border-b border-cyber-gray/30 pb-3">
                <div>
                <div className="text-3xl font-display font-bold text-white">{wallet.balance.toFixed(4)} <span className="text-sm text-cyber-cyan font-sans">SOL</span></div>
                <div className="text-gray-400 text-xs mt-1">≈ ${(wallet.balance * SOL_PRICE_USD).toFixed(2)} USD</div>
                </div>
                {wallet.connected && (
                <div className="flex flex-col items-end gap-2">
                    <Button onClick={handleBuySol} className="bg-green-600 hover:bg-green-500 text-white text-[10px] py-1 px-3 h-auto"><PlusCircle className="w-3 h-3 mr-1" /> COMPRAR SOL</Button>
                    <div className="flex gap-2">
                        <button onClick={() => setIsTransferOpen(true)} className="bg-cyber-gray hover:bg-cyber-cyan hover:text-black text-cyber-cyan p-2 rounded transition-all border border-cyber-cyan/30" title="Send Funds"><Send className="w-4 h-4" /></button>
                        <button onClick={() => setIsFiatOpen(true)} className="bg-cyber-gray hover:bg-blue-500 hover:text-white text-blue-500 p-2 rounded transition-all border border-blue-500/30" title="More Options"><CreditCard className="w-4 h-4" /></button>
                    </div>
                </div>
                )}
            </div>
            {/* DIAMOND ROW */}
            <div className="flex justify-between items-start border-b border-cyber-gray/30 pb-3">
                <div>
                    <div className="text-2xl font-display font-bold text-cyber-purple">{diamondBalance.toLocaleString(undefined, { maximumFractionDigits: 2 })} <span className="text-sm text-white font-sans">DMT</span></div>
                    <div className="text-gray-400 text-xs mt-1">≈ ${(diamondBalance * livePrice).toFixed(2)} USD</div>
                </div>
                {wallet.connected && diamondBalance > 0 && (
                    <div className="flex flex-col items-end gap-2">
                         <Button variant="danger" onClick={() => setIsLiquidateModalOpen(true)} className="text-[10px] py-1 px-3 h-auto shadow-[0_0_10px_rgba(255,0,60,0.3)] bg-red-600"><MinusCircle className="w-3 h-3 mr-1" /> VENDER DMT</Button>
                    </div>
                )}
            </div>
             {/* USDC ROW (New) */}
             <div className="flex justify-between items-start border-b border-cyber-gray/30 pb-3">
                <div>
                    <div className="text-2xl font-display font-bold text-blue-400">{usdcBalance.toLocaleString(undefined, { maximumFractionDigits: 2 })} <span className="text-sm text-white font-sans">USDC</span></div>
                    <div className="text-gray-400 text-xs mt-1">≈ ${(usdcBalance * USDC_PRICE_USD).toFixed(2)} USD</div>
                </div>
            </div>
             {/* SLOP ROW */}
             <div className="flex justify-between items-start border-b border-cyber-gray/30 pb-3">
                <div>
                    <div className="text-2xl font-display font-bold text-orange-500">{slopBalance.toLocaleString(undefined, { maximumFractionDigits: 2 })} <span className="text-sm text-white font-sans">SLOP</span></div>
                    <div className="text-gray-400 text-xs mt-1">≈ ${(slopBalance * SLOP_PRICE_USD).toFixed(2)} USD</div>
                </div>
            </div>
          </div>
        </Card>

        {/* METRICS & MCAP Cards */}
        <Card title="DIAMOND METRICS">
          {loading ? (
             <div className="animate-pulse flex flex-col gap-2"><div className="h-8 bg-cyber-gray rounded w-3/4"></div><div className="h-4 bg-cyber-gray rounded w-1/2"></div></div>
          ) : (
            <>
              <div className="flex items-baseline gap-2">
                <div className={`text-3xl font-display font-bold ${botStatus.active ? 'text-green-500 animate-pulse' : 'text-cyber-cyan'}`}>${livePrice.toFixed(4)}</div>
                <div className={`text-sm font-bold flex items-center ${priceChange >= 0 ? 'text-green-500' : 'text-red-500'}`}>{priceChange >= 0 ? <TrendingUp className="w-4 h-4 mr-1"/> : <TrendingDown className="w-4 h-4 mr-1"/>}{Math.abs(priceChange).toFixed(2)}% (24h)</div>
              </div>
              <div className="flex flex-col mt-2 gap-1">
                <div className="flex justify-between text-xs text-gray-400"><span className="flex items-center gap-1"><Droplets className="w-3 h-3"/> LIQ:</span><span className="text-white font-mono">${poolData ? parseFloat(poolData.liquidity).toLocaleString() : '---'}</span></div>
                <div className="flex justify-between text-xs text-gray-400"><span className="flex items-center gap-1"><DollarSign className="w-3 h-3"/> VOL:</span><span className="text-white font-mono">${(parseFloat(poolData ? poolData.volume24h : '0') + botStatus.volumeGenerated).toLocaleString()}</span></div>
              </div>
            </>
          )}
        </Card>

        <Card title="MARKET CAP / FDV">
           {loading ? (
             <div className="animate-pulse flex flex-col gap-2"><div className="h-8 bg-cyber-gray rounded w-3/4"></div><div className="h-4 bg-cyber-gray rounded w-1/2"></div></div>
          ) : (
            <>
              <div className={`text-2xl font-display font-bold truncate ${botStatus.active ? 'text-green-400' : 'text-cyber-purple'}`} title={poolData?.fdv}>${poolData ? (parseFloat(poolData.fdv) * (livePrice / parseFloat(poolData.priceUsd))).toLocaleString(undefined, { maximumFractionDigits: 0 }) : '---'}</div>
              <div className="mt-2 text-sm text-gray-400">Fully Diluted Valuation</div>
              <div className="mt-1 text-xs text-gray-500 font-mono">MCAP: ${poolData ? (parseFloat(poolData.marketCap) * (livePrice / parseFloat(poolData.priceUsd))).toLocaleString(undefined, { maximumFractionDigits: 0 }) : '---'}</div>
            </>
          )}
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="DIAMOND PRICE ACTION">
          <div className="h-[300px] w-full relative">
            {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData}><defs><linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={botStatus.active ? "#4ade80" : "#bc13fe"} stopOpacity={0.3}/><stop offset="95%" stopColor={botStatus.active ? "#4ade80" : "#bc13fe"} stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke="#1a1a24" /><XAxis dataKey="time" stroke="#6b7280" style={{ fontSize: '10px' }} /><YAxis stroke="#6b7280" style={{ fontSize: '10px' }} domain={['auto', 'auto']} /><Tooltip contentStyle={{ backgroundColor: '#0a0a0f', borderColor: botStatus.active ? '#4ade80' : '#bc13fe' }} itemStyle={{ color: botStatus.active ? '#4ade80' : '#bc13fe' }} /><Area type="monotone" dataKey="price" stroke={botStatus.active ? "#4ade80" : "#bc13fe"} strokeWidth={2} fillOpacity={1} fill="url(#colorPrice)" isAnimationActive={false} /></AreaChart></ResponsiveContainer>
            ) : <div className="flex items-center justify-center h-full text-gray-500 font-mono text-sm animate-pulse">WAITING FOR FIRST MARKET TICK...</div>}
            {botStatus.active && <div className="absolute top-2 right-2 flex items-center gap-1 bg-green-900/40 text-green-400 text-[10px] px-2 py-1 rounded border border-green-500/30 animate-pulse"><Activity className="w-3 h-3" /><span>BOTNET INJECTION ACTIVE</span></div>}
          </div>
        </Card>
        
        <div className="space-y-6">
            <Card title="LIVE VOLUME FEED">
            <div className="h-[120px] w-full">
                {chartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%"><BarChart data={chartData}><CartesianGrid strokeDasharray="3 3" stroke="#1a1a24" /><XAxis dataKey="time" hide /><YAxis stroke="#6b7280" style={{ fontSize: '10px' }} domain={['auto', 'auto']} /><Tooltip contentStyle={{ backgroundColor: '#0a0a0f', borderColor: '#00f3ff' }} cursor={{fill: '#1a1a24'}} /><Bar dataKey="volume" fill={botStatus.active ? "#4ade80" : "#00f3ff"} opacity={0.8} /></BarChart></ResponsiveContainer>
                ) : <div className="flex items-center justify-center h-full text-gray-500 font-mono text-sm animate-pulse">WAITING FOR VOLUME DATA...</div>}
            </div>
            </Card>

            <Card title="GOOGLE FINANCE NEWS WIRE">
                <div className="relative h-[120px] overflow-hidden">
                    <div className="absolute inset-0 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                        {googleData && googleData.news.length > 0 ? (
                            googleData.news.map((news, i) => (
                                <div key={i} className="flex flex-col border-b border-cyber-gray/30 pb-2 last:border-0 hover:bg-cyber-gray/20 p-1 rounded transition-colors cursor-default">
                                    <span className="text-white text-xs font-bold truncate">{news.title}</span>
                                    <div className="flex justify-between text-[10px] text-gray-500 mt-1"><span className="text-cyber-cyan">{news.source}</span><span>{news.time}</span></div>
                                </div>
                            ))
                        ) : <div className="flex items-center justify-center h-full text-gray-500 text-xs"><Newspaper className="w-4 h-4 mr-2" /> ESTABLISHING GOOGLE UPLINK...</div>}
                    </div>
                </div>
            </Card>
        </div>
      </div>
    </div>
  );
};
