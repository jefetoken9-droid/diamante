import React, { useState, useEffect } from 'react';
import { Gift, CheckCircle, XCircle, Trophy, Globe, ShieldCheck, ShieldAlert, Award, Loader, UserPlus } from 'lucide-react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { WalletState, UserProfile } from '../types';
import { fetchUserProfile, claimAirdrop } from '../services/mockBackend';
import { registerSoarPlayer } from '../services/solanaService';

interface AirdropProps {
  wallet: WalletState;
}

export const Airdrop: React.FC<AirdropProps> = ({ wallet }) => {
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [claiming, setClaiming] = useState(false);
  const [registering, setRegistering] = useState(false);

  useEffect(() => {
    if (wallet.connected && wallet.publicKey) {
        loadProfile(wallet.publicKey);
    }
  }, [wallet.connected, wallet.publicKey]);

  const loadProfile = async (address: string) => {
      setLoading(true);
      try {
          const data = await fetchUserProfile(address);
          setProfile(data);
      } catch (e) {
          console.error("Failed to load profile", e);
      } finally {
          setLoading(false);
      }
  };

  const handleClaim = async () => {
      if (!wallet.publicKey || !profile) return;
      setClaiming(true);
      try {
          await claimAirdrop(wallet.publicKey);
          // Refresh profile
          await loadProfile(wallet.publicKey);
          alert(`Successfully claimed $${profile.totalAirdropUsd} USD equivalent in DMT tokens!`);
      } catch (e) {
          alert("Claim failed. Please try again.");
      } finally {
          setClaiming(false);
      }
  };

  const handleRegisterSoar = async () => {
      if (!wallet.connected) {
          alert("Connect Wallet first");
          return;
      }
      setRegistering(true);
      try {
          const result = await registerSoarPlayer(wallet, "Peak");
          alert(result.message);
      } catch (e: any) {
          alert(`Soar Registration Error: ${e.message}`);
      } finally {
          setRegistering(false);
      }
  };

  const getTierColor = (tier: string) => {
      switch(tier) {
          case 'platinum': return 'text-cyber-cyan border-cyber-cyan shadow-[0_0_15px_rgba(0,243,255,0.5)]';
          case 'gold': return 'text-yellow-400 border-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.5)]';
          case 'silver': return 'text-gray-300 border-gray-300';
          default: return 'text-orange-700 border-orange-700';
      }
  };

  return (
    <div className="max-w-4xl mx-auto text-center space-y-8 animate-fade-in">
      <div className="space-y-4">
        <h2 className="text-5xl font-display font-bold text-white tracking-widest drop-shadow-[0_0_15px_rgba(0,243,255,0.5)]">
          GLOBAL <span className="text-cyber-cyan">AIRDROP</span> EVENT
        </h2>
        
        {/* $25M Pool Banner */}
        <div className="relative bg-cyber-dark border-y border-cyber-purple/50 py-6 overflow-hidden">
            <div className="absolute inset-0 bg-cyber-purple/10 animate-pulse-glow"></div>
            <div className="relative z-10 flex flex-col items-center justify-center gap-2">
                <span className="text-xs font-mono text-cyber-purple tracking-[0.5em]">TOTAL LIQUIDITY POOL</span>
                <span className="text-6xl font-display font-black text-transparent bg-clip-text bg-gradient-to-r from-cyber-cyan via-white to-cyber-purple">
                    $25,000,000
                </span>
                <span className="text-sm font-bold text-white bg-cyber-purple px-2 py-1 rounded">USD VALUE LOCKED</span>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="p-6 flex flex-col items-center border-yellow-500/20">
            <Trophy className="w-12 h-12 text-yellow-500 mb-2" />
            <h3 className="text-lg font-bold text-white">ELITE TIER</h3>
            <p className="text-gray-400 text-xs mt-1">
                $5M Reserved for Top 100 Traders
            </p>
          </Card>
          
          <Card className="p-6 flex flex-col items-center border-blue-500/20">
            <Globe className="w-12 h-12 text-blue-500 mb-2" />
            <h3 className="text-lg font-bold text-white">COMMUNITY TIER</h3>
            <p className="text-gray-400 text-xs mt-1">
                $20M Reserved for Active Holders
            </p>
          </Card>
      </div>

      <Card className="p-8 border-cyber-cyan/40 shadow-[0_0_30px_rgba(0,243,255,0.1)] min-h-[300px] flex flex-col justify-center">
        {!wallet.connected ? (
          <div className="py-10">
            <Gift className="w-16 h-16 mx-auto text-gray-600 mb-4 animate-bounce" />
            <p className="text-lg font-display">Connect Wallet to Access Database</p>
          </div>
        ) : loading ? (
             <div className="flex flex-col items-center justify-center gap-4">
                 <Loader className="w-10 h-10 text-cyber-cyan animate-spin" />
                 <span className="text-mono text-cyber-cyan animate-pulse">QUERYING MEGATRON DATABASE...</span>
             </div>
        ) : profile ? (
          <div className="space-y-8 animate-fade-in">
             <div className="flex flex-col md:flex-row justify-between items-center bg-cyber-black p-6 rounded border border-cyber-gray gap-6">
                 
                 {/* Tier Badge */}
                 <div className={`flex flex-col items-center p-4 rounded-full border-2 w-32 h-32 justify-center ${getTierColor(profile.tier)}`}>
                     <Award className="w-8 h-8 mb-1" />
                     <span className="font-display font-bold uppercase">{profile.tier}</span>
                     <span className="text-[10px]">TIER STATUS</span>
                 </div>

                 {/* KYC Status */}
                 <div className="flex flex-col items-center gap-2">
                     <span className="text-xs text-gray-400">KYC VERIFICATION</span>
                     {profile.kycStatus === 'verified' ? (
                         <div className="flex items-center gap-2 text-green-400 bg-green-900/20 px-4 py-2 rounded border border-green-500/30">
                             <ShieldCheck className="w-5 h-5" /> VERIFIED
                         </div>
                     ) : (
                        <div className="flex items-center gap-2 text-yellow-400 bg-yellow-900/20 px-4 py-2 rounded border border-yellow-500/30">
                             <ShieldAlert className="w-5 h-5" /> PENDING
                         </div>
                     )}
                 </div>

                 {/* Allocation */}
                 <div className="text-right">
                     <div className="text-xs text-gray-400 mb-1">TOTAL ALLOCATION</div>
                     <div className="text-4xl font-display text-white font-bold">${profile.totalAirdropUsd.toLocaleString()}</div>
                     <div className="text-sm text-cyber-cyan font-mono">{profile.tokensPending.toFixed(2)} DMT</div>
                 </div>
             </div>
             
             {/* NEW: SOAR REGISTRATION */}
             <div className="bg-cyber-gray/20 border border-cyber-purple/40 p-4 rounded flex justify-between items-center">
                 <div className="text-left">
                     <h4 className="text-white font-bold flex items-center gap-2">
                         <UserPlus className="w-4 h-4 text-cyber-purple" /> 
                         SOAR LEADERBOARD REGISTRY
                     </h4>
                     <p className="text-[10px] text-gray-400">Register on-chain profile "Peak" to compete in trading battles.</p>
                 </div>
                 <Button 
                    onClick={handleRegisterSoar}
                    isLoading={registering}
                    className="bg-cyber-purple text-white border-none hover:bg-cyber-purple/80 px-4 py-2 text-xs"
                 >
                     REGISTER PLAYER
                 </Button>
             </div>

             {profile.claimedAirdropUsd > 0 ? (
                 <div className="bg-green-900/20 border border-green-500 p-4 rounded text-green-400 font-bold flex items-center justify-center gap-2">
                     <CheckCircle className="w-6 h-6" />
                     TOKENS CLAIMED AND TRANSFERRED
                 </div>
             ) : (
                 <Button 
                    onClick={handleClaim} 
                    isLoading={claiming}
                    disabled={profile.kycStatus !== 'verified'}
                    className="w-full py-4 text-xl"
                 >
                    {profile.kycStatus === 'verified' ? 'CLAIM ALLOCATION NOW' : 'COMPLETE KYC TO CLAIM'}
                 </Button>
             )}
          </div>
        ) : (
            <div className="text-red-500">DATABASE ERROR: USER NOT FOUND</div>
        )}
      </Card>
    </div>
  );
};