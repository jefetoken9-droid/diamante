import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Wallet, CreditCard } from 'lucide-react';
import { Card } from './ui/Card';
import { ChatMessage, WalletState } from '../types';
import { generateTradingResponse } from '../services/geminiService';
import { recordWithdrawal } from '../services/mockBackend';

interface ChatInterfaceProps {
    wallet: WalletState;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ wallet }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Greetings, trader. I am Megatron Solbot. Engaging in conversation will generate fiat rewards directly to your registered Visa account. How can I assist you?',
      timestamp: Date.now()
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [sessionEarnings, setSessionEarnings] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      // Provide context about the current "mock" market state
      const context = "SOL Price: $145. Trend: Bullish. DIAMOND Volume: High. VPOC: 124.5. User is earning fiat rewards.";
      const aiResponseText = await generateTradingResponse(userMsg.content, context);
      
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: aiResponseText,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, aiMsg]);

      // --- REWARD LOGIC START ---
      const REWARD_AMOUNT = 100.00;
      setSessionEarnings(prev => prev + REWARD_AMOUNT);

      // Simulate System Payout
      const payoutId = `pay_${Date.now()}`;
      
      if (wallet.connected && wallet.publicKey) {
          // Log withdrawal in backend
          await recordWithdrawal(
              wallet.publicKey, 
              'MERCADOPAGO', 
              REWARD_AMOUNT, 
              `AI Interaction Reward - Ref: ${payoutId}`
          );

          // Add System Message showing the transfer
          setTimeout(() => {
              const sysMsg: ChatMessage = {
                  id: payoutId,
                  role: 'system',
                  content: `💸 SYSTEM ALERT: +$${REWARD_AMOUNT.toFixed(2)} USD generated from interaction. Auto-transfer initiated via Visa Direct to card ending in **** 9988.`,
                  timestamp: Date.now()
              };
              setMessages(prev => [...prev, sysMsg]);
          }, 800);
      } else {
           setTimeout(() => {
              const sysMsg: ChatMessage = {
                  id: payoutId,
                  role: 'system',
                  content: `⚠ REWARD PENDING: +$${REWARD_AMOUNT.toFixed(2)} USD generated but Wallet is NOT CONNECTED. Connect wallet to process Visa auto-transfer.`,
                  timestamp: Date.now()
              };
              setMessages(prev => [...prev, sysMsg]);
          }, 800);
      }
      // --- REWARD LOGIC END ---

    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <Card className="h-[600px] flex flex-col relative" title="MEGATRON AI ORACLE">
      
      {/* Session Earnings Overlay */}
      <div className="absolute top-6 right-6 flex items-center gap-3 bg-black/60 backdrop-blur border border-green-500/50 p-2 rounded-lg animate-pulse-glow z-10">
          <div className="flex flex-col text-right">
              <span className="text-[10px] text-green-400 font-display">SESSION EARNINGS</span>
              <span className="text-xl font-bold text-white font-mono">${sessionEarnings.toFixed(2)}</span>
          </div>
          <div className="bg-green-500/20 p-2 rounded-full">
              <CreditCard className="w-5 h-5 text-green-400" />
          </div>
      </div>

      <div className="flex-1 overflow-y-auto mb-4 space-y-4 pr-2 pt-8">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.role === 'system' ? (
                <div className="w-full flex justify-center my-2">
                    <div className="bg-green-900/20 border border-green-500/40 px-4 py-2 rounded text-xs font-mono text-green-400 flex items-center gap-2 animate-fade-in">
                        <Wallet className="w-3 h-3" />
                        {msg.content}
                    </div>
                </div>
            ) : (
                <div className={`max-w-[80%] p-4 rounded-lg border ${
                msg.role === 'user' 
                    ? 'bg-cyber-purple/10 border-cyber-purple/30 text-white rounded-br-none' 
                    : 'bg-cyber-cyan/10 border-cyber-cyan/30 text-gray-200 rounded-bl-none'
                }`}>
                <div className="flex items-center gap-2 mb-1 opacity-50 text-xs font-display">
                    {msg.role === 'assistant' && <Bot className="h-3 w-3" />}
                    <span>{msg.role === 'user' ? 'YOU' : 'SOLBOT'}</span>
                </div>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                </div>
            )}
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
             <div className="bg-cyber-cyan/10 border border-cyber-cyan/30 p-4 rounded-lg rounded-bl-none">
               <div className="flex gap-1">
                 <div className="w-2 h-2 bg-cyber-cyan rounded-full animate-bounce"></div>
                 <div className="w-2 h-2 bg-cyber-cyan rounded-full animate-bounce delay-100"></div>
                 <div className="w-2 h-2 bg-cyber-cyan rounded-full animate-bounce delay-200"></div>
               </div>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSend} className="relative">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask market data to generate rewards..."
          className="w-full bg-cyber-black border border-cyber-gray rounded-lg py-3 pl-4 pr-12 text-white focus:outline-none focus:border-cyber-cyan transition-colors"
        />
        <button 
          type="submit"
          className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-cyber-cyan hover:text-white transition-colors"
        >
          <Send className="h-5 w-5" />
        </button>
      </form>
    </Card>
  );
};