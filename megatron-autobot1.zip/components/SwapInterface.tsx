
import React, { useState, useEffect } from 'react';
import { ArrowDownUp, Zap, Settings, ChevronDown, ChevronUp, Layers, RefreshCw, AlertTriangle, Maximize, TrendingUp, TrendingDown } from 'lucide-react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { WalletState, PoolData } from '../types';
import { performSwap, buyPumpFunToken, executeStabilizationSwap } from '../services/solanaService';
import { DIAMOND_TOKEN_ADDRESS, DEEPSEEK_TOKEN_ADDRESS, WSOL_TOKEN_ADDRESS, SLOP_TOKEN_ADDRESS, USDC_TOKEN_ADDRESS, SOL_PRICE_USD, DIAMOND_PRICE_USD, DEEPSEEK_PRICE_USD, SLOP_PRICE_USD, USDC_PRICE_USD } from '../constants';

interface SwapProps {
  wallet: WalletState;
  poolData: PoolData | null;
  onTxSuccess?: () => void;
  livePrice: number; // Received from App (Robot driven)
  botActive: boolean;
}

type TokenOption = 'SOL' | 'DIAMOND' | 'DEEPSEEK' | 'WSOL' | 'SLOP' | 'USDC';
type TradeMode = 'BUY' | 'SELL';

export const SwapInterface: React.FC<SwapProps> = ({ wallet, poolData, onTxSuccess, livePrice, botActive }) => {
  const [fromAmount, setFromAmount] = useState<string>('');
  const [isSwapping, setIsSwapping] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [isPumpFunMode, setIsPumpFunMode] = useState(false); // Default to Jupiter (Classic Swap)
  
  // Trade Mode State (Buy vs Sell)
  const [tradeMode, setTradeMode] = useState<TradeMode>('BUY');

  // Default tokens based on mode
  const [fromToken, setFromToken] = useState<TokenOption>('SOL');
  const [toToken, setToToken] = useState<TokenOption>('DIAMOND');
  
  // Stabilizer State
  const [targetWallet, setTargetWallet] = useState<string>(wallet.publicKey || '');
  const [isStabilizing, setIsStabilizing] = useState(false);
  const [showStabilizer, setShowStabilizer] = useState(false);

  // Advanced Settings State
  const [showSettings, setShowSettings] = useState(false);
  const [slippage, setSlippage] = useState<number>(1.0); // Higher slippage for Mainnet execution
  const [deadline, setDeadline] = useState<number>(20);

  useEffect(() => {
      if (wallet.publicKey) setTargetWallet(wallet.publicKey);
  }, [wallet.publicKey]);

  // Handle Mode Switching
  const handleModeChange = (mode: TradeMode) => {
      setTradeMode(mode);
      if (mode === 'BUY') {
          // Buying DMT: Spending SOL -> Getting DMT
          setFromToken('SOL');
          setToToken('DIAMOND');
      } else {
          // Selling DMT: Spending DMT -> Getting SOL
          setFromToken('DIAMOND');
          setToToken('SOL');
      }
      setFromAmount(''); // Clear amount on switch
  };

  // Helper to get prices with robust fallbacks
  const getPrice = (token: TokenOption) => {
    switch (token) {
      case 'SOL': return SOL_PRICE_USD;
      case 'WSOL': return SOL_PRICE_USD; // WSOL is pegged 1:1 to SOL
      // CRITICAL: Use livePrice (Robot Price) if bots are active, fallback to poolData or constant
      case 'DIAMOND': 
        if (livePrice > 0) return livePrice;
        if (poolData && poolData.priceUsd) return parseFloat(poolData.priceUsd);
        return DIAMOND_PRICE_USD;
      case 'DEEPSEEK': return DEEPSEEK_PRICE_USD;
      case 'SLOP': return SLOP_PRICE_USD;
      case 'USDC': return USDC_PRICE_USD;
      default: return 0;
    }
  };

  const getAddress = (token: TokenOption) => {
      if (token === 'DIAMOND') return DIAMOND_TOKEN_ADDRESS;
      if (token === 'DEEPSEEK') return DEEPSEEK_TOKEN_ADDRESS;
      if (token === 'WSOL') return WSOL_TOKEN_ADDRESS;
      if (token === 'SLOP') return SLOP_TOKEN_ADDRESS;
      if (token === 'USDC') return USDC_TOKEN_ADDRESS;
      return 'So11111111111111111111111111111111111111112'; // Default SOL/WSOL
  };

  const fromPrice = getPrice(fromToken);
  const toPrice = getPrice(toToken);
  // Calculate exchange rate: How much ToToken per 1 FromToken
  const exchangeRate = toPrice > 0 ? fromPrice / toPrice : 0;

  // Balance logic
  const getBalance = (token: TokenOption) => {
    if (token === 'SOL') return wallet.balance;
    if (token === 'WSOL') return wallet.tokens[WSOL_TOKEN_ADDRESS] || 0;
    if (token === 'DIAMOND') return wallet.tokens[DIAMOND_TOKEN_ADDRESS] || 0;
    if (token === 'DEEPSEEK') return wallet.tokens[DEEPSEEK_TOKEN_ADDRESS] || 0;
    if (token === 'SLOP') return wallet.tokens[SLOP_TOKEN_ADDRESS] || 0;
    if (token === 'USDC') return wallet.tokens[USDC_TOKEN_ADDRESS] || 0;
    return 0;
  };

  const handleMax = () => {
      const bal = getBalance(fromToken);
      // Leave a tiny bit for rent if SOL, otherwise full amount
      const maxVal = fromToken === 'SOL' ? Math.max(0, bal - 0.01) : bal;
      setFromAmount(maxVal.toString());
  };

  const switchTokens = () => {
    // If manually switching, toggle the mode visual
    if (tradeMode === 'BUY') setTradeMode('SELL');
    else setTradeMode('BUY');

    setFromToken(toToken);
    setToToken(fromToken);
  };

  const handleSwap = async () => {
    if (!wallet.connected) {
      setStatus("Wallet not connected");
      return;
    }
    
    setIsSwapping(true);
    setStatus(null);

    try {
      let result;
      
      // Pump.fun Logic: Only supports SOL -> Token (Buy) for this demo bonding curve logic
      if (isPumpFunMode && fromToken === 'SOL' && (toToken === 'DIAMOND' || toToken === 'DEEPSEEK' || toToken === 'SLOP')) {
          result = await buyPumpFunToken(
              wallet, 
              getAddress(toToken), 
              parseFloat(fromAmount)
          );
      } else {
          // Attempt generic swap
          const actionName = (fromToken === 'SOL' && toToken === 'WSOL') ? 'WRAP' : (fromToken === 'WSOL' && toToken === 'SOL') ? 'UNWRAP' : 'SWAP';
          console.log(`[SWAP UI] Initiating Real ${actionName}: ${fromToken} -> ${toToken}`);
          
          result = await performSwap(wallet, fromToken, toToken, parseFloat(fromAmount));
      }

      // Check success flag
      if (result.success) {
         setStatus(result.message);
         setFromAmount('');
         if (onTxSuccess) {
             // Add delay for Chain Propagation of the SOL Payout
             setTimeout(() => {
                 onTxSuccess();
             }, 3000);
         }
      } else {
         // Display message neutrally, not as an error
         setStatus(result.message); 
      }
      
    } catch (error: any) {
      // Silent catch or simple log
      console.warn("Swap operation cancelled or failed");
      setStatus("Transaction Terminated");
    } finally {
      setIsSwapping(false);
    }
  };

  const handleStabilize = async () => {
      if (!wallet.connected) return;
      setIsStabilizing(true);
      try {
          const result = await executeStabilizationSwap(wallet, targetWallet, livePrice);
          if (result.success) {
            alert(result.message);
            if (onTxSuccess) onTxSuccess();
          } else {
            console.log("Stabilization skipped: " + result.message);
          }
      } catch (e: any) {
          // Silent catch
      } finally {
          setIsStabilizing(false);
      }
  };

  // --- Dynamic Calculation Logic ---
  const inputVal = parseFloat(fromAmount) || 0;
  
  // 1. Expected Output (Mid-Market)
  // Logic: Amount * (FromPrice / ToPrice)
  const estimatedVal = inputVal * exchangeRate;
  
  // 2. Minimum Received (Accounting for Slippage)
  // Formula: Expected * (1 - slippage%)
  const minVal = estimatedVal * (1 - (slippage / 100));

  const estimatedOutput = estimatedVal > 0 ? estimatedVal.toFixed(6) : '0.00';
  const minReceivedOutput = minVal > 0 ? minVal.toFixed(6) : '0.00';
  
  const isWrapping = (fromToken === 'SOL' && toToken === 'WSOL') || (fromToken === 'WSOL' && toToken === 'SOL');

  return (
    <div className="max-w-xl mx-auto space-y-6">
      
      {/* PROTOCOL STABILIZER PANEL */}
      <div className="bg-cyber-gray/20 border border-green-500/50 p-4 rounded-lg">
          <button 
             onClick={() => setShowStabilizer(!showStabilizer)}
             className="w-full flex justify-between items-center text-green-400 font-display text-sm tracking-widest"
          >
              <div className="flex items-center gap-2">
                 <RefreshCw className={`w-4 h-4 ${isStabilizing ? 'animate-spin' : ''}`} />
                 PROTOCOL STABILIZER
              </div>
              {showStabilizer ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          
          {showStabilizer && (
              <div className="mt-4 space-y-3 animate-fade-in border-t border-green-900/50 pt-3">
                  <div className="text-xs text-gray-400">
                      Target specific wallet to liquidate ALL assets to SOL and buy DMT to stabilize price at current robot levels.
                  </div>
                  <div>
                      <label className="text-xs text-green-600 font-bold mb-1 block">TARGET WALLET ADDRESS</label>
                      <input 
                         type="text" 
                         value={targetWallet}
                         onChange={(e) => setTargetWallet(e.target.value)}
                         className="w-full bg-black/50 border border-green-900 text-green-400 p-2 rounded text-xs font-mono"
                      />
                  </div>
                  <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-500">TARGET PRICE:</span>
                      <span className="text-green-400 font-bold font-mono">${livePrice.toFixed(4)}</span>
                  </div>
                  <Button 
                    variant="primary" 
                    className="w-full bg-green-600 hover:bg-green-500 text-black border-none"
                    onClick={handleStabilize}
                    isLoading={isStabilizing}
                  >
                      EXECUTE STABILIZATION SWAP
                  </Button>
              </div>
          )}
      </div>

      <Card title={botActive ? `REAL-TIME BOT PRICE: $${livePrice.toFixed(4)}` : "REAL-TIME DEX INTERFACE"}>
        <div className="space-y-4">
          
          {/* BUY / SELL TABS */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-cyber-black rounded-lg border border-cyber-gray">
              <button
                  onClick={() => handleModeChange('BUY')}
                  className={`py-3 text-sm font-bold rounded flex items-center justify-center gap-2 transition-all ${
                      tradeMode === 'BUY' 
                      ? 'bg-green-600 text-white shadow-[0_0_15px_rgba(22,163,74,0.4)]' 
                      : 'text-gray-500 hover:text-gray-300'
                  }`}
              >
                  <TrendingUp className="w-4 h-4" /> COMPRAR
              </button>
              <button
                  onClick={() => handleModeChange('SELL')}
                  className={`py-3 text-sm font-bold rounded flex items-center justify-center gap-2 transition-all ${
                      tradeMode === 'SELL' 
                      ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(220,38,38,0.4)]' 
                      : 'text-gray-500 hover:text-gray-300'
                  }`}
              >
                  <TrendingDown className="w-4 h-4" /> VENDER
              </button>
          </div>

          {/* Header Controls */}
          <div className="flex flex-col gap-2 mb-2">
            <div className="flex items-center justify-between">
                {/* Mode Toggle */}
                <div className="flex items-center gap-2 bg-cyber-dark p-2 rounded border border-cyber-gray">
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                    {isPumpFunMode ? <Zap className="w-4 h-4 text-yellow-400 fill-yellow-400" /> : <Layers className="w-4 h-4 text-cyber-cyan" />}
                    <span className="font-display text-xs">{isPumpFunMode ? 'PUMP.FUN BONDING' : 'JUPITER AGGREGATOR'}</span>
                    </div>
                    <button 
                    onClick={() => setIsPumpFunMode(!isPumpFunMode)}
                    className={`relative w-8 h-4 rounded-full transition-colors ${isPumpFunMode ? 'bg-yellow-500' : 'bg-cyber-cyan'}`}
                    >
                    <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform ${isPumpFunMode ? 'translate-x-4' : 'translate-x-0'}`} />
                    </button>
                </div>

                {/* Settings Toggle */}
                <button 
                  onClick={() => setShowSettings(!showSettings)}
                  className={`p-2 rounded hover:bg-cyber-gray transition-colors ${showSettings ? 'text-cyber-cyan' : 'text-gray-500'}`}
                >
                  <Settings className="w-5 h-5" />
                </button>
            </div>
          </div>

          {/* Advanced Settings */}
          {showSettings && (
            <div className="bg-cyber-black/50 border border-cyber-gray p-3 rounded space-y-3 animate-fade-in text-xs">
               <div className="flex justify-between items-center text-gray-400 font-display">
                  <span>ADVANCED TRANSACTION SETTINGS</span>
                  <ChevronUp className="w-3 h-3 cursor-pointer" onClick={() => setShowSettings(false)} />
               </div>
               
               <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-gray-500 mb-1">Slippage Tolerance (%)</label>
                    <div className="flex gap-2">
                      {[0.1, 0.5, 1.0].map((val) => (
                        <button
                          key={val}
                          onClick={() => setSlippage(val)}
                          className={`px-2 py-1 rounded border ${slippage === val ? 'bg-cyber-purple/20 border-cyber-purple text-white' : 'border-cyber-gray text-gray-500 hover:text-white'}`}
                        >
                          {val}%
                        </button>
                      ))}
                      <input 
                        type="number" 
                        value={slippage}
                        onChange={(e) => setSlippage(parseFloat(e.target.value))}
                        className="w-12 bg-cyber-black border border-cyber-gray rounded px-1 text-center text-white focus:border-cyber-purple outline-none"
                      />
                    </div>
                 </div>
                 
                 <div>
                    <label className="block text-gray-500 mb-1">Transaction Deadline (m)</label>
                    <input 
                      type="number"
                      value={deadline}
                      onChange={(e) => setDeadline(parseInt(e.target.value))}
                      className="w-full bg-cyber-black border border-cyber-gray rounded p-1 text-white focus:border-cyber-purple outline-none"
                    />
                 </div>
               </div>
            </div>
          )}

          {/* FROM */}
          <div className="bg-cyber-black p-4 border border-cyber-gray rounded-lg">
            <div className="flex justify-between mb-2 text-sm text-gray-400">
              <span>PAYING</span>
              <div className="flex items-center gap-2">
                  <span>BAL: {getBalance(fromToken).toFixed(4)}</span>
                  <button onClick={handleMax} className="text-[10px] bg-cyber-gray px-1.5 rounded text-cyber-cyan hover:text-white">MAX</button>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <input 
                type="number" 
                value={fromAmount}
                onChange={(e) => setFromAmount(e.target.value)}
                placeholder="0.00"
                className="bg-transparent text-2xl font-bold w-full focus:outline-none text-white font-mono"
              />
              <select 
                value={fromToken}
                onChange={(e) => setFromToken(e.target.value as TokenOption)}
                className="bg-cyber-gray px-2 py-1 rounded border border-cyber-cyan/30 text-cyber-cyan font-bold outline-none cursor-pointer"
              >
                  <option value="SOL">SOL</option>
                  <option value="WSOL">WSOL</option>
                  <option value="DIAMOND">DMT</option>
                  <option value="DEEPSEEK">DEEP</option>
                  <option value="SLOP">SLOP</option>
                  <option value="USDC">USDC</option>
              </select>
            </div>
          </div>

          {/* SWAP ICON */}
          <div className="flex justify-center -my-2 relative z-10">
            <button 
              onClick={switchTokens}
              className="bg-cyber-purple p-2 rounded-full hover:shadow-[0_0_15px_rgba(188,19,254,0.6)] transition-all"
            >
              <ArrowDownUp className="text-white h-5 w-5" />
            </button>
          </div>

          {/* TO */}
          <div className="bg-cyber-black p-4 border border-cyber-gray rounded-lg">
            <div className="flex justify-between mb-2 text-sm text-gray-400">
              <span>RECEIVING (EST)</span>
            </div>
            <div className="flex items-center gap-4">
               <div className="text-2xl font-bold w-full text-gray-300 font-mono">
                 {estimatedOutput}
               </div>
               <select 
                value={toToken}
                onChange={(e) => setToToken(e.target.value as TokenOption)}
                className="bg-cyber-gray px-2 py-1 rounded border border-cyber-purple/30 text-cyber-purple font-bold outline-none cursor-pointer"
              >
                  <option value="SOL">SOL</option>
                  <option value="WSOL">WSOL</option>
                  <option value="DIAMOND">DMT</option>
                  <option value="DEEPSEEK">DEEP</option>
                  <option value="SLOP">SLOP</option>
                  <option value="USDC">USDC</option>
              </select>
            </div>
            <div className="mt-2 flex justify-between items-center text-[10px] text-gray-500 font-mono">
                <span className="truncate max-w-[200px]">Contract: {getAddress(toToken)}</span>
                <span className="text-cyber-cyan">Min Received: {minReceivedOutput} {toToken}</span>
            </div>
          </div>

          {/* Price Info */}
          <div className="flex justify-between text-xs text-gray-500 font-mono border-t border-cyber-gray/30 pt-3 mt-1">
            <span>Rate</span>
            <span className="text-cyber-cyan">
                1 {fromToken} ≈ {exchangeRate.toFixed(4)} {toToken}
            </span>
          </div>
          
          <div className="flex justify-between text-[10px] text-gray-600 font-mono mt-1">
              <span>Slippage: {slippage}%</span>
              <span>Deadline: {deadline}m</span>
              <span>Route: {isWrapping ? 'SYSTEM WRAP' : (isPumpFunMode ? 'PUMP.FUN' : 'JUPITER')}</span>
          </div>

          {/* Action */}
          <Button 
            className={`w-full mt-4 ${tradeMode === 'BUY' ? 'bg-green-600 hover:bg-green-500' : 'bg-red-600 hover:bg-red-500'}`} 
            onClick={handleSwap} 
            isLoading={isSwapping}
            disabled={!fromAmount || parseFloat(fromAmount) <= 0}
          >
            {wallet.connected 
                ? (isWrapping 
                    ? (fromToken === 'SOL' ? 'WRAP SOL (REAL)' : 'UNWRAP WSOL (REAL)') 
                    : (tradeMode === 'BUY' ? `COMPRAR ${toToken}` : `VENDER ${fromToken}`))
                : 'CONNECT WALLET'}
          </Button>

          {status && (
            <div className={`text-center p-3 rounded bg-opacity-20 text-xs font-mono break-all ${status.includes('Error') || status.includes('Failed') ? 'bg-red-500 text-red-300' : 'bg-blue-500/20 text-blue-300'}`}>
              {status}
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};
