
import React, { useState, useRef, useEffect } from 'react';
import { Terminal, Send, ChevronRight, Server, Database, Command } from 'lucide-react';
import { handleApiRequest } from '../services/customApiService';
import { processCliCommand } from '../services/cliService';
import { WalletState } from '../types';

interface DeveloperCLIProps {
    wallet: WalletState;
}

interface LogEntry {
    type: 'req' | 'res' | 'info';
    content: string;
}

export const DeveloperCLI: React.FC<DeveloperCLIProps> = ({ wallet }) => {
    const [input, setInput] = useState('');
    const [logs, setLogs] = useState<LogEntry[]>([
        { type: 'info', content: 'MEGATRON SOLBOT TERMINAL v2.0' },
        { type: 'info', content: 'Environment: MAINNET-BETA (Alchemy RPC)' },
        { type: 'info', content: 'Type "help" or "solana --help" for available commands.' }
    ]);
    const [isProcessing, setIsProcessing] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [logs]);

    const executeCommand = async (cmd: string) => {
        const rawCmd = cmd.trim();
        const parts = rawCmd.split(' ');
        const mainCmd = parts[0].toLowerCase();
        
        // Help Command
        if (mainCmd === 'help') {
            return [
                'AVAILABLE COMMAND SUITES:',
                '  solana [options]          - Solana Native CLI Interface',
                '  spl-token [options]       - SPL Token Management',
                '  GET /api/...              - Custom API Endpoints',
                '  POST /api/...             - Custom API Actions',
                '  clear                     - Clear terminal buffer',
                '',
                'EXAMPLES:',
                '  solana balance',
                '  solana address',
                '  solana transfer <addr> 0.1',
                '  spl-token accounts',
                '  GET /api/apy'
            ].join('\n');
        }

        if (mainCmd === 'clear') {
            setLogs([]);
            return '';
        }

        // 1. Try Solana CLI Parser
        if (mainCmd === 'solana' || mainCmd === 'spl-token') {
            return await processCliCommand(rawCmd, wallet);
        }

        // 2. Try Custom API Parser (GET/POST)
        if (mainCmd === 'get' || mainCmd === 'post') {
            const endpoint = parts[1];
            let body = {};
            if (parts.length > 2) {
                try {
                    const jsonStr = parts.slice(2).join(' ');
                    body = JSON.parse(jsonStr);
                } catch (e) {
                    return "ERROR: Invalid JSON format in body.";
                }
            }
            const response = await handleApiRequest(mainCmd.toUpperCase() as 'GET' | 'POST', endpoint, body, wallet);
            return JSON.stringify(response, null, 2);
        }

        return `Command not recognized: "${mainCmd}". Type "help" for list.`;
    };

    const handleKeyDown = async (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !isProcessing && input.trim()) {
            setIsProcessing(true);
            const cmd = input;
            setLogs(prev => [...prev, { type: 'req', content: `$ ${cmd}` }]);
            setInput('');

            try {
                const result = await executeCommand(cmd);
                if (result) {
                    setLogs(prev => [...prev, { type: 'res', content: result }]);
                }
            } catch (e: any) {
                setLogs(prev => [...prev, { type: 'res', content: `Error: ${e.message}` }]);
            } finally {
                setIsProcessing(false);
            }
        }
    };

    // Quick Action Buttons
    const runQuickCmd = (cmd: string) => {
        setInput(cmd);
    };

    return (
        <div className="bg-[#0c0c0c] border border-cyber-cyan/30 rounded-lg overflow-hidden font-mono text-xs shadow-[0_0_20px_rgba(0,243,255,0.1)] flex flex-col h-[350px]">
            {/* Header */}
            <div className="bg-cyber-gray/30 p-2 border-b border-cyber-cyan/20 flex justify-between items-center">
                <div className="flex items-center gap-2 text-cyber-cyan">
                    <Terminal className="w-4 h-4" />
                    <span className="font-bold tracking-widest">SOLANA_CLI_WRAPPER</span>
                </div>
                <div className="flex gap-2">
                    <div className="flex items-center gap-1 text-[10px] text-green-500">
                        <Server className="w-3 h-3" />
                        RPC: CONNECTED
                    </div>
                </div>
            </div>

            {/* Logs Area */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2 text-gray-300 custom-scrollbar font-mono leading-relaxed">
                {logs.map((log, i) => (
                    <div key={i} className={`break-words ${
                        log.type === 'req' ? 'text-white font-bold mt-2' : 
                        log.type === 'res' ? 'text-cyber-cyan pl-2 border-l-2 border-cyber-cyan/30 whitespace-pre-wrap' : 
                        'text-gray-500 italic'
                    }`}>
                        {log.content}
                    </div>
                ))}
                {isProcessing && <div className="text-cyber-cyan animate-pulse">Executing command sequence...</div>}
            </div>

            {/* Quick Actions */}
            <div className="flex gap-2 p-2 bg-black/50 border-t border-gray-800 overflow-x-auto">
                <button onClick={() => runQuickCmd('solana balance')} className="px-3 py-1 bg-cyber-cyan/10 text-cyber-cyan border border-cyber-cyan/30 rounded hover:bg-cyber-cyan/20 text-[10px] whitespace-nowrap flex items-center gap-1">
                    <Command className="w-3 h-3" /> Balance
                </button>
                <button onClick={() => runQuickCmd('solana address')} className="px-3 py-1 bg-cyber-cyan/10 text-cyber-cyan border border-cyber-cyan/30 rounded hover:bg-cyber-cyan/20 text-[10px] whitespace-nowrap flex items-center gap-1">
                    <Command className="w-3 h-3" /> Address
                </button>
                <button onClick={() => runQuickCmd('spl-token accounts')} className="px-3 py-1 bg-cyber-purple/10 text-cyber-purple border border-cyber-purple/30 rounded hover:bg-cyber-purple/20 text-[10px] whitespace-nowrap flex items-center gap-1">
                    <Database className="w-3 h-3" /> Tokens
                </button>
                <button onClick={() => runQuickCmd('solana cluster-version')} className="px-3 py-1 bg-gray-800 text-gray-400 border border-gray-700 rounded hover:bg-gray-700 text-[10px] whitespace-nowrap">
                    Version
                </button>
            </div>

            {/* Input Line */}
            <div className="p-3 bg-black flex items-center gap-2 border-t border-cyber-cyan/30">
                <ChevronRight className="w-4 h-4 text-cyber-cyan animate-pulse" />
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="solana command..."
                    className="flex-1 bg-transparent border-none outline-none text-white placeholder-gray-700 font-mono"
                    autoFocus
                />
                <Send className="w-4 h-4 text-cyber-cyan cursor-pointer hover:text-white" onClick={() => handleKeyDown({ key: 'Enter' } as any)} />
            </div>
        </div>
    );
};
