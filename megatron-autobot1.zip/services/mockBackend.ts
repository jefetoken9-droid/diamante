import { UserProfile, UserTier } from "../types";
import { DIAMOND_PRICE_USD } from "../constants";

// In-memory simulation of the 'users' and 'airdrop_distribution' tables
const usersTable: Record<string, UserProfile> = {};
const withdrawalsTable: any[] = [];
const paymentsTable: any[] = [];
const cardsTable: any[] = [];

// Deterministic random generator for consistent demo data
const seededRandom = (seed: number) => {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
};

export const fetchUserProfile = async (walletAddress: string): Promise<UserProfile> => {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));

    if (!usersTable[walletAddress]) {
        // Create new user logic (Simulating DB Insert)
        const seed = walletAddress.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
        const rand = seededRandom(seed);

        let tier: UserTier = 'bronze';
        let allocation = 500; // Base allocation

        if (rand > 0.95) {
            tier = 'platinum';
            allocation = 25000;
        } else if (rand > 0.8) {
            tier = 'gold';
            allocation = 5000;
        } else if (rand > 0.5) {
            tier = 'silver';
            allocation = 1500;
        }

        // KYC status simulation
        const kycStatus = rand > 0.3 ? 'verified' : 'pending';

        usersTable[walletAddress] = {
            id: `user_${seed}`,
            walletAddress,
            tier,
            kycStatus,
            totalAirdropUsd: allocation,
            claimedAirdropUsd: 0,
            tokensPending: allocation / DIAMOND_PRICE_USD
        };
    }

    return usersTable[walletAddress];
};

export const recordWithdrawal = async (
    walletAddress: string, 
    provider: 'MOONPAY' | 'MERCADOPAGO', 
    amountUsd: number,
    details: string
) => {
    // Simulate DB Insert into 'moonpay_transactions' or 'mercado_pago_withdrawals'
    const record = {
        id: `tx_${Date.now()}`,
        wallet_address: walletAddress,
        provider,
        amount_usd: amountUsd,
        details,
        status: 'pending',
        created_at: new Date().toISOString()
    };
    
    withdrawalsTable.push(record);
    console.log(`[BACKEND] Withdrawal Recorded:`, record);
    
    // Simulate processing
    return new Promise((resolve) => {
        setTimeout(() => {
            console.log(`[BACKEND] Withdrawal Processed: ${record.id}`);
            resolve({ success: true, txId: record.id });
        }, 1500);
    });
};

export const claimAirdrop = async (walletAddress: string) => {
    const user = usersTable[walletAddress];
    if (user && user.claimedAirdropUsd === 0) {
        user.claimedAirdropUsd = user.totalAirdropUsd;
        // Simulate DB Update
        return true;
    }
    return false;
};

// --- Mercado Pago Backend Simulation ---

export const processPayment = async (data: any) => {
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log('[BACKEND] Processing Payment:', data);

    const { transaction_amount, token, payment_method_id, payer } = data;

    // Simulate validation
    if (!token || !payment_method_id) {
        return {
            success: false,
            status: 'rejected',
            status_detail: 'E201', // Missing fields
            message: 'Missing mandatory fields'
        };
    }

    // Simulate approval based on amount (e.g., fail if ends in .99)
    if (transaction_amount.toString().endsWith('.99')) {
        return {
            success: false,
            status: 'rejected',
            status_detail: 'cc_rejected_insufficient_amount',
            message: 'Insufficient funds'
        };
    }

    const paymentRecord = {
        id: `pay_${Date.now()}`,
        status: 'approved',
        status_detail: 'accredited',
        transaction_amount,
        payment_method_id,
        payer,
        date_created: new Date().toISOString()
    };
    paymentsTable.push(paymentRecord);

    return {
        success: true,
        status: 'approved',
        paymentId: paymentRecord.id
    };
};

export const saveCard = async (data: any) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log('[BACKEND] Saving Card:', data);
    
    const cardId = `card_${Date.now()}`;
    const newCard = {
        id: cardId,
        customer_id: data.userId,
        last_four_digits: '4242',
        expiration_month: 12,
        expiration_year: 2028,
        payment_method: { id: 'visa', name: 'Visa' }
    };
    cardsTable.push(newCard);

    return {
        success: true,
        cardId: newCard.id,
        lastFourDigits: newCard.last_four_digits,
        expirationMonth: newCard.expiration_month,
        expirationYear: newCard.expiration_year,
        paymentMethod: newCard.payment_method
    };
};

export const webhookHandler = async (type: string, data: any) => {
    console.log('[BACKEND] Webhook received:', { type, data });
    if (type === 'payment') {
        // Find and update payment status logic would go here
        console.log(`[BACKEND] Updating status for payment ${data.id}...`);
    }
    return { status: 200, message: 'OK' };
};