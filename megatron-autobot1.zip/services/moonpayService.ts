import { MOONPAY_PUBLIC_KEY } from "../constants";

declare global {
  interface Window {
    MoonPayWebSdk: any;
  }
}

// Helper to load SDK logic
const initSdk = (config: any) => {
    if (!window.MoonPayWebSdk) {
      console.error("MoonPay SDK not loaded");
      throw new Error("MoonPay SDK not available");
    }
    return window.MoonPayWebSdk.init(config);
}

export const initMoonPay = async (walletAddress: string, flow: 'buy' | 'sell' = 'buy') => {
  const config: any = {
    flow: flow, // 'buy' or 'sell'
    environment: "sandbox", // Use 'production' in real app
    variant: "overlay",
    params: {
      apiKey: MOONPAY_PUBLIC_KEY,
      walletAddress: walletAddress,
      lockAmount: false,
    },
  };

  // Configure params based on flow
  if (flow === 'buy') {
      config.params.baseCurrencyCode = "usd";
      config.params.defaultCurrencyCode = "sol";
      config.params.quoteCurrencyAmount = 100;
  } else {
      // For Selling (Withdrawal)
      // We are selling Crypto (base) to get Fiat (quote)
      config.params.baseCurrencyCode = "sol"; 
      config.params.quoteCurrencyCode = "usd"; // Withdraw to USD
  }

  return initSdk(config);
};

export const openMoonPayWidget = async (walletAddress: string) => {
    try {
        const sdk = await initMoonPay(walletAddress, 'buy');
        sdk.show();
    } catch (e) {
        console.error("MoonPay Buy Launch Error:", e);
        alert("Failed to launch MoonPay Buy widget.");
    }
};

export const openMoonPayWithdrawal = async (walletAddress: string) => {
    try {
        const sdk = await initMoonPay(walletAddress, 'sell');
        sdk.show();
    } catch (e) {
        console.error("MoonPay Sell Launch Error:", e);
        alert("Failed to launch MoonPay Withdrawal widget. Ensure your IP is in a supported region for Off-ramps.");
    }
};