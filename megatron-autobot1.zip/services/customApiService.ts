
import { WalletState } from "../types";
import { performSwap, transferSOL, getWalletBalance } from "./solanaService";
import { APP_TREASURY_ADDRESS, DIAMOND_TOKEN_ADDRESS } from "../constants";

export interface ApiResponse {
    status: number;
    data?: any;
    error?: string;
}

// Internal Staking/APY State
let currentApy = 420.69; // Base High APY
let totalStaked = 0;

export const handleApiRequest = async (
    method: 'GET' | 'POST',
    endpoint: string,
    body: any,
    wallet: WalletState
): Promise<ApiResponse> => {
    
    // Simulate Network Latency
    await new Promise(resolve => setTimeout(resolve, 600));

    try {
        // --- ENDPOINT: GET /api/balance ---
        if (method === 'GET' && endpoint === '/api/balance') {
            const updatedWallet = await getWalletBalance(wallet);
            return {
                status: 200,
                data: {
                    address: wallet.publicKey,
                    sol: updatedWallet.balance,
                    dmt: updatedWallet.tokens[DIAMOND_TOKEN_ADDRESS] || 0,
                    treasury_address: APP_TREASURY_ADDRESS // Verifying funds go here
                }
            };
        }

        // --- ENDPOINT: GET /api/apy ---
        if (method === 'GET' && endpoint === '/api/apy') {
            // Dynamic APY calculation based on "market volatility" (randomized)
            const fluctuation = (Math.random() * 10) - 5;
            currentApy = Math.max(100, currentApy + fluctuation);
            
            return {
                status: 200,
                data: {
                    token: "DIAMOND (DMT)",
                    apy_percent: currentApy.toFixed(2) + "%",
                    staking_contract: "Native Staking v1",
                    yield_source: "MEGATRON LIQUIDITY PROTOCOL"
                }
            };
        }

        // --- ENDPOINT: POST /api/swap ---
        if (method === 'POST' && endpoint === '/api/swap') {
            if (!body.amount || !body.from || !body.to) {
                return { status: 400, error: "Missing parameters: amount, from, to" };
            }

            const result = await performSwap(wallet, body.from, body.to, parseFloat(body.amount));
            
            if (result.success) {
                return {
                    status: 200,
                    data: {
                        tx_hash: result.txHash,
                        message: result.message,
                        fee_beneficiary: APP_TREASURY_ADDRESS // Explicit confirmation
                    }
                };
            } else {
                return { status: 500, error: result.message };
            }
        }

        // --- ENDPOINT: POST /api/transfer ---
        if (method === 'POST' && endpoint === '/api/transfer') {
            if (!body.amount || !body.to_address) {
                return { status: 400, error: "Missing parameters: amount, to_address" };
            }

            const signature = await transferSOL(wallet, body.to_address, parseFloat(body.amount));
            return {
                status: 200,
                data: {
                    tx_hash: signature,
                    status: "confirmed",
                    network: "Solana Mainnet"
                }
            };
        }

        return { status: 404, error: `Endpoint ${endpoint} not found for method ${method}` };

    } catch (e: any) {
        return { status: 500, error: e.message };
    }
};
