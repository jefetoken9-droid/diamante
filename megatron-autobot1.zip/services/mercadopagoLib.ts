// This file simulates the 'mercadopago' npm package behavior for the frontend environment
// Since we cannot run Node.js modules like 'http' in the browser, we mock the classes.

export class MercadoPagoConfig {
  accessToken: string;
  options: any;

  constructor(config: { accessToken: string; options?: any }) {
    this.accessToken = config.accessToken;
    this.options = config.options;
  }
}

export class Order {
  client: MercadoPagoConfig;

  constructor(client: MercadoPagoConfig) {
    this.client = client;
  }

  async create(params: { body: any; requestOptions?: any }) {
    console.log("[MercadoPago SDK] Creating Order...", params);
    
    // Simulate API Network Delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Validation Simulation
    if (!this.client.accessToken) {
        throw new Error("Missing Access Token");
    }

    const { body } = params;

    // Log additional fields if present, simulating the /v1/orders endpoint
    if (body.type) console.log(`[MercadoPago SDK] Order Type: ${body.type}`);
    if (body.config?.point) console.log(`[MercadoPago SDK] Point Config:`, body.config.point);
    if (body.taxes) console.log(`[MercadoPago SDK] Taxes:`, body.taxes);

    // Return a mock successful response structure from Mercado Pago API
    return {
        id: `ord_${Date.now()}`,
        status: "opened",
        status_detail: "accredited",
        date_created: new Date().toISOString(),
        total_amount: body.total_amount,
        payer: body.payer,
        items: body.items,
        sandbox: true,
        init_point: `https://sandbox.mercadopago.com.mx/checkout/v1/redirect?pref_id=${Date.now()}`
    };
  }

  async search(params?: any) {
      // Mock search for orders
      return {
          results: []
      }
  }
}