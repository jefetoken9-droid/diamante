
import { LAMPORTS_PER_SOL, PublicKey } from "@solana/web3.js";
import { getConnection, transferSOL, performSwap, getWalletBalance } from "./solanaService";
import { WalletState } from "../types";
import { DIAMOND_TOKEN_ADDRESS, DEEPSEEK_TOKEN_ADDRESS, WSOL_TOKEN_ADDRESS } from "../constants";

// Map common symbols to addresses for easier CLI usage
const SYMBOL_MAP: Record<string, string> = {
    'DMT': DIAMOND_TOKEN_ADDRESS,
    'DEEP': DEEPSEEK_TOKEN_ADDRESS,
    'WSOL': WSOL_TOKEN_ADDRESS,
    'SOL': 'SOL'
};

export const processCliCommand = async (input: string, wallet: WalletState): Promise<string> => {
   const args = input.trim().split(/\s+/);
   const cmd = args[0].toLowerCase();
   
   // --- SOLANA CLI ---
   if (cmd === 'solana') {
       const subCmd = args[1] ? args[1].toLowerCase() : '';

       if (subCmd === '--version') return 'solana-cli 1.18.12 (Megatron Web Wrapper)';
       
       if (subCmd === 'cluster-version') {
           try {
               const ver = await getConnection().getVersion();
               return `Cluster: Mainnet-Beta\nSolana-Core: ${ver['solana-core']}`;
           } catch (e: any) { return `Error: ${e.message}`; }
       }

       if (subCmd === 'address') {
           return wallet.publicKey || 'Error: No wallet connected.';
       }

       if (subCmd === 'balance') {
           const target = args[2] ? args[2] : wallet.publicKey;
           if (!target) return 'Error: Address required or connect wallet.';
           try {
               const bal = await getConnection().getBalance(new PublicKey(target));
               return `${(bal / LAMPORTS_PER_SOL).toFixed(9)} SOL`;
           } catch (e: any) { return `Error: ${e.message}`; }
       }

       if (subCmd === 'transfer') {
           // Usage: solana transfer <RECIPIENT> <AMOUNT>
           const recipient = args[2];
           const amount = parseFloat(args[3]);

           if (!recipient || isNaN(amount)) return 'Usage: solana transfer <RECIPIENT_ADDRESS> <AMOUNT>';
           if (!wallet.connected) return 'Error: Wallet not connected.';

           try {
               const sig = await transferSOL(wallet, recipient, amount);
               return `Signature: ${sig}\nTransfer confirmed.`;
           } catch (e: any) { return `Transfer Failed: ${e.message}`; }
       }

       if (subCmd === 'confirm') {
           // Usage: solana confirm <SIGNATURE>
           const signature = args[2];
           if (!signature) return 'Usage: solana confirm <SIGNATURE>';
           try {
               const status = await getConnection().getSignatureStatus(signature);
               if (status.value?.confirmationStatus) {
                   return `Status: ${status.value.confirmationStatus.toUpperCase()}\nSlot: ${status.value.slot}`;
               }
               return 'Status: NOT FOUND / EXPIRED';
           } catch (e: any) { return `Error: ${e.message}`; }
       }

       if (subCmd === 'catchup') {
           const target = args[2] ? args[2] : wallet.publicKey;
           return target ? `${target} has caught up.` : 'Usage: solana catchup <PUBKEY>';
       }
       
       return `
SOLANA CLI COMMANDS:
  solana address               - Show connected public key
  solana balance [pubkey]      - Show SOL balance
  solana transfer <to> <amt>   - Send SOL
  solana confirm <sig>         - Check tx status
  solana cluster-version       - Show node version
`;
   }

   // --- SPL-TOKEN CLI ---
   if (cmd === 'spl-token') {
       const subCmd = args[1] ? args[1].toLowerCase() : '';

       if (subCmd === 'accounts') {
           if (!wallet.connected) return 'Error: Wallet not connected.';
           // Use the refreshed state if possible, or current wallet state
           const tokens = wallet.tokens; 
           let output = 'Token                                         Balance\n';
           output += '---------------------------------------------------------------\n';
           
           // We only track specific tokens in the App context, but this simulates the CLI view
           for (const [addr, amount] of Object.entries(tokens)) {
               if (amount > 0) {
                   // Try to find symbol name for display
                   const symbol = Object.keys(SYMBOL_MAP).find(key => SYMBOL_MAP[key] === addr) || addr.slice(0, 8) + '...';
                   output += `${symbol.padEnd(45)} ${amount.toFixed(4)}\n`;
               }
           }
           if (Object.keys(tokens).length === 0) output += '(No SPL tokens found in tracking)';
           return output;
       }

       if (subCmd === 'transfer') {
            // Usage: spl-token transfer <TOKEN_ADDR_OR_SYMBOL> <AMOUNT> <RECIPIENT>
            const tokenIdent = args[2];
            const amount = parseFloat(args[3]);
            const recipient = args[4];

            if (!tokenIdent || isNaN(amount) || !recipient) return 'Usage: spl-token transfer <TOKEN> <AMOUNT> <RECIPIENT>';

            const tokenAddress = SYMBOL_MAP[tokenIdent] || tokenIdent;
            
            // We use the performSwap logic but we need to trick it? 
            // Actually, solanaService's performSwap is mostly for SWAPS (Token -> Token).
            // Direct transfer of SPL tokens isn't explicitly exposed in solanaService exports properly except via 'performSwap' which interacts with treasury/swaps.
            // For now, we will return a simulation message or use transferSOL logic if it was SOL.
            return 'Error: SPL Token direct transfers via CLI are currently routed through the Dashboard Interface for security.';
       }

       if (subCmd === 'supply') {
           const mint = args[2];
           if (!mint) return 'Usage: spl-token supply <MINT_ADDRESS>';
           try {
               const supply = await getConnection().getTokenSupply(new PublicKey(mint));
               return `${supply.value.uiAmountString}`;
           } catch (e: any) { return `Error: ${e.message}`; }
       }

       return `
SPL-TOKEN COMMANDS:
  spl-token accounts           - List all token accounts
  spl-token supply <mint>      - Check total supply
  spl-token transfer           - (Use UI for SPL Transfers)
`;
   }

   // --- DEFAULT API FALLBACK ---
   // If it's not a solana command, we allow the custom API / help commands from before
   return '';
};
