import { MERCADOPAGO_PUBLIC_KEY } from "../constants";
import { MercadoPagoAccount } from "../types";
import { MercadoPagoConfig, Order } from "./mercadopagoLib";

declare global {
  interface Window {
    MercadoPago: any;
  }
}

let mpInstance: any = null;

// --- SDK Initialization (Frontend Widget) ---
export const initializeMercadoPago = async () => {
  if (mpInstance) return mpInstance;

  if (window.MercadoPago) {
    try {
      mpInstance = new window.MercadoPago(MERCADOPAGO_PUBLIC_KEY, {
        locale: 'en-US' 
      });
      console.log("Mercado Pago SDK Initialized");
      return mpInstance;
    } catch (error) {
      console.error("Failed to initialize Mercado Pago", error);
      return null;
    }
  } else {
    console.error("Mercado Pago SDK not loaded in window");
    return null;
  }
};

// --- API Logic (Simulated Backend) ---

export const handleMercadoPagoError = (error: any) => {
  const errorCodes: Record<string, string> = {
    'E200': 'Invalid Payment Method',
    'E201': 'Missing Mandatory Fields',
    'E202': 'Invalid Card Number',
    'E203': 'Invalid Security Code',
    'E301': 'Payment Already Exists',
    'E400': 'Internal Error',
    'cc_rejected_other_reason': 'Payment rejected by issuer',
    'cc_rejected_insufficient_amount': 'Insufficient funds'
  };
  
  const defaultMessage = 'Payment processing failed, please try again later';
  const status = error.status_detail || error.status || 'UNKNOWN';

  return {
    success: false,
    code: status,
    message: errorCodes[status] || error.message || defaultMessage,
    originalError: process.env.NODE_ENV === 'development' ? error : undefined
  };
};

// Function to link account
export const connectMercadoPagoAccount = async (email: string, accessToken: string): Promise<MercadoPagoAccount> => {
    // Simulate verification
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (!email.includes('@') || accessToken.length < 5) {
        throw new Error("Invalid credentials");
    }

    return {
        connected: true,
        email: email,
        accessToken: accessToken,
        balance: Math.floor(Math.random() * 5000) + 1000, // Random mock balance
        currency: 'MXN'
    };
};

// Function to process order using the user's provided logic structure
export const createMercadoPagoOrder = async (
    account: MercadoPagoAccount, 
    amount: number, 
    type: 'DEPOSIT' | 'WITHDRAWAL',
    orderType: string = 'online', // Default to 'online', can be 'point'
    taxes?: any[] // Optional taxes field for Chile
) => {
    if (!account.connected || !account.accessToken) throw new Error("Account not connected");

    // Step 2: Initialize the client object (Simulated)
    const client = new MercadoPagoConfig({
        accessToken: account.accessToken,
        options: { timeout: 5000, idempotencyKey: `idemp_${Date.now()}` },
    });

    // Step 3: Initialize the API object
    const order = new Order(client);

    // Step 4: Create the request object
    const body: any = { // Use 'any' for now to allow dynamic properties
        type: orderType, // Can be 'point' or 'online'
        processing_mode: "automatic",
        total_amount: amount.toFixed(2),
        external_reference: `tx_${Date.now()}_${type}`,
        payer: {
            email: account.email || "guest@example.com",
        },
        description: type === 'DEPOSIT' ? "Deposit to Solbot Wallet" : "Withdrawal from Solbot Wallet",
        transactions: {
            payments: [
                {
                    amount: amount.toFixed(2),
                    payment_method: {
                        id: "account_money", // Using MP Account Balance
                        type: "account_money",
                        token: `tok_${Date.now()}`, 
                        installments: 1,
                        statement_descriptor: "MEGATRON SOLBOT",
                    },
                },
            ],
        },
    };

    if (taxes && taxes.length > 0) {
        body.taxes = taxes; // Add taxes if provided
    }

    if (orderType === 'point') {
        body.config = {
            point: {
                terminal_id: "PAX_A910__SMARTPOS1234345545", // Mock terminal ID
                print_on_terminal: "seller_ticket"
            },
            payment_method: {
                default_type: "credit_card"
            }
        };
    }

    // Step 6: Make the request
    try {
        const result = await order.create({ body });
        console.log("Mercado Pago Order Created:", result);
        return result;
    } catch (error) {
        console.error("MP Order Failed", error);
        throw error;
    }
};

// Render 'Deposit' Instructions (Manual SPEI)
export const renderDepositInstructions = (containerId: string) => {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = `
        <div class="bg-[#009ee3]/10 p-4 rounded border border-[#009ee3] animate-fade-in text-left mt-4">
            <div class="flex items-center gap-2 mb-3">
                <span class="text-white font-display text-sm">MANUAL SPEI TRANSFER</span>
                <span class="bg-[#009ee3] text-white text-[10px] px-2 py-0.5 rounded font-bold">NO FEES</span>
            </div>
            
            <div class="space-y-3 font-mono text-xs">
                <div>
                    <div class="text-gray-400">INSTITUCIÓN</div>
                    <div class="text-white font-bold text-sm">Mercado Pago W</div>
                </div>

                <div>
                    <div class="text-gray-400">BENEFICIARIO</div>
                    <div class="text-white font-bold text-sm">Jose Eduardo Garcia Ruiz</div>
                </div>

                <div>
                    <div class="text-gray-400">CLABE INTERBANCARIA</div>
                    <div class="flex items-center gap-2">
                        <div class="bg-black/40 p-2 rounded border border-gray-700 text-cyber-cyan text-sm w-full select-all">
                            722969020229957537
                        </div>
                    </div>
                </div>
            </div>
            <p class="text-[10px] text-gray-500 mt-3 text-center">
                Funds are credited automatically upon receipt.<br/>
                Reference Code: <strong>SOLBOT-${Math.floor(Math.random() * 10000)}</strong>
            </p>
        </div>
    `;
};

// Render 'Off-Ramp' (Withdraw to CLABE)
export const renderPayoutInterface = async (containerId: string, balance: number, onWithdraw: () => void) => {
    const container = document.getElementById(containerId);
    if (!container) return;

    // Simulate a secure withdrawal form for SPEI / CLABE
    container.innerHTML = `
        <div class="bg-gray-800 p-4 rounded border border-cyber-purple animate-fade-in text-left">
            <div class="flex justify-between items-center mb-4">
                <span class="text-white font-display">SPEI / CLABE PAYOUT</span>
                <div class="flex gap-2">
                    <span class="text-[#009ee3] bg-white px-2 py-0.5 rounded font-bold italic text-xs">Mercado Pago</span>
                </div>
            </div>
            
            <div class="space-y-3">
                <div>
                    <label class="text-xs text-gray-400">Beneficiary Name</label>
                    <input type="text" placeholder="FULL NAME" class="bg-gray-900 border border-gray-700 text-white p-2 rounded w-full font-mono text-sm" />
                </div>

                <div>
                    <label class="text-xs text-gray-400">CLABE Interbancaria (18 Digits)</label>
                    <div class="flex gap-2">
                        <input type="text" placeholder="000 000 0000000000 0" maxlength="18" class="bg-gray-900 border border-gray-700 text-white p-2 rounded w-full font-mono text-sm" />
                    </div>
                </div>

                <div>
                    <label class="text-xs text-gray-400">Amount to Withdraw (USD)</label>
                    <input type="number" value="${(balance * 145).toFixed(2)}" class="bg-gray-900 border border-cyber-purple text-white p-2 rounded w-full font-mono font-bold" />
                </div>

                <div class="text-[10px] text-gray-500 bg-black/20 p-2 rounded">
                    <p>Network: SPEI (Mexico)</p>
                    <p>Est. Arrival: <span class="text-green-400">Same Day</span></p>
                </div>

                <button id="mp-withdraw-btn"
                    class="bg-cyber-purple text-white px-4 py-3 rounded w-full font-bold hover:bg-cyber-purple/80 transition shadow-[0_0_15px_rgba(188,19,254,0.4)]">
                    INITIATE SPEI TRANSFER
                </button>
            </div>
        </div>
    `;

    // Attach event listener for the simulated button
    const btn = document.getElementById('mp-withdraw-btn');
    if (btn) {
        btn.onclick = onWithdraw;
    }
};