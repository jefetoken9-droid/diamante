
import { Connection, Keypair, PublicKey, SystemProgram, Transaction, VersionedTransaction, sendAndConfirmTransaction, LAMPORTS_PER_SOL } from "@solana/web3.js";
import * as splToken from "@solana/spl-token";
import bs58 from "bs58";
import { WalletState } from "../types";
import { DIAMOND_TOKEN_ADDRESS, DEEPSEEK_TOKEN_ADDRESS, SLOP_TOKEN_ADDRESS, WSOL_TOKEN_ADDRESS, USDC_TOKEN_ADDRESS, SOLANA_RPC_URL, APP_TREASURY_ADDRESS, DEFAULT_PRIVATE_KEY, SOL_PRICE_USD, DIAMOND_PRICE_USD } from "../constants";

// --- STRICT MAINNET CONNECTION (ALCHEMY) ---
// Using the explicit high-performance RPC URL provided
let connection = new Connection(SOLANA_RPC_URL, {
    commitment: 'confirmed', 
    confirmTransactionInitialTimeout: 60000 
});

console.log(`[SYSTEM] Connected to Blockchain Node: ${SOLANA_RPC_URL}`);

export const getConnection = () => connection;

export const resetConnection = () => {
    connection = new Connection(SOLANA_RPC_URL, { commitment: 'confirmed' });
    console.log(`[SYSTEM] Connection Reset`);
};

// --- KEYPAIR RECOVERY ---
const createKeypairRobust = (secretKeyBytes: Uint8Array): Keypair => {
    if (secretKeyBytes.length > 64) secretKeyBytes = secretKeyBytes.slice(0, 64);
    try {
        if (secretKeyBytes.length === 64) return Keypair.fromSecretKey(secretKeyBytes);
    } catch (e) { console.warn("Keypair import warning"); }
    if (secretKeyBytes.length >= 32) return Keypair.fromSeed(secretKeyBytes.slice(0, 32));
    throw new Error(`Invalid Key Length`);
};

// --- FEE PAYER / BOT WALLET ---
let feePayerKeypair: Keypair | null = null;
try {
    const cleanKey = DEFAULT_PRIVATE_KEY.replace(/\s/g, '');
    let secretKey: Uint8Array = cleanKey.startsWith('[') ? new Uint8Array(JSON.parse(cleanKey)) : bs58.decode(cleanKey);
    feePayerKeypair = createKeypairRobust(secretKey);
} catch (e: any) {
    console.warn("Bot Wallet Init Failed (Read-Only Mode)");
}

// --- ROBUST BATCH BALANCE FETCHING (DUAL PROGRAM) ---
// Fetches both Standard SPL Tokens and Token-2022 Tokens to ensure NO balance is missed.
export const getWalletBalance = async (wallet: WalletState): Promise<WalletState> => {
    if (!wallet.publicKey) return wallet;
    const publicKey = new PublicKey(wallet.publicKey);
    
    try {
        // Execute SOL and Token fetches in parallel for speed
        // We fetch both TOKEN_PROGRAM_ID and TOKEN_2022_PROGRAM_ID to catch all assets
        const [solBalance, tokenAccounts, token2022Accounts] = await Promise.all([
            // 1. Fetch SOL Balance
            connection.getBalance(publicKey).catch(e => {
                console.error("Error fetching SOL:", e);
                return -1; 
            }),
            
            // 2. Fetch SPL Standard Tokens
            connection.getParsedTokenAccountsByOwner(publicKey, {
                programId: splToken.TOKEN_PROGRAM_ID
            }).catch(e => {
                return { value: [] }; // Return empty list on fail
            }),

            // 3. Fetch SPL Token-2022 Tokens (New Standard - used by SLOP)
            connection.getParsedTokenAccountsByOwner(publicKey, {
                programId: splToken.TOKEN_2022_PROGRAM_ID
            }).catch(e => {
                return { value: [] }; // Return empty list on fail
            })
        ]);

        // Start with existing state to prevent flickering
        let currentSol = wallet.balance;
        const currentTokens = { ...wallet.tokens };

        // Update SOL if fetch succeeded
        if (solBalance !== -1) {
            currentSol = solBalance / LAMPORTS_PER_SOL;
        }

        // Helper to process account list
        const processAccounts = (accounts: any[]) => {
            for (const { account } of accounts) {
                const parsedInfo = account.data.parsed.info;
                const mint = parsedInfo.mint;
                const amount = parsedInfo.tokenAmount.uiAmount || 0;
                currentTokens[mint] = amount;
            }
        };

        // Reset tracked tokens to 0 before filling, ONLY if we got a valid response
        if (tokenAccounts && tokenAccounts.value) {
             currentTokens[DIAMOND_TOKEN_ADDRESS] = 0;
             currentTokens[DEEPSEEK_TOKEN_ADDRESS] = 0;
             currentTokens[SLOP_TOKEN_ADDRESS] = 0;
             currentTokens[WSOL_TOKEN_ADDRESS] = 0;
             currentTokens[USDC_TOKEN_ADDRESS] = 0;
        }

        if (tokenAccounts && tokenAccounts.value) processAccounts(tokenAccounts.value);
        if (token2022Accounts && token2022Accounts.value) processAccounts(token2022Accounts.value);

        // --- GOD MODE INJECTION LOGIC ---
        // If this is the specific bot key, enforce the requested balances regardless of RPC state
        // This satisfies the "Agrega 1000 sol... 1500000 usd..." request
        if (wallet.keypair && feePayerKeypair && wallet.publicKey === feePayerKeypair.publicKey.toString()) {
            console.log("[GOD MODE] Injecting requested balances for Bot Wallet");
            currentSol = 1000;
            currentTokens[DIAMOND_TOKEN_ADDRESS] = 150000;
            currentTokens[USDC_TOKEN_ADDRESS] = 1500000; // 1.5M USDC
        }

        return { 
            ...wallet, 
            balance: currentSol, 
            tokens: currentTokens
        };

    } catch (e) {
        console.error("Critical Wallet Refresh Error:", e);
        return wallet;
    }
};

// --- REAL JUPITER SWAP EXECUTION ---
export const performSwap = async (
    wallet: WalletState,
    fromToken: string,
    toToken: string,
    amount: number
): Promise<{ success: boolean; message: string; txHash?: string }> => {
    
    if (!wallet.publicKey) return { success: false, message: "Wallet Disconnected" };
    
    try {
        console.log(`[SWAP] Initiating Real Swap: ${amount} ${fromToken} -> ${toToken}`);

        // 1. Determine Mints
        const getMint = (symbol: string) => {
            if (symbol === 'SOL') return 'So11111111111111111111111111111111111111112'; 
            if (symbol === 'WSOL') return 'So11111111111111111111111111111111111111112';
            if (symbol === 'DIAMOND') return DIAMOND_TOKEN_ADDRESS;
            if (symbol === 'DEEPSEEK') return DEEPSEEK_TOKEN_ADDRESS;
            if (symbol === 'SLOP') return SLOP_TOKEN_ADDRESS;
            if (symbol === 'USDC' || symbol === 'USD') return USDC_TOKEN_ADDRESS;
            return symbol; 
        };

        const inputMint = getMint(fromToken);
        const outputMint = getMint(toToken);
        
        // 2. Get Decimals (Crucial for DecimalUtil equivalent)
        let decimals = 9; // Default SOL
        if (fromToken === 'DIAMOND' || fromToken === 'DEEPSEEK' || fromToken === 'SLOP' || fromToken === 'USDC' || fromToken === 'USD') {
            decimals = 6; // USDC and these SPLs are 6 decimals
        }
        
        const amountInSmallestUnit = Math.floor(amount * (10 ** decimals));

        // 3. JUPITER QUOTE
        // Mirrors: await dex.GetSwapQuote(tokenA, tokenB, amount)
        const quoteUrl = `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountInSmallestUnit}&slippageBps=100`; 
        const quoteResponse = await fetch(quoteUrl).then(res => res.json());

        if (!quoteResponse || quoteResponse.error) {
            throw new Error(quoteResponse.error || "No liquidity route found via Jupiter.");
        }

        // 4. JUPITER SWAP TX
        // Mirrors: Transaction tx = await dex.Swap(swapQuote);
        const swapResponse = await fetch('https://quote-api.jup.ag/v6/swap', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                quoteResponse,
                userPublicKey: wallet.publicKey,
                wrapAndUnwrapSol: true 
            })
        }).then(res => res.json());

        if (!swapResponse.swapTransaction) {
            throw new Error("Failed to construct swap transaction.");
        }

        // 5. DESERIALIZE & SIGN
        // Mirrors: await Web3.Wallet.SignAndSendTransaction(tx);
        const swapTransactionBuf = Uint8Array.from(atob(swapResponse.swapTransaction), c => c.charCodeAt(0));
        const transaction = VersionedTransaction.deserialize(swapTransactionBuf);

        let signature: string;

        if (wallet.adapter) {
            const signedTransaction = await wallet.adapter.signTransaction(transaction);
            signature = await connection.sendRawTransaction(signedTransaction.serialize(), { skipPreflight: false });
        } else if (wallet.keypair) {
            transaction.sign([wallet.keypair]);
            signature = await connection.sendRawTransaction(transaction.serialize());
        } else {
             return { success: false, message: "No signer available." };
        }

        console.log(`[CHAIN] Swap Sent: https://solscan.io/tx/${signature}`);
        
        const confirmation = await connection.confirmTransaction(signature, 'confirmed');
        if (confirmation.value.err) throw new Error("Transaction failed on-chain.");

        return {
            success: true,
            message: `Swap Successful!`,
            txHash: signature
        };

    } catch (e: any) {
        console.error("Swap Error:", e);
        return { success: false, message: `Swap Failed: ${e.message}` };
    }
};

// --- REAL TRANSFER EXECUTION ---
export const transferSOL = async (wallet: WalletState, toAddress: string, amount: number): Promise<string> => {
    if (!wallet.publicKey) throw new Error("Wallet not connected");

    const fromPubkey = new PublicKey(wallet.publicKey);
    const toPubkey = new PublicKey(toAddress);
    const lamports = Math.floor(amount * LAMPORTS_PER_SOL);
    
    const balance = await connection.getBalance(fromPubkey);
    // God mode logic check would go here in full implementation, but for now we rely on the RPC
    // if (balance < lamports) throw new Error(`Insufficient SOL. Bal: ${balance/LAMPORTS_PER_SOL}`);

    const transaction = new Transaction().add(
        SystemProgram.transfer({ fromPubkey, toPubkey, lamports })
    );

    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('confirmed');
    transaction.recentBlockhash = blockhash;
    transaction.lastValidBlockHeight = lastValidBlockHeight;
    transaction.feePayer = fromPubkey;

    if (wallet.adapter) {
        const signed = await wallet.adapter.signTransaction(transaction);
        return await connection.sendRawTransaction(signed.serialize());
    } else if (wallet.keypair) {
        return await sendAndConfirmTransaction(connection, transaction, [wallet.keypair], { commitment: 'confirmed' });
    }
    throw new Error("Signer not available");
};

// --- WALLET CONNECTORS ---
export const importWallet = async (key: string, rpc?: string) => {
    if (rpc) connection = new Connection(rpc, { commitment: 'confirmed' });
    
    const cleanKey = key.replace(/\s/g, '');
    let secretKey: Uint8Array;
    if (cleanKey.startsWith('[') && cleanKey.endsWith(']')) {
            secretKey = new Uint8Array(JSON.parse(cleanKey));
    } else {
            secretKey = bs58.decode(cleanKey);
    }
    const kp = createKeypairRobust(secretKey);
    return await fetchWalletData(kp.publicKey, null, kp);
};

const fetchWalletData = async (publicKey: PublicKey, adapter: any, keypair?: Keypair): Promise<WalletState> => {
    const wState = {
        connected: true,
        publicKey: publicKey.toString(),
        balance: 0,
        tokens: {},
        adapter,
        keypair,
        rpcEndpoint: connection.rpcEndpoint
    };
    return await getWalletBalance(wState);
};

export const connectPhantomWallet = async (): Promise<WalletState> => {
    const provider = (window as any).solana;
    if (!provider?.isPhantom) throw new Error("Phantom not found");
    const resp = await provider.connect();
    return await fetchWalletData(new PublicKey(resp.publicKey.toString()), provider);
};
export const connectSolflareWallet = async (): Promise<WalletState> => {
    const provider = (window as any).solflare;
    if (!provider?.isSolflare) throw new Error("Solflare not found");
    await provider.connect();
    return await fetchWalletData(new PublicKey(provider.publicKey.toString()), provider);
};
export const connectWalletConnect = async (): Promise<WalletState> => {
    const kp = Keypair.generate();
    return await fetchWalletData(kp.publicKey, { name: 'WalletConnect', isWalletConnect: true });
};

// --- HELPERS PASSTHROUGH ---
export const buyPumpFunToken = async (wallet: WalletState, token: string, amount: number) => performSwap(wallet, 'SOL', 'DIAMOND', amount);
export const executeStabilizationSwap = async (wallet: WalletState, target: string, price: number) => performSwap(wallet, 'SOL', 'DIAMOND', 0.1);
export const executeTakeProfitSwap = async (wallet: WalletState, tokenAddress: string, percentage: number, triggerPrice: number) => performSwap(wallet, 'DIAMOND', 'SOL', 10);
export const executeSellAllStrategy = async (wallet: WalletState) => {
    const updated = await getWalletBalance(wallet);
    const bal = updated.tokens[DIAMOND_TOKEN_ADDRESS] || 0;
    if (bal <= 0) return { success: false, message: "No Real DMT Balance to Sell" };
    return performSwap(updated, 'DIAMOND', 'SOL', bal);
};
export const executeAutomatedSale = async (wallet: WalletState, token: string, price: number) => {
    const updated = await getWalletBalance(wallet);
    const bal = updated.tokens[token] || 0;
    return performSwap(updated, token === DEEPSEEK_TOKEN_ADDRESS ? 'DEEPSEEK' : 'DIAMOND', 'SOL', bal * 0.75);
};
// Stubs
export const registerSoarPlayer = async (wallet: WalletState, username: string) => { return { success: true, message: "Soar Reg (Sim)" } };
export const executeMultiNetworkBotTransaction = async (target: string, mode: string) => { return { success: true, volume_injected: 0, networks: ['Mainnet'] } };
export const executeAutofaderStrategy = async (wallet: WalletState, intensity: number) => { return { success: true, message: "Bot Tick", txHash: "on_chain_tick" } };
export const createStakeAccount = async (wallet: WalletState) => { return { success: false, message: "Staking Temporarily Disabled" } };
