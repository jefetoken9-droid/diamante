

import { PoolData } from "../types";
import { MARKET_OVERRIDE } from "../constants";

export const fetchPoolData = async (poolAddress: string): Promise<PoolData | null> => {
  try {
    const targetUrl = `https://api.geckoterminal.com/api/v2/networks/solana/pools/${poolAddress}`;
    
    // Strategy: Try primary proxy (corsproxy.io), fallback to secondary (allorigins)
    let response;
    let errorDetails;

    try {
        // Primary Proxy
        response = await fetch(`https://corsproxy.io/?${encodeURIComponent(targetUrl)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        });
        if (!response.ok) throw new Error(`Primary proxy returned ${response.status}`);
    } catch (e1: any) {
        try {
            // Fallback Proxy
            response = await fetch(`https://api.allorigins.win/raw?url=${encodeURIComponent(targetUrl)}`);
            if (!response.ok) throw new Error(`Fallback proxy returned ${response.status}`);
        } catch (e2: any) {
            errorDetails = e2.message;
        }
    }

    if (!response || !response.ok) {
        throw new Error(`All proxies failed. Last error: ${errorDetails || 'Unknown Network Error'}`);
    }

    const data = await response.json();

    if (data.errors) {
        throw new Error(`Gecko API Error: ${data.errors[0]?.title || 'Unknown error'}`);
    }

    if (!data.data || !data.data.attributes) {
        throw new Error("Invalid data structure from GeckoTerminal");
    }

    const attrs = data.data.attributes;

    let priceUsd = parseFloat(attrs.base_token_price_usd);
    let marketCap = parseFloat(attrs.market_cap_usd || '0');
    let fdv = parseFloat(attrs.fdv_usd || '0');

    // ONLY apply override if enabled in constants
    if (MARKET_OVERRIDE.ENABLED) {
        const newPrice = MARKET_OVERRIDE.TARGET_PRICE;
        const ratio = newPrice / (priceUsd || 1);

        priceUsd = newPrice;
        
        if (marketCap > 0) marketCap = marketCap * ratio;
        else marketCap = 3880.78 * ratio; 

        if (fdv > 0) fdv = fdv * ratio;
        else fdv = marketCap;
    }

    return {
      priceUsd: priceUsd.toString(),
      priceChange24h: attrs.price_change_percentage.h24,
      volume24h: attrs.volume_usd.h24,
      liquidity: attrs.reserve_in_usd,
      marketCap: marketCap.toString(),
      fdv: fdv.toString(),
      pairName: attrs.name
    };
  } catch (e) {
    console.warn("GeckoTerminal Data Uplink Failed:", e);
    // STRICT MODE: Return NULL, do NOT return mock data
    return null;
  }
};
