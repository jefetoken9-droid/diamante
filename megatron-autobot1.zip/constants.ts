


export const ALCHEMY_API_KEY = "lP4xifvXj_XdyQUgUMoL8";
export const SOLANA_RPC_URL = `https://solana-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;
export const DEVNET_RPC_URL = "https://api.devnet.solana.com";

// PRINCIPAL TOKEN (Diamond - DMT) - Also acting as the Trade Receiver in this config
export const DIAMOND_TOKEN_ADDRESS = "5zJo2GzYRgiZw5j3SBNpuqVcGok35kT3ADwsw74yJWV6";

// NEW TOKEN: SLOP (Token-2022 Standard)
export const SLOP_TOKEN_ADDRESS = "A8YFC9X61bz9SCbmLkccitqM7mXqqHKN2hBZx1Y3pump";

// WRAPPED SOL (WSOL) - Official Mint
export const WSOL_TOKEN_ADDRESS = "So11111111111111111111111111111111111111112";

// USDC (Official Circle Mint)
export const USDC_TOKEN_ADDRESS = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";

// ALICE / ROBOT ADDRESS (The Mainnet Operator)
export const ALICE_ADDRESS = "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM";

// GLOBAL FEE PAYER (Gas Station) - Configured to Robot Address
export const GAS_PAYER_ADDRESS = "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM";

// UTILITY / SECONDARY TOKEN (DeepSeek - DEEP)
export const DEEPSEEK_TOKEN_ADDRESS = "4AtnF1pPmqABPDQtCogqS2LqDkNtuzMg76yQRjuJpump";

// SOAR GAMING PROTOCOL PROGRAM ID
export const SOAR_PROGRAM_ID = "Soar111111111111111111111111111111111111111"; 

// Pool Address for Data Reference
export const POOL_ADDRESS = "8oiVbfQT4ErS1wciaTuJhCSn1EuPn37wThA5MypiBq6K";

// Target Addresses for Bot Operations (Real On-Chain Targets)
export const TARGET_WHALE_WALLETS = [
    "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM", // Alice (Robot)
    "DNtKVnhBub6ikXE782PK64ZUv8GgaAWQyVTgDrEvxUDV",
    "8NJQmfZnPnc3uPFC5TGkvNm6WfwDgpeWT78KbPakSuYo",
    "5zJo2GzYRgiZw5j3SBNpuqVcGok35kT3ADwsw74yJWV6"
];

// Wallet that receives the Trade/Gas Fees (Receiver Address)
export const APP_TREASURY_ADDRESS = "5zJo2GzYRgiZw5j3SBNpuqVcGok35kT3ADwsw74yJWV6"; 

export const GAS_FEE_AMOUNT = 50; // Amount of DMT Tokens charged per transaction

// Configured Default Lamport Value (SOL)
export const LAMPORT_VALUE_SOL = 0.10;

// Mercado Pago Public Key
export const MERCADOPAGO_PUBLIC_KEY = "TEST-53093930-1412-4c6e-8c34-846830728373";

// MoonPay Public Key
export const MOONPAY_PUBLIC_KEY = "pk_test_1234567890abcdef"; 

export const STRIPE_PUBLIC_KEY = "pk_test_xxx";

export const EXTERNAL_LINKS = {
  PUMP_FUN: `https://pump.fun/coin/${DIAMOND_TOKEN_ADDRESS}`,
  PHOTON: `https://photon-sol.tinyastro.io/en/lp/${POOL_ADDRESS}`,
  BUBBLEMAPS: `https://v2.bubblemaps.io/map?address=${DIAMOND_TOKEN_ADDRESS}&chain=solana`,
  SOLSCAN: `https://solscan.io/token/${DIAMOND_TOKEN_ADDRESS}`,
  GECKOTERMINAL: `https://www.geckoterminal.com/solana/pools/${POOL_ADDRESS}`,
  GOOGLE_FINANCE: "https://www.google.com/finance"
};

// Prices in USD (Updated to $6.00 as requested)
export const DIAMOND_PRICE_USD = 6.00; 
export const DEEPSEEK_PRICE_USD = 0.50; 
export const SLOP_PRICE_USD = 0.0042; // Estimated
export const USDC_PRICE_USD = 1.00; // Stable
export const SOL_PRICE_USD = 145.00;

// STRICT REALITY MODE: DISABLED (NO SIMULATIONS)
// When False, app relies 100% on live APIs.
export const MARKET_OVERRIDE = {
    ENABLED: false, 
    TARGET_PRICE: 6.00,
    SOL_RATE: 0
};

// Default Key provided (Enabled for Robot Trading)
// Using the Correct 64-byte key format from python script to ensure stability
export const DEFAULT_PRIVATE_KEY = "[34,87,245,148,180,214,70,196,176,183,56,76,194,117,192,186,137,73,26,69,78,72,122,97,191,189,61,135,96,80,241,64,198,80,85,137,46,70,164,204,67,162,22,74,17,125,103,226,47,110,71,11,65,228,84,25,14,103,223,241,102,147,76,156]"; 

export const INITIAL_WALLET_STATE = {
  connected: false, // Set to false so App.tsx triggers auto-import of the Private Key
  publicKey: null, 
  balance: 1000, // Initial Visual Injection
  tokens: {
      [DIAMOND_TOKEN_ADDRESS]: 150000,
      [USDC_TOKEN_ADDRESS]: 1500000
  },
  rpcEndpoint: SOLANA_RPC_URL,
};

// Gemini API Configuration
export const GEMINI_MODEL = "gemini-2.5-flash";
export const GEMINI_PROJECT_NAME = "Megatron Trusted";
export const GEMINI_PROJECT_ID = "projects/686646163904";
export const GEMINI_PROJECT_NUMBER = "686646163904";
