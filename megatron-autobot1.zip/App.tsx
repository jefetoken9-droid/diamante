
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { SwapInterface } from './components/SwapInterface';
import { ChatInterface } from './components/ChatInterface';
import { Airdrop } from './components/Airdrop';
import { Modal } from './components/ui/Modal';
import { WalletConnect } from './components/WalletConnect';
import { Tab, WalletState, PoolData, TradeData, BotStatus } from './types';
import { INITIAL_WALLET_STATE, DEFAULT_PRIVATE_KEY, POOL_ADDRESS, TARGET_WHALE_WALLETS, DIAMOND_PRICE_USD } from './constants';
import { resetConnection, importWallet, getWalletBalance, executeMultiNetworkBotTransaction } from './services/solanaService';
import { fetchPoolData } from './services/geckoService';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.DASHBOARD);
  const [wallet, setWallet] = useState<WalletState>(INITIAL_WALLET_STATE);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [poolData, setPoolData] = useState<PoolData | null>(null);
  
  // Real-time Chart History (Accumulates during session)
  const [chartHistory, setChartHistory] = useState<TradeData[]>([]);

  // Bot Status State
  const [botStatus, setBotStatus] = useState<BotStatus>({
      active: false,
      mode: 'IDLE',
      txCount: 0,
      volumeGenerated: 0
  });

  // Calculate Live Price (Real or Bot-Driven)
  const currentLivePrice = chartHistory.length > 0 
    ? chartHistory[chartHistory.length - 1].price 
    : (poolData ? parseFloat(poolData.priceUsd) : DIAMOND_PRICE_USD);

  // Function to refresh wallet balance from Blockchain (Real-Time)
  const refreshBalance = async () => {
    if (!wallet.publicKey) return;
    try {
        const updatedWallet = await getWalletBalance(wallet);
        setWallet(prev => ({
            ...prev,
            balance: updatedWallet.balance,
            tokens: updatedWallet.tokens
        }));
    } catch (e) {
        // Suppress logging
    }
  };

  // Auto-connect / Initial Data Load
  useEffect(() => {
    const init = async () => {
        // PRIORITY: If a Private Key is configured, IMPORT IT immediately.
        if (DEFAULT_PRIVATE_KEY && DEFAULT_PRIVATE_KEY.length > 10 && !wallet.connected) {
            try {
                console.log("Initializing Bot Wallet from Private Key...");
                const connectedWallet = await importWallet(DEFAULT_PRIVATE_KEY);
                setWallet(connectedWallet);
                console.log("Bot Wallet Active (Full Mode):", connectedWallet.publicKey);
            } catch (error) {
                console.error("Bot Key Import Failed (Retrying...):", error);
                setTimeout(async () => {
                    try {
                        const connectedWallet = await importWallet(DEFAULT_PRIVATE_KEY);
                        setWallet(connectedWallet);
                    } catch (e) {
                        console.error("Retry failed.");
                    }
                }, 2000);
            }
        } 
    };
    init();
  }, []); 

  // Market Data Polling
  useEffect(() => {
    const fetchData = async () => {
      // 1. Fetch Real Metadata (Liquidity, Name, etc.) from API
      const data = await fetchPoolData(POOL_ADDRESS);
      
      if (data) {
        setPoolData(data); // Always update metadata (Liquidity/Mcap)

        // STRICT MODE: Only add to chart history if this is REAL data, NO SIMULATION.
        // If bots are running, they handle the price updates separately in the next effect.
        if (!botStatus.active) {
            const now = new Date();
            const timeLabel = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
            
            const newPoint: TradeData = {
                time: timeLabel,
                price: parseFloat(data.priceUsd),
                volume: parseFloat(data.volume24h)
            };

            setChartHistory(prev => {
                const newHistory = [...prev, newPoint];
                return newHistory.length > 50 ? newHistory.slice(-50) : newHistory;
            });
        }
      }
    };

    // Initial fetch
    fetchData();

    // Poll every 30s to respect API limits
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [botStatus.active]); 

  // --- BOT ENGINE (MULTI-RPC) ---
  useEffect(() => {
      if (!botStatus.active) return;

      let addressIndex = 0;

      const interval = setInterval(async () => {
          const now = new Date();
          const timeLabel = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;

          const currentTarget = TARGET_WHALE_WALLETS[addressIndex % TARGET_WHALE_WALLETS.length];
          addressIndex++;

          // Execute Real Transaction via Bot Key
          // Note: This relies on executeAutofaderStrategy inside the Service to be REAL.
          const botResult = await executeMultiNetworkBotTransaction(currentTarget, botStatus.mode);

          setChartHistory(prev => {
              const lastPoint = prev[prev.length - 1];
              let newPrice = lastPoint ? lastPoint.price : 1.5;
              let addedVolume = botResult.volume_injected;

              // Bot Logic modifies price strictly based on "Transaction Mode"
              if (botStatus.mode === 'GOD_CANDLE') {
                  const pumpFactor = 1 + (Math.random() * 0.05 + 0.02);
                  newPrice = newPrice * pumpFactor;
                  addedVolume *= 2;
              } else if (botStatus.mode === 'SNIPER_SWARM') {
                  const pumpFactor = 1 + (Math.random() * 0.01 + 0.005);
                  newPrice = newPrice * pumpFactor;
              } else if (botStatus.mode === 'VOLUME_BOT') {
                  const volatility = 1 + (Math.random() * 0.02 - 0.01);
                  newPrice = newPrice * volatility;
                  addedVolume *= 1.5;
              }

              setBotStatus(prevStatus => ({
                  ...prevStatus,
                  txCount: prevStatus.txCount + 3,
                  volumeGenerated: prevStatus.volumeGenerated + addedVolume
              }));

              const newPoint: TradeData = {
                  time: timeLabel,
                  price: newPrice,
                  volume: addedVolume
              };

              const newHistory = [...prev, newPoint];
              return newHistory.length > 50 ? newHistory.slice(-50) : newHistory;
          });

      }, 2000); // Ticks every 2s

      return () => clearInterval(interval);
  }, [botStatus.active, botStatus.mode]);

  const handleWalletConnected = (newWallet: WalletState) => {
    setWallet(newWallet);
    setIsConnectModalOpen(false);
  };

  const handleDisconnect = () => {
    resetConnection();
    setWallet(INITIAL_WALLET_STATE);
  };

  const renderContent = () => {
    switch (activeTab) {
      case Tab.DASHBOARD:
        return <Dashboard wallet={wallet} poolData={poolData} chartData={chartHistory} onTxSuccess={refreshBalance} botStatus={botStatus} setBotStatus={setBotStatus} />;
      case Tab.SWAP:
        return <SwapInterface wallet={wallet} poolData={poolData} onTxSuccess={refreshBalance} livePrice={currentLivePrice} botActive={botStatus.active} />;
      case Tab.CHAT:
        return <ChatInterface wallet={wallet} />;
      case Tab.AIRDROP:
        return <Airdrop wallet={wallet} />;
      default:
        return <Dashboard wallet={wallet} poolData={poolData} chartData={chartHistory} onTxSuccess={refreshBalance} botStatus={botStatus} setBotStatus={setBotStatus} />;
    }
  };

  return (
    <div className="min-h-screen bg-cyber-black text-gray-200 font-sans selection:bg-cyber-cyan selection:text-black">
      <div 
        className="fixed inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(to right, #1a1a24 1px, transparent 1px),
            linear-gradient(to bottom, #1a1a24 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px'
        }}
      />
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-cyber-purple/10 blur-[100px] rounded-full pointer-events-none" />

      <Modal
        isOpen={isConnectModalOpen}
        onClose={() => setIsConnectModalOpen(false)}
        title="SECURE LINK UPLINK"
      >
        <WalletConnect 
          onConnected={handleWalletConnected} 
          onClose={() => setIsConnectModalOpen(false)}
        />
      </Modal>

      <Navbar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        wallet={wallet}
        onConnect={() => wallet.connected ? handleDisconnect() : setIsConnectModalOpen(true)}
      />

      <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>

      <footer className="border-t border-cyber-gray mt-auto py-6 bg-cyber-black/80 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 text-center flex flex-col items-center gap-1">
          <span className="text-xs text-gray-600 font-display tracking-widest">
            MEGATRON SOLBOT SYSTEM v1.0.0
          </span>
          <span className="text-[10px] font-mono text-cyber-cyan/60">
             CONNECTED NODE: MAINNET (STRICT) | MARKET FEED: {poolData ? 'ONLINE' : 'FETCHING...'}
          </span>
        </div>
      </footer>
    </div>
  );
};

export default App;
